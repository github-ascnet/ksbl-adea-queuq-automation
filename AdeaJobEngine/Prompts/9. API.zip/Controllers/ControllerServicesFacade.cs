﻿using Infrastructure.GUI.Web.Data;
using Infrastructure.GUI.Web.Utils;
using Microsoft.Extensions.Options;

namespace Infrastructure.GUI.Web.Controllers
{
    public class ControllerServicesFacade
    {
        public KSBL_IAMContext Context { get; }
        public IEventLogService EventLogService;
        public AppSettingsService AppSettingsService { get; }
        public IUserInfoService UserInfoService { get; }
        public SamAccountTracker SamAccountTracker { get; }
        public IIamQueueService IamQueueService { get; }
        public IActiveDirectoryService ActiveDirectoryService { get; }
        public IListComparisonService ListComparisonService { get; }
        public IStringSanitizerService StringSanitizerService { get; }
        public IPowerShellRemoteExecService PowerShellRemoteExecService { get; }

        public ControllerServicesFacade(
            KSBL_IAMContext context,
            IEventLogService eventLogService,
            IOptions<AppSettingsService> appSettingsService,
            IUserInfoService userInfoService,
            SamAccountTracker samAccountTracker,
            IIamQueueService iamQueueService,
            IActiveDirectoryService activeDirectoryService,
            IListComparisonService listComparisonService,
            IStringSanitizerService stringSanitizerService,
            IPowerShellRemoteExecService powerShellRemoteExecService)
        {
            Context = context;
            EventLogService = eventLogService;
            AppSettingsService = appSettingsService.Value;
            UserInfoService = userInfoService;
            SamAccountTracker = samAccountTracker;
            IamQueueService = iamQueueService;
            ActiveDirectoryService = activeDirectoryService;
            ListComparisonService = listComparisonService;
            StringSanitizerService = stringSanitizerService;
            PowerShellRemoteExecService = powerShellRemoteExecService;
        }
    }
}
