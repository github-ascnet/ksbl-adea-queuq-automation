﻿using Infrastructure.GUI.Web.Data;
using Infrastructure.GUI.Web.Models;
using Infrastructure.GUI.Web.Utils;
using Infrastructure.GUI.Web.Views;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Diagnostics;
using System.Globalization;
using System.Text.Json;

namespace Infrastructure.GUI.Web.Controllers
{
    public class NewUserProps
    {
        public string AdEmployeeId { get; set; } = string.Empty;
        public string AdEmployeeType { get; set; } = string.Empty;
        public string AdObjectName { get; set; } = string.Empty;
        public string AdDisplayName { get; set; } = string.Empty;
        public string AdDepartment { get; set; } = string.Empty;
        public string MobilePhoneNumber { get; set; } = string.Empty;
        public string AdSurname { get; set; } = string.Empty;
        public string AdGivenname { get; set; } = string.Empty;
        public string ManagedBy { get; set; } = string.Empty;
        public string MailAddress { get; set; } = string.Empty;
        public bool MailboxEnable { get; set; } = false;
        public string UserDomain { get; set; } = string.Empty;
        public string UserDomainOU { get; set; } = string.Empty;
        public string UserLocation { get; set; } = string.Empty;
        public string BirthdayDate { get; set; } = string.Empty;
        public string ExternalCompany { get; set; } = string.Empty;
        public string AppDescription { get; set; } = string.Empty;
        public string HospisPersId { get; set; } = string.Empty;
        public string AdLdapSearchUserId { get; set; } = string.Empty;
        public string MessageTitleAction { get; set; } = string.Empty;
    }


    public class UserAccountsController : Controller
    {
        private readonly ControllerServicesFacade _facadeServices;
        private readonly NewUserProps _newUserProps;

        public UserAccountsController(ControllerServicesFacade facadeServices)
        {
            _facadeServices = facadeServices;
            _newUserProps = new NewUserProps();
        }

        // Action für das Ändern des Benutzernamens und der Benutzer-ID
        [HttpPost]
        public async Task<IActionResult> UpdateUserNameChange(UpdateUserNameChangeViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { UpdateUserNameChange = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 800);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            var samAccountName = model.UserNameChangeUserSelect?.ToString().ExtractDisplayNameSuffix();

            // 2. Benutzer aus der Datenbank abrufen
            var account = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(p => p.SamAccountName == samAccountName);

            if (account == null)
            {
                // Handle the case where the account is not found
                _facadeServices.EventLogService.LogWarning($"Account with SamAccountName {samAccountName} not found.", 801);
                TempData["ErrorMessage"] = $"Das Konto mit dem SamAccountName {samAccountName} wurde nicht gefunden.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 3. Überprüfen, ob sich der Nachname geändert hat
            string givenName = string.Empty;
            string surName = string.Empty;
            string newPrimaryEMailAddress = string.Empty;

            if (!string.Equals(account.SurName, model.UserNameChangeLastName, StringComparison.OrdinalIgnoreCase))
            {
                // 4. Email-Adresse erstellen und validieren
                givenName = account.GivenName; // Unverändert aus der Datenbank
                surName = model.UserNameChangeLastName.ReplaceIllegalChars(); // Neues LastName aus dem Model
                newPrimaryEMailAddress = $"{givenName}.{surName}@{_facadeServices.AppSettingsService.PrimarySmtpDomain}";

                // 5. Überprüfen, ob die Email-Adresse bereits existiert
                var existingMailAddresses = await _facadeServices.Context.ValidateEMailByMailAddressAsync(newPrimaryEMailAddress);
                if (existingMailAddresses.Any())
                {
                    for (int i = 1; i < 100; i++)
                    {
                        newPrimaryEMailAddress = $"{givenName}.{surName}.{i}@{_facadeServices.AppSettingsService.PrimarySmtpDomain}";
                        existingMailAddresses = await _facadeServices.Context.ValidateEMailByMailAddressAsync(newPrimaryEMailAddress);

                        if (!existingMailAddresses.Any())
                        {
                            break;
                        }
                    }
                }
            }

            // 6. Überprüfen, ob das Kontrollkästchen ausgewählt ist und die neue UserId vom aktuellen SamAccountName abweicht
            string newUserId;
            if (model.UserNameChangeNewUserId && !string.Equals(model.UserNameChangeUserId, account.SamAccountName, StringComparison.OrdinalIgnoreCase))
            {
                if (account.EmployeeType == "P") // Überprüfung auf `EmployeeType`
                {
                    newUserId = (await _facadeServices.SamAccountTracker.GetNextSamAccountNameAsync("us"));
                }
                else
                {
                    newUserId = (await _facadeServices.SamAccountTracker.GetNextSamAccountNameAsync("ex"));
                }
            }
            else
            {
                newUserId = account.SamAccountName; // Wenn keine Änderung notwendig ist
            }

            // 7. Schreiben eines Job-Files in die Queue
            var values = new List<string>
            {
                ExecutableAction.RenameUserAccount.ToString(),
                samAccountName,
                givenName,
                surName,
                newPrimaryEMailAddress,
                newUserId,
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };
            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.UpdateUserNameChangeColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 802);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError(
                        $"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 803);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 8. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 804);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                // 9. Aktualisieren der Namen
                account.GivenName = givenName;
                account.SurName = surName;
                account.DisplayName = $"{givenName} {surName}";

                // 10. Aktualisieren des SamAccountName, falls erforderlich
                if (model.UserNameChangeNewUserId && model.UserNameChangeUserId != samAccountName)
                {
                    string finalSamAccountName = model.UserNameChangeUserId;

                    // Falls das Feld leer ist oder ein Alias generiert werden soll
                    if (string.IsNullOrWhiteSpace(finalSamAccountName))
                    {
                        var prefix = samAccountName.StartsWith("ex") ? "ex" : "us";
                        finalSamAccountName = (await _facadeServices.SamAccountTracker.GetNextSamAccountNameAsync(prefix));
                        model.UserNameChangeUserId = finalSamAccountName; // Damit View konsistent bleibt
                    }

                    account.Name = finalSamAccountName;
                    account.Cn = finalSamAccountName;
                    account.SamAccountName = finalSamAccountName;
                    account.MailName = finalSamAccountName;

                    if (!string.IsNullOrEmpty(account.UserPrincipalName))
                        account.UserPrincipalName = account.UserPrincipalName.Replace(samAccountName, finalSamAccountName);

                    if (!string.IsNullOrEmpty(account.DistinguishedName))
                        account.DistinguishedName = account.DistinguishedName.Replace(samAccountName, finalSamAccountName);
                }

                // 11. Aktualisieren der E-Mail-Adresse
                if (newPrimaryEMailAddress != "N/A")
                {
                    if (!string.IsNullOrEmpty(newPrimaryEMailAddress))
                    {
                        account.Mail = newPrimaryEMailAddress;

                        if (!string.IsNullOrEmpty(account.ProxyAddresses))
                        {
                            account.ProxyAddresses = account.ProxyAddresses.Replace(model.UserNameChangeEmail, newPrimaryEMailAddress);
                        }
                        else
                        {
                            account.ProxyAddresses = newPrimaryEMailAddress;
                        }
                    }
                }
                else
                {
                    account.Mail = null;
                }

                try
                {
                    // 12. Speichern der Änderungen
                    _facadeServices.Context.Accounts.Update(account);
                    await _facadeServices.Context.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    string alert = $"Fehler beim Speichern der Änderung an {model.UserNameChangeUserSelect}: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 805);
                    TempData["ErrorMessage"] = alert;
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 13. ViewModel aktualisieren
                model.UserNameChangeEmail = newPrimaryEMailAddress;
                _facadeServices.EventLogService.LogInformation($"Das Benutzerkonto {model.UserNameChangeUserId} wurde erfolgreich modifiziert.", 806);
                TempData["SuccessMessage"] = $"Das Benutzerkonto {model.UserNameChangeUserId} wurde erfolgreich modifiziert.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }
            else
            {
                _facadeServices.EventLogService.LogInformation(
                    $"Das Benutzerkonto {model.UserNameChangeUserId} wurde erfolgreich modifiziert.", 806);
                TempData["SuccessMessage"] = $"Das Benutzerkonto {model.UserNameChangeUserId} wurde erfolgreich modifiziert.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }
        }

        // Action für das Ändern von Active Directory- und Exchange-Informationen
        [HttpPost]
        public async Task<IActionResult> UpdateAdAndExchangeUser(UpdateAdAndExchangeViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { UpdateAdAndExchange = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 900);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            var samAccountName = model.AdAndExchangeUserSelect?.ToString().ExtractDisplayNameSuffix();

            // 2. Benutzer aus der Datenbank abrufen
            // Changed an 7.10.2025
            //var person = await _facadeServices.Context.GetSinglePersonByWindowsIdAsync(samAccountName);
            var person = await _facadeServices.Context.GetSinglePersonAccountsBySamAccountNameAsync(samAccountName);

            if (person == null)
            {
                // Handle the case where the account is not found
                _facadeServices.EventLogService.LogWarning($"Account with SamAccountName {samAccountName} not found.", 901);
                TempData["ErrorMessage"] = $"Das Konto mit dem SamAccountName {samAccountName} wurde nicht gefunden.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            var account = person.Select(p => new Person
            {
                WindowsLogin = p.SamAccountName,
                // Changed an 7.10.2025
                WindowsAccountState = p.UserAccountControl.Contains("ACCOUNTDISABLE") ? "Disabled": "Enabled",
            }).FirstOrDefault();

            // 3. Überprüfung der Kontooptionen
            if ((account.WindowsAccountState == "Disabled" && model.AdAndExchangeAccountStatus == "active") ||
                (account.WindowsAccountState == "Enabled" && model.AdAndExchangeAccountStatus == "inactive"))
            {
                // Gültige Kombination – keine weitere Prüfung des Alias erforderlich
            }
            else
            {
                // 2. Prüfung auf ungültige Kombinationen (alles andere ist ungültig)
                // Konto-Status Kombination ist ungültig, jetzt prüfen, ob der Alias leer ist
                if (string.IsNullOrEmpty(model.AdAndExchangeAlias))
                {
                    TempData["ErrorMessage"] = "Der eingegebene E-Mail Nickname und/oder die Konten-Option sind ungültig. Bitte geben Sie eines von beidem ein!";
                    _facadeServices.EventLogService.LogWarning("Ungültige Änderung: Kein Alias oder ungültige Konten-Option angegeben.", 902);
                    return RedirectToAction("Landing", "Home", new { tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }

            var executableAction = account.WindowsAccountState == "Disabled" && model.AdAndExchangeAccountStatus == "active"
                ? ExecutableAction.EnableNonStdPersonMailbox
                : account.WindowsAccountState != "Disabled" && model.AdAndExchangeAccountStatus == "inactive"
                    ? ExecutableAction.DisableNonStdPersonMailbox
                    : ExecutableAction.Unknown;

            if (executableAction != ExecutableAction.Unknown)
            {
                // 4. Schreiben eines Job-Files in die Queue
                var values = new List<string>
                {
                    executableAction.ToString(),
                    samAccountName,
                    userInfo.CurrentUserName,
                    userInfo.CurrentUserDomainName,
                    userInfo.CurrentUserEMailAddress
                };

                string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.UpdateAdAndExchangeUserUpdateAccountColumns) + "\r\n" + string.Join("|", values);
                _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 903);

                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError(
                        $"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 904);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new { tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

            }

            string newPrimaryEMailAddress = string.Empty;
            // 4b. Queue-File für E-Mail-Alias erstellen
            if (!string.IsNullOrWhiteSpace(model.AdAndExchangeAlias))
            {
                newPrimaryEMailAddress = $"{model.AdAndExchangeAlias}@{_facadeServices.AppSettingsService.PrimarySmtpDomain}";

                var aliasValues = new List<string>
                {
                    ExecutableAction.AddEMailNickName.ToString(),
                    samAccountName,
                    _facadeServices.AppSettingsService.NetBiosDomain,
                    newPrimaryEMailAddress,
                    userInfo.CurrentUserName,
                    userInfo.CurrentUserDomainName,
                    userInfo.CurrentUserEMailAddress
                };

                string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.UpdateAdAndExchangeUserChangeMailAliasColumns) + "\r\n" + string.Join("|", aliasValues);
                _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n{IamQueueFileContent}", 905);

                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError(
                        $"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 906);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new { tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }

            bool saveChangesRequired = false;
            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems 
                && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
            {
                if (!string.IsNullOrWhiteSpace(model.AdAndExchangeAlias))
                {
                    var accountDb = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(a => a.SamAccountName == samAccountName);

                    if (accountDb != null)
                    {
                        accountDb.Mail = newPrimaryEMailAddress;
                        accountDb.ProxyAddresses = accountDb.ProxyAddresses?.Replace("SMTP:", "smtp:") ?? "";
                        accountDb.ProxyAddresses += $"|SMTP:{newPrimaryEMailAddress.ToLower()}";
                        saveChangesRequired = true;
                    }
                }

                if (executableAction != ExecutableAction.Unknown)
                {
                    account.WindowsAccountState = model.AdAndExchangeAccountStatus == "active" ? "Enabled" : "Disabled";
                    _facadeServices.Context.Persons.Update(account);
                    saveChangesRequired = true;
                }

                if (saveChangesRequired)
                {
                    try
                    {
                        await _facadeServices.Context.SaveChangesAsync();
                        _facadeServices.EventLogService.LogInformation($"Das Benutzerkonto {model.AdAndExchangeUserSelect} wurde erfolgreich modifiziert.", 906);
                        TempData["SuccessMessage"] = $"Das Benutzerkonto {model.AdAndExchangeUserSelect} wurde erfolgreich modifiziert.";
                    }
                    catch (Exception ex)
                    {
                        string alert = $"Fehler beim Speichern der Änderung an {model.AdAndExchangeUserSelect}: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        _facadeServices.EventLogService.LogError(alert, 907);
                        TempData["ErrorMessage"] = alert;
                    }
                }
            }
            else
            {
                _facadeServices.EventLogService.LogInformation($"Das Benutzerkonto {model.AdAndExchangeUserSelect} wurde erfolgreich modifiziert.", 906);
                TempData["SuccessMessage"] = $"Das Benutzerkonto {model.AdAndExchangeUserSelect} wurde erfolgreich modifiziert.";
            }

            return RedirectToAction("Landing", "Home", new
            {
                tab = combinedViewModel.ActiveTab,
                section = combinedViewModel.ActiveSection
            });

        }

        // Action für das Erstellen eines neuen Hausarzt Benutzers
        [HttpPost]
        public async Task<IActionResult> CreateNewHausarztUser(CreateNewHausarztUserViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { CreateNewHausarztUser = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 1000);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftrag abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            _newUserProps.AdObjectName = (await _facadeServices.SamAccountTracker.GetNextSamAccountNameAsync("us"));
            _newUserProps.AdLdapSearchUserId = model.ExistingHausarztUserId != null ? model.ExistingHausarztUserId : string.Empty;
            _newUserProps.MailboxEnable = false;
            _newUserProps.UserDomain = _facadeServices.AppSettingsService.LdapDomain;
            _newUserProps.UserLocation = model.NewHausarztLocation;
            _newUserProps.AdSurname = model.NewHausarztLastName.ReplaceIllegalChars().Trim();
            _newUserProps.AdGivenname = model.NewHausarztFirstName.ReplaceIllegalChars().Trim();
            _newUserProps.AdDisplayName = _newUserProps.AdSurname + " " + _newUserProps.AdGivenname;
            _newUserProps.MailAddress = await _facadeServices.ActiveDirectoryService.ValidateMailAddressAsync(_newUserProps.AdGivenname + "." + _newUserProps.AdSurname + "@" + _facadeServices.AppSettingsService.PrimarySmtpDomain);
            _newUserProps.AdEmployeeId = string.Empty;
            _newUserProps.AdEmployeeType = "HNP";
            _newUserProps.UserDomainOU = _facadeServices.AppSettingsService.M2IntOrgUnitName.ToString();
            _newUserProps.AdDepartment = "Notfall Hausärzte";
            _newUserProps.BirthdayDate = string.Empty;
            _newUserProps.ExternalCompany = string.Empty;
            _newUserProps.AppDescription = string.Empty;

            // 2. Schreiben eines Job-Files in die Queue
            var values = new List<string>
            {
                ExecutableAction.CreateNonStdPersonMailbox.ToString(),
                _newUserProps.AdObjectName,
                _newUserProps.AdLdapSearchUserId,
                _newUserProps.MailboxEnable.ToString(),
                _newUserProps.UserDomain,
                _newUserProps.UserLocation,
                _newUserProps.AdSurname,
                _newUserProps.AdGivenname,
                _newUserProps.AdDisplayName,
                _newUserProps.AdEmployeeId,
                _newUserProps.AdEmployeeType,
                _newUserProps.UserDomainOU,
                _newUserProps.AdDepartment,
                _newUserProps.BirthdayDate,
                _newUserProps.ExternalCompany,
                _newUserProps.AppDescription,
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };

            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.CreateNewHausarztUserColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 1001);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError(
                        $"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 1002);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 3. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 1003);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                // 4. Erstellen eines neuen Datenbank-Objektes
                var newUserAccount = new Account
                {
                    PrivisioningActionType = ExecutableAction.CreateNonStdPersonMailbox.ToString(),
                    EmployeeId = _newUserProps.AdEmployeeId,
                    DisplayName = _newUserProps.AdDisplayName,
                    SurName = _newUserProps.AdSurname,
                    GivenName = _newUserProps.AdGivenname,
                    Name = _newUserProps.AdObjectName,
                    UserPrincipalName = _newUserProps.AdObjectName + "@" + _facadeServices.AppSettingsService.UpnDomain,
                    Cn = _newUserProps.AdObjectName,
                    SamAccountName = _newUserProps.AdObjectName,
                    DistinguishedName = _newUserProps.UserDomainOU,
                    MailNickname = _newUserProps.MailboxEnable == true ? _newUserProps.AdObjectName : string.Empty,
                    Mail = _newUserProps.MailboxEnable == true ? _newUserProps.MailAddress : string.Empty,
                    ExchHideFromAddressLists = _newUserProps.MailboxEnable == true ? true : false,
                    EmployeeType = _newUserProps.AdEmployeeType,
                    HrmsBirthdate = _newUserProps.BirthdayDate,
                    Company = _newUserProps.ExternalCompany,
                    Description = _newUserProps.AppDescription,
                    ModifiedBy = userInfo.CurrentUserName,
                    ModifiedOn = DateTime.Now
                };

                _facadeServices.Context.Accounts.Add(newUserAccount);

                try
                {
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation($"Der Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt", 1004);
                    TempData["SuccessMessage"] = $"Der Benutzer  {_newUserProps.AdDisplayName} wurde erfolgreich erstellt.";
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Der Benutzer {_newUserProps.AdDisplayName} konnte nicht der Datenbank hinzugefügt werden. {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 1005);
                    TempData["ErrorMessage"] = alert;
                    ModelState.AddModelError("", alert);
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else
            {
                _facadeServices.EventLogService.LogInformation($"Der Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt", 1004);
                TempData["SuccessMessage"] = $"Der Benutzer  {_newUserProps.AdDisplayName} wurde erfolgreich erstellt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

        }

        // Action für das Erstellen eines neuen Admin Benutzers
        [HttpPost]
        public async Task<IActionResult> CreateNewAdminUser(CreateNewAdminUserViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { CreateNewAdminUser = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 1100);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            var samAccountName = model.NewAdminPersId?.ToString().ExtractDisplayNameSuffix();

            // 2. Benutzer aus der Datenbank abrufen
            var account = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(p => p.SamAccountName == samAccountName);

            if (account == null)
            {
                _facadeServices.EventLogService.LogWarning($"Account with SamAccountName {samAccountName} not found.", 1101);
                TempData["ErrorMessage"] = $"Das Konto mit dem SamAccountName {samAccountName} wurde nicht gefunden.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            _newUserProps.AdObjectName = model.NewAdminUserId;
            _newUserProps.AdLdapSearchUserId = string.Empty;
            _newUserProps.MailboxEnable = false;
            _newUserProps.UserDomain = _facadeServices.AppSettingsService.LdapDomain;
            _newUserProps.UserLocation = string.Empty;
            _newUserProps.AdSurname = model.NewAdminLastName.ReplaceIllegalChars().Trim();
            _newUserProps.AdGivenname = model.NewAdminFirstName.ReplaceIllegalChars().Trim();
            _newUserProps.AdDisplayName = _newUserProps.AdSurname + " " + _newUserProps.AdGivenname;
            _newUserProps.MailAddress = string.Empty;
            _newUserProps.AdEmployeeId = account.EmployeeId;
            _newUserProps.AdEmployeeType = "A";
            _newUserProps.UserDomainOU = _facadeServices.AppSettingsService.AdminAccountOrgUnitName.ToString();
            _newUserProps.AdDepartment = account.Department;
            _newUserProps.BirthdayDate = account.HrmsBirthdate;
            _newUserProps.ExternalCompany = string.Empty;
            _newUserProps.AppDescription = string.Empty;

            var values = new List<string>
            {
                ExecutableAction.CreateNonStdPersonMailbox.ToString(),
                _newUserProps.AdObjectName,
                _newUserProps.AdLdapSearchUserId,
                _newUserProps.MailboxEnable.ToString(),
                _newUserProps.UserDomain,
                _newUserProps.UserLocation,
                _newUserProps.AdSurname,
                _newUserProps.AdGivenname,
                _newUserProps.AdDisplayName,
                _newUserProps.AdEmployeeId,
                _newUserProps.AdEmployeeType,
                _newUserProps.UserDomainOU,
                _newUserProps.AdDepartment,
                _newUserProps.BirthdayDate,
                _newUserProps.ExternalCompany,
                _newUserProps.AppDescription,
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };

            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.CreateNewAdminUserColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 1102);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError($"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 1103);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 3. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 1104);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                // 4. Erstellen eines neuen Datenbank-Objektes
                var newUserAccount = new Account
                {
                    PrivisioningActionType = ExecutableAction.CreateNonStdPersonMailbox.ToString(),
                    EmployeeId = _newUserProps.AdEmployeeId,
                    DisplayName = _newUserProps.AdDisplayName,
                    SurName = _newUserProps.AdSurname,
                    GivenName = _newUserProps.AdGivenname,
                    Name = _newUserProps.AdObjectName,
                    UserPrincipalName = _newUserProps.AdObjectName + "@" + _facadeServices.AppSettingsService.UpnDomain,
                    Cn = _newUserProps.AdObjectName,
                    SamAccountName = _newUserProps.AdObjectName,
                    DistinguishedName = _newUserProps.UserDomainOU,
                    MailNickname = _newUserProps.MailboxEnable == true ? _newUserProps.AdObjectName : string.Empty,
                    Mail = _newUserProps.MailboxEnable == true ? _newUserProps.MailAddress : string.Empty,
                    ExchHideFromAddressLists = _newUserProps.MailboxEnable == true ? true : false,
                    EmployeeType = _newUserProps.AdEmployeeType,
                    HrmsBirthdate = _newUserProps.BirthdayDate,
                    Company = _newUserProps.ExternalCompany,
                    Description = _newUserProps.AppDescription,
                    ModifiedBy = userInfo.CurrentUserName,
                    ModifiedOn = DateTime.Now
                };

                _facadeServices.Context.Accounts.Add(newUserAccount);

                try
                {
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation($"Der Admin-Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt", 1105);
                    TempData["SuccessMessage"] = $"Der Admin-Benutzer  {_newUserProps.AdDisplayName} wurde erfolgreich erstellt.";
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Der Admin-Benutzer {_newUserProps.AdDisplayName} konnte nicht der Datenbank hinzugefügt werden. {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 1106);
                    TempData["ErrorMessage"] = alert;
                    ModelState.AddModelError("", alert);
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else
            {
                _facadeServices.EventLogService.LogInformation($"Der Admin-Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt", 1105);
                TempData["SuccessMessage"] = $"Der Admin-Benutzer  {_newUserProps.AdDisplayName} wurde erfolgreich erstellt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

        }

        // Action für das Erstellen eines neuen Externer Benutzers
        [HttpPost]
        public async Task<IActionResult> CreateNewExternalUser(CreateNewExternalUserViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { CreateNewExternalUser = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 1200);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            _newUserProps.AdObjectName = model.NewExternalUserType.ToString() == "Externer Mitarbeiter (Informatik)"
                ? (await _facadeServices.SamAccountTracker.GetNextSamAccountNameAsync("ex"))
                : (await _facadeServices.SamAccountTracker.GetNextSamAccountNameAsync("us"));
            _newUserProps.AdLdapSearchUserId = string.Empty;
            _newUserProps.MailboxEnable = model.NewExternalEnableMailbox;
            _newUserProps.UserDomain = _facadeServices.AppSettingsService.LdapDomain;
            _newUserProps.UserLocation = model.NewExternalLocation;
            _newUserProps.AdSurname = model.NewExternalLastName.ReplaceIllegalChars().Trim();
            _newUserProps.AdGivenname = model.NewExternalFirstName.ReplaceIllegalChars().Trim();
            _newUserProps.AdDisplayName = _newUserProps.AdSurname + " " + _newUserProps.AdGivenname;
            _newUserProps.MailAddress = model.NewExternalEnableMailbox == true 
                ? await _facadeServices.ActiveDirectoryService.ValidateMailAddressAsync(_newUserProps.AdGivenname + "." + _newUserProps.AdSurname + "@" + _facadeServices.AppSettingsService.PrimarySmtpDomain) 
                : string.Empty ;
            _newUserProps.AdEmployeeId = string.Empty;
            _newUserProps.AdEmployeeType = "E";
            _newUserProps.UserDomainOU = _facadeServices.AppSettingsService.M2ExtOrgUnitName.ToString();
            _newUserProps.AdDepartment = string.Empty;
            _newUserProps.BirthdayDate = model.NewExternalBirthdate.ToString();
            _newUserProps.ExternalCompany = model.NewExternalCompany;
            _newUserProps.AppDescription = string.Empty;

            var values = new List<string>
            {
                ExecutableAction.CreateNonStdPersonMailbox.ToString(),
                _newUserProps.AdObjectName,
                _newUserProps.AdLdapSearchUserId,
                _newUserProps.MailboxEnable.ToString(),
                _newUserProps.UserDomain,
                _newUserProps.UserLocation,
                _newUserProps.AdSurname,
                _newUserProps.AdGivenname,
                _newUserProps.AdDisplayName,
                _newUserProps.AdEmployeeId,
                _newUserProps.AdEmployeeType,
                _newUserProps.UserDomainOU,
                _newUserProps.AdDepartment,
                _newUserProps.BirthdayDate,
                _newUserProps.ExternalCompany,
                _newUserProps.AppDescription,
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };

            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.CreateNewExternalUserColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 1201);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError($"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 1202);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 2. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 1203);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                // 3. Erstellen eines neuen Datenbank-Objektes
                var newUserAccount = new Account
                {
                    PrivisioningActionType = ExecutableAction.CreateNonStdPersonMailbox.ToString(),
                    EmployeeId = _newUserProps.AdEmployeeId,
                    DisplayName = _newUserProps.AdDisplayName,
                    SurName = _newUserProps.AdSurname,
                    GivenName = _newUserProps.AdGivenname,
                    Name = _newUserProps.AdObjectName,
                    UserPrincipalName = _newUserProps.AdObjectName + "@" + _facadeServices.AppSettingsService.UpnDomain,
                    Cn = _newUserProps.AdObjectName,
                    SamAccountName = _newUserProps.AdObjectName,
                    DistinguishedName = _newUserProps.UserDomainOU,
                    MailNickname = _newUserProps.MailboxEnable == true ? _newUserProps.AdObjectName : string.Empty,
                    Mail = _newUserProps.MailboxEnable == true ? _newUserProps.MailAddress : string.Empty,
                    ExchHideFromAddressLists = _newUserProps.MailboxEnable == true ? true : false,
                    EmployeeType = _newUserProps.AdEmployeeType,
                    HrmsBirthdate = _newUserProps.BirthdayDate,
                    Company = _newUserProps.ExternalCompany,
                    Description = _newUserProps.AppDescription,
                    ModifiedBy = userInfo.CurrentUserName,
                    ModifiedOn = DateTime.Now
                };

                _facadeServices.Context.Accounts.Add(newUserAccount);

                try
                {
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation($"Der externe Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt", 1204);
                    TempData["SuccessMessage"] = $"Der externe Benutzer  {_newUserProps.AdDisplayName} wurde erfolgreich erstellt.";
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Der externe Benutzer {_newUserProps.AdDisplayName} konnte nicht der Datenbank hinzugefügt werden. {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 1205);
                    TempData["ErrorMessage"] = alert;
                    ModelState.AddModelError("", alert);
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else
            {
                _facadeServices.EventLogService.LogInformation($"Der externe Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt", 1204);
                TempData["SuccessMessage"] = $"Der externe Benutzer  {_newUserProps.AdDisplayName} wurde erfolgreich erstellt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

        }

        // Action für das Erstellen eines neuen Internen Benutzers
        [HttpPost]
        public async Task<IActionResult> CreateNewInternalUser(CreateNewInternalUserViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { CreateNewInternalUser = model }.WithTabAndSection(model);
            // Hegyaljai Ina
            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 1300);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            var persId = model.NewInternalPersId?.ToString().ExtractDisplayNameSuffix();

            _newUserProps.AdObjectName = (await _facadeServices.SamAccountTracker.GetNextSamAccountNameAsync("us"));
            _newUserProps.AdLdapSearchUserId = string.Empty;
            _newUserProps.MailboxEnable = true;
            _newUserProps.UserDomain = _facadeServices.AppSettingsService.LdapDomain;
            _newUserProps.UserLocation = string.Empty;
            _newUserProps.AdSurname = model.NewInternalLastName.ReplaceIllegalChars().Trim();
            _newUserProps.AdGivenname = model.NewInternalFirstName.ReplaceIllegalChars().Trim();
            _newUserProps.AdDisplayName = _newUserProps.AdSurname + " " + _newUserProps.AdGivenname;
            _newUserProps.MailAddress = await _facadeServices.ActiveDirectoryService.ValidateMailAddressAsync(_newUserProps.AdGivenname + "." + _newUserProps.AdSurname + "@" + _facadeServices.AppSettingsService.PrimarySmtpDomain);
            _newUserProps.AdEmployeeId = persId;
            _newUserProps.AdEmployeeType = "P";
            _newUserProps.UserDomainOU = _facadeServices.AppSettingsService.M2ExtOrgUnitName.ToString();
            _newUserProps.AdDepartment = model.NewInternalDepartment;
            //_newUserProps.BirthdayDate = model.NewInternalBirthdate.ToString();
            _newUserProps.BirthdayDate = model.NewInternalBirthdate.HasValue
                ? model.NewInternalBirthdate.Value.ToString("dd.MM.yyyy", CultureInfo.InvariantCulture)
                : string.Empty;
            _newUserProps.ExternalCompany = string.Empty;
            _newUserProps.AppDescription = string.Empty;

            if (!string.IsNullOrWhiteSpace(model.SelectedDuplicateSamAccountName) && model.SelectedDuplicateSamAccountName != "__new")
            {
                Console.WriteLine($"⚠️ Duplikat wurde manuell ausgewählt: {model.SelectedDuplicateSamAccountName}");
                _newUserProps.AdLdapSearchUserId = model.SelectedDuplicateSamAccountName;
            }

            var values = new List<string>
            {
                ExecutableAction.CreateNonStdPersonMailbox.ToString(),
                _newUserProps.AdObjectName,
                _newUserProps.AdLdapSearchUserId,
                _newUserProps.MailboxEnable.ToString(),
                _newUserProps.UserDomain,
                _newUserProps.UserLocation,
                _newUserProps.AdSurname,
                _newUserProps.AdGivenname,
                _newUserProps.AdDisplayName,
                _newUserProps.AdEmployeeId,
                _newUserProps.AdEmployeeType,
                _newUserProps.UserDomainOU,
                _newUserProps.AdDepartment,
                _newUserProps.BirthdayDate,
                _newUserProps.ExternalCompany,
                _newUserProps.AppDescription,
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };

            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.CreateNewInternalUserColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 1301);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError($"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 1302);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 2. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 1303);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                // 3. Erstellen eines neuen Datenbank-Objektes
                var newUserAccount = new Account
                {
                    PrivisioningActionType = ExecutableAction.CreateNonStdPersonMailbox.ToString(),
                    EmployeeId = _newUserProps.AdEmployeeId,
                    DisplayName = _newUserProps.AdDisplayName,
                    SurName = _newUserProps.AdSurname,
                    GivenName = _newUserProps.AdGivenname,
                    Name = _newUserProps.AdObjectName,
                    UserPrincipalName = _newUserProps.AdObjectName + "@" + _facadeServices.AppSettingsService.UpnDomain,
                    Cn = _newUserProps.AdObjectName,
                    SamAccountName = _newUserProps.AdObjectName,
                    DistinguishedName = _newUserProps.UserDomainOU,
                    MailNickname = _newUserProps.MailboxEnable == true ? _newUserProps.AdObjectName : string.Empty,
                    Mail = _newUserProps.MailboxEnable == true ? _newUserProps.MailAddress : string.Empty,
                    ExchHideFromAddressLists = _newUserProps.MailboxEnable == true ? true : false,
                    EmployeeType = _newUserProps.AdEmployeeType,
                    HrmsBirthdate = _newUserProps.BirthdayDate,
                    Company = _newUserProps.ExternalCompany,
                    Description = _newUserProps.AppDescription,
                    ModifiedBy = userInfo.CurrentUserName,
                    ModifiedOn = DateTime.Now
                };

                _facadeServices.Context.Accounts.Add(newUserAccount);

                try
                {
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation($"Der externe Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt", 1304);
                    TempData["SuccessMessage"] = $"Der externe Benutzer  {_newUserProps.AdDisplayName} wurde erfolgreich erstellt.";
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Der externe Benutzer {_newUserProps.AdDisplayName} konnte nicht der Datenbank hinzugefügt werden. {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 1305);
                    TempData["ErrorMessage"] = alert;
                    ModelState.AddModelError("", alert);
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else
            {
                _facadeServices.EventLogService.LogInformation($"Der externe Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt", 1304);
                TempData["SuccessMessage"] = $"Der externe Benutzer  {_newUserProps.AdDisplayName} wurde erfolgreich erstellt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }
        }

        // Action für das Erstellen eines neuen Service Benutzers
        [HttpPost]
        public async Task<IActionResult> CreateNewServiceUser(CreateNewServiceUserViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { CreateNewServiceUser = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 1400);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            var samAccountName = model.NewServiceUserId?.ToString();

            // 2. Benutzer aus der Datenbank abrufen
            var account = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(p => p.SamAccountName == samAccountName);

            if (account != null)
            {
                _facadeServices.EventLogService.LogWarning($"Account with SamAccountName {samAccountName} already exists.", 1401);
                TempData["ErrorMessage"] = $"Das Konto mit dem SamAccountName {samAccountName} existiert bereits.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            _newUserProps.AdObjectName = samAccountName;
            _newUserProps.AdLdapSearchUserId = string.Empty;
            _newUserProps.MailboxEnable = model.NewServiceEnableMailbox;
            _newUserProps.UserDomain = _facadeServices.AppSettingsService.LdapDomain;
            _newUserProps.UserLocation = string.Empty;
            _newUserProps.AdSurname = model.NewServiceLastName.ReplaceIllegalChars().Trim();
            _newUserProps.AdGivenname = model.NewServiceFirstName.ReplaceIllegalChars().Trim();
            _newUserProps.AdDisplayName = _newUserProps.AdSurname + " " + _newUserProps.AdGivenname;
            _newUserProps.MailAddress = model.NewServiceEnableMailbox == true
                ? await _facadeServices.ActiveDirectoryService.ValidateMailAddressAsync(_newUserProps.AdGivenname + "." + _newUserProps.AdSurname + "@" + _facadeServices.AppSettingsService.PrimarySmtpDomain)
                : string.Empty;
            _newUserProps.AdEmployeeId = string.Empty;
            _newUserProps.AdEmployeeType = "S";
            _newUserProps.UserDomainOU = model.NewServiceAccountType?.ToString() == "Managed Service Account"
                ? _facadeServices.AppSettingsService.ManagedServiceAccountOrgUnitName.ToString()
                : _facadeServices.AppSettingsService.ServiceAccountOrgUnitName.ToString(); 
            _newUserProps.AdDepartment = string.Empty;
            _newUserProps.BirthdayDate = string.Empty;
            _newUserProps.ExternalCompany = string.Empty;
            _newUserProps.AppDescription = string.IsNullOrEmpty(model.NewServiceAppDescription) 
                ?  $"Service-Account created by {userInfo.CurrentUserName} on {DateTime.Now.ToShortDateString()}"
                : model.NewServiceAppDescription;

            ExecutableAction ServiceAccountExecutableAction = ExecutableAction.Unknown;
            switch (model.NewServiceAccountType?.ToString())
            {
                case "Standard Service Account":
                    ServiceAccountExecutableAction = ExecutableAction.CreateServiceAccount;
                    break;
                case "Managed Service Account":
                    ServiceAccountExecutableAction = ExecutableAction.CreateManagedServiceAccount;
                    break;
                case "WLAN Service Account":
                    ServiceAccountExecutableAction = ExecutableAction.CreateWpaServiceAccount;
                    break;
            }


            var values = new List<string>
            {
                ServiceAccountExecutableAction.ToString(),
                _newUserProps.AdObjectName,
                _newUserProps.AdLdapSearchUserId,
                _newUserProps.MailboxEnable.ToString(),
                _newUserProps.UserDomain,
                _newUserProps.UserLocation,
                _newUserProps.AdSurname,
                _newUserProps.AdGivenname,
                _newUserProps.AdDisplayName,
                _newUserProps.AdEmployeeId,
                _newUserProps.AdEmployeeType,
                _newUserProps.UserDomainOU,
                _newUserProps.AdDepartment,
                _newUserProps.BirthdayDate,
                _newUserProps.ExternalCompany,
                _newUserProps.AppDescription,
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };

            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.CreateNewServiceUserColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 1402);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError($"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 1403);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 3. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 1404);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                // 4. Erstellen eines neuen Datenbank-Objektes
                var newUserAccount = new Account
                {
                    PrivisioningActionType = ServiceAccountExecutableAction.ToString(),
                    EmployeeId = _newUserProps.AdEmployeeId,
                    DisplayName = _newUserProps.AdDisplayName,
                    SurName = _newUserProps.AdSurname,
                    GivenName = _newUserProps.AdGivenname,
                    Name = _newUserProps.AdObjectName,
                    UserPrincipalName = _newUserProps.AdObjectName + "@" + _facadeServices.AppSettingsService.UpnDomain,
                    Cn = _newUserProps.AdObjectName,
                    SamAccountName = _newUserProps.AdObjectName,
                    DistinguishedName = _newUserProps.UserDomainOU,
                    MailNickname = _newUserProps.MailboxEnable == true ? _newUserProps.AdObjectName : string.Empty,
                    Mail = _newUserProps.MailboxEnable == true ? _newUserProps.MailAddress : string.Empty,
                    ExchHideFromAddressLists = _newUserProps.MailboxEnable == true ? true : false,
                    EmployeeType = _newUserProps.AdEmployeeType,
                    HrmsBirthdate = _newUserProps.BirthdayDate,
                    Company = _newUserProps.ExternalCompany,
                    Description = _newUserProps.AppDescription,
                    ModifiedBy = userInfo.CurrentUserName,
                    ModifiedOn = DateTime.Now
                };

                _facadeServices.Context.Accounts.Add(newUserAccount);

                try
                {
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation($"Der Service-Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt", 1405);
                    TempData["SuccessMessage"] = $"Der Service-Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt.";
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Der Service-Benutzer {_newUserProps.AdDisplayName} konnte nicht der Datenbank hinzugefügt werden. {ExceptionHelper.GetMostRelevantMessage(ex)}";   
                    _facadeServices.EventLogService.LogError(alert, 1406);
                    TempData["ErrorMessage"] = alert;
                    ModelState.AddModelError("", alert);
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else
            {
                _facadeServices.EventLogService.LogInformation($"Der Service-Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt", 1405);
                TempData["SuccessMessage"] = $"Der Service-Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

        }

        // Action für das Erstellen eines neuen Multifunktionsbenutzers
        [HttpPost]
        public async Task<IActionResult> CreateMultifunctionUser(CreateMultifunctionUserViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { CreateMultifunctionUser = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 1500);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            var samAccountName = model.MultifunctionUserId?.ToString();

            // 2. Benutzer aus der Datenbank abrufen
            var account = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(p => p.SamAccountName == samAccountName);

            if (account != null)
            {
                _facadeServices.EventLogService.LogWarning($"Account with SamAccountName {samAccountName} already exists.", 1501);
                TempData["ErrorMessage"] = $"Das Konto mit dem SamAccountName {samAccountName} existiert bereits.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            _newUserProps.AdObjectName = samAccountName;
            _newUserProps.AdDisplayName = samAccountName;
            _newUserProps.AdEmployeeType = "GU";
            _newUserProps.AppDescription = $"Gemeinschaftsuser - {model.MultifunctionDescription}";
            _newUserProps.UserDomainOU = _facadeServices.AppSettingsService.MultiFuncGenericOrgUnitName.ToString();
            _newUserProps.UserDomain = _facadeServices.AppSettingsService.LdapDomain;
            _newUserProps.ManagedBy = string.IsNullOrEmpty(model.MultifunctionResponsible?.ToString())
                ? string.Empty
                : $"{model.MultifunctionResponsible?.ToString().ExtractDisplayNameSuffix()}[ADD]";


            var values = new List<string>
            {
                ExecutableAction.CreateMultiFunctionGenericUser.ToString(),
                _newUserProps.AdObjectName,
                _newUserProps.UserDomain,
                _newUserProps.AdDisplayName,
                _newUserProps.AdEmployeeType,
                _newUserProps.UserDomainOU,
                _newUserProps.ManagedBy,
                _newUserProps.AppDescription,
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };

            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.CreateMultifunctionUserColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 1502);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError($"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 1503);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 3. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 1504);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                // 4. Erstellen eines neuen Datenbank-Objektes
                var newUserAccount = new Account
                {
                    PrivisioningActionType = ExecutableAction.CreateMultiFunctionGenericUser.ToString(),
                    DisplayName = _newUserProps.AdDisplayName,
                    Name = _newUserProps.AdObjectName,
                    UserPrincipalName = _newUserProps.AdObjectName + "@" + _facadeServices.AppSettingsService.UpnDomain,
                    Cn = _newUserProps.AdObjectName,
                    SamAccountName = _newUserProps.AdObjectName,
                    DistinguishedName = _newUserProps.UserDomainOU,
                    MailNickname = _newUserProps.MailboxEnable == true ? _newUserProps.AdObjectName : string.Empty,
                    EmployeeType = _newUserProps.AdEmployeeType,
                    ModifiedBy = userInfo.CurrentUserName,
                    ModifiedOn = DateTime.Now
                };

                _facadeServices.Context.Accounts.Add(newUserAccount);

                try
                {
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation($"Der Gemeinschafts-Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt", 1505);
                    TempData["SuccessMessage"] = $"Der Gemeinschafts-Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt.";
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Der Gemeinschafts-Benutzer {_newUserProps.AdDisplayName} konnte nicht der Datenbank hinzugefügt werden. {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 1506);
                    TempData["ErrorMessage"] = alert;
                    ModelState.AddModelError("", alert);
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else
            {
                _facadeServices.EventLogService.LogInformation($"Der Gemeinschafts-Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt", 1505);
                TempData["SuccessMessage"] = $"Der Gemeinschafts-Benutzer {_newUserProps.AdDisplayName} wurde erfolgreich erstellt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }
        }

        // Action für das Zuordnen einer mobilen Nummer
        [HttpPost]
        public async Task<IActionResult> AssignMobileNumber(AssignMobileNumberViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { AssignMobileNumber = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 1600);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            var samAccountName = model.MobileNumberUserSelect?.ToString().ExtractDisplayNameSuffix();

            if (string.IsNullOrEmpty(model.MobileNumber))
            {
                _facadeServices.EventLogService.LogWarning($"Die mobile Nummer ist ungültig.", 1601);
                TempData["ErrorMessage"] = $"Die mobile Nummer ist ungültig.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            _newUserProps.AdObjectName = samAccountName;
            _newUserProps.MobilePhoneNumber = model.MobileNumber;

            var values = new List<string>
            {
                ExecutableAction.ModifyMobilePhoneNumber.ToString(),
                _newUserProps.AdObjectName,
                _newUserProps.MobilePhoneNumber,
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };

            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.AssignMobileNumberColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 1602);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError($"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 1603);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 2. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 1604);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                var account = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(p => p.SamAccountName == samAccountName);

                if (account == null)
                {
                    _facadeServices.EventLogService.LogWarning($"Account with SamAccountName {samAccountName} not found.", 1605);
                    TempData["ErrorMessage"] = $"Das Konto mit dem SamAccountName {samAccountName} wurde nicht gefunden.";
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                account.ExtensionAttribute3 = _newUserProps.MobilePhoneNumber;

                try
                {
                    // 3. Speichern der Änderungen
                    _facadeServices.Context.Accounts.Update(account);
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation($"Dem Benutzer {_newUserProps.AdObjectName} wurde die Mobile Nummer erfolgreich zugeteilt", 1606);
                    TempData["SuccessMessage"] = $"Dem Benutzer {_newUserProps.AdObjectName} wurde die Mobile Nummer erfolgreich zugeteilt.";
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Fehler beim Speichern der Änderung an {model.MobileNumberUserSelect}: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 1607);
                    TempData["ErrorMessage"] = alert;
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else
            {
                _facadeServices.EventLogService.LogInformation($"Dem Benutzer {_newUserProps.AdObjectName} wurde die Mobile Nummer erfolgreich zugeteilt", 1606);
                TempData["SuccessMessage"] = $"Dem Benutzer {_newUserProps.AdObjectName} wurde die Mobile Nummer erfolgreich zugeteilt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

        }
    }
}
