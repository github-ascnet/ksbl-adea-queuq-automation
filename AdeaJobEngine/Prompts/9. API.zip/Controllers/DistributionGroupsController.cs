﻿using Infrastructure.GUI.Web.Data;
using Infrastructure.GUI.Web.Models;
using Infrastructure.GUI.Web.Utils;
using Infrastructure.GUI.Web.Views;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System.Collections.Generic;

namespace Infrastructure.GUI.Web.Controllers
{
    public class DistributionGroupsController : Controller
    {
        private readonly ControllerServicesFacade _facadeServices;
        public DistributionGroupsController(ControllerServicesFacade facadeServices)
        {
            _facadeServices = facadeServices;
        }
        
        [HttpPost]
        public async Task<IActionResult> CreateDistributionGroup(CreateDistributionGroupViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { CreateDistributionGroup = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 400);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new { tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                //return View(ViewPaths.Home.Landing, combinedViewModel);
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new { tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                //return View(ViewPaths.Home.Landing, combinedViewModel);
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            // 2. Überprüfen, ob eine Verteilerliste mit diesem Namen bereits existiert
            var fullObjectName = $"VL-{model.DgCreateLocation}-{model.DgCreateSearchFor}";
            var existingGroup = await _facadeServices.Context.Groups.FirstOrDefaultAsync(g => g.DisplayName == fullObjectName);

            if (existingGroup != null)
            {
                _facadeServices.EventLogService.LogWarning(
                    $"Die Verteilerliste {fullObjectName} existiert bereits.", 401);
                TempData["ErrorMessage"] = $"Die Verteilerliste {fullObjectName} existiert bereits! Bitte wählen Sie einen anderen Namen.";
                ModelState.AddModelError("", $"Die Verteilerliste {fullObjectName} existiert bereits! Bitte wählen Sie einen anderen Namen.");
                return RedirectToAction("Landing", "Home", new { tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                //return View(ViewPaths.Home.Landing, combinedViewModel);
            }

            // 3. Erstellen der primären SMTP-Adresse und weiterer Attribute
            var primarySmtpAddress = $"{model.DgCreateLocation.ToLower()}.vl.{model.DgCreateSearchFor.ToLower()}@{_facadeServices.AppSettingsService.PrimarySmtpDomain}";
            var targetOu = _facadeServices.AppSettingsService.DistListOrgUnitName;

            // 4. Überprüfen, ob ein Manager für die Verteilerliste ausgewählt wurde
            if (string.IsNullOrEmpty(model.DgCreateManager))
            {
                _facadeServices.EventLogService.LogWarning(
                    $"Für die Verteilerliste {fullObjectName} muss mindestens ein gültiger Verantwortlicher ausgewählt werden.", 402);
                TempData["ErrorMessage"] = $"Es muss mindestens ein gültiger Verantwortlicher ausgewählt werden.";
                ModelState.AddModelError("", $"Es muss mindestens ein gültiger Verantwortlicher ausgewählt werden.");
                return RedirectToAction("Landing", "Home", new { tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                //return View(ViewPaths.Home.Landing, combinedViewModel);
            }

            string samAccountName = string.Empty;
            if (Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
            {
                samAccountName = await _facadeServices.SamAccountTracker.GetNextSamAccountNameAsync("vl");
                _facadeServices.EventLogService.LogInformation($"Für die Verteilerliste {fullObjectName} wurde der SamAccountName {samAccountName} selektiert.", 403);
            }
            else
            {
                samAccountName = await _facadeServices.SamAccountTracker.GetNextSamAccountNameAsync("vl");
                _facadeServices.EventLogService.LogInformation(
                    $"Für die Verteilerliste {fullObjectName} wurde der SamAccountName {samAccountName} selektiert.", 403);
            }
            string managedBy = model.DgCreateManager;
            bool isHiddenInAb = model.DgCreateHideFromAddressLists == true ? true : false;

            // 5. Schreiben eines Job-Files in die Queue
            var values = new List<string>
            {
                ExecutableAction.CreateDistributionList.ToString(),
                fullObjectName,                                    
                primarySmtpAddress,                                
                samAccountName,                                    
                targetOu,                                          
                isHiddenInAb.ToString(),                           
                managedBy,                                         
                userInfo.CurrentUserName,                          
                userInfo.CurrentUserDomainName,                    
                userInfo.CurrentUserEMailAddress                   
            };
            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.CreateDistributionGroupColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 404);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError(
                        $"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 405);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 6. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately 
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 406);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                // 7. Erstellen eines neuen Datenbank-Objektes
                var newDistributionGroup = new Group
                {
                    Name = model.DgCreateSearchFor,
                    DisplayName = fullObjectName,
                    SamAccountName = samAccountName,
                    MailNickname = model.DgCreateAlias,
                    Mail = primarySmtpAddress,
                    ExchHideFromAddressLists = model.DgCreateHideFromAddressLists,
                    Manager = model.DgCreateManager, // Du musst vielleicht den DistinguishedName hier setzen
                    ModifiedBy = userInfo.CurrentUserName,
                    ModifiedOn = DateTime.Now
                };

                _facadeServices.Context.Groups.Add(newDistributionGroup);

                try
                {
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation(
                        $"Die Verteilerliste {fullObjectName} mit der E-Mail Adresse {primarySmtpAddress} wurde erfolgreich erstellt", 407);
                    TempData["SuccessMessage"] = $"Die Verteilerliste {fullObjectName} mit der E-Mail Adresse {primarySmtpAddress} wurde erfolgreich erstellt.";                    
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Die Verteilerliste {fullObjectName} mit der E-Mail Adresse {primarySmtpAddress} konnte nicht der Datenbank hinzugefügt werden. {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 408);
                    TempData["ErrorMessage"] = alert;
                    ModelState.AddModelError("", alert);                    
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else 
            {
                _facadeServices.EventLogService.LogInformation(
                    $"Die Verteilerliste {fullObjectName} mit der E-Mail Adresse {primarySmtpAddress} wurde erfolgreich erstellt.", 407);
                TempData["SuccessMessage"] = $"Die Verteilerliste {fullObjectName} mit der E-Mail Adresse {primarySmtpAddress} wurde erfolgreich erstellt.";                
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }
        }

        [HttpPost]
        public async Task<IActionResult> ModifyDistributionGroupPermissions(ModifyDistributionGroupPermissionsViewModel model, [FromForm] IFormCollection formCollection)
        {
            var combinedViewModel = new CombinedViewModel { ModifyDistributionGroupPermissions = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 500);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            var samAccountName = model.DgModPermissionGroupName?.ToString().ExtractDisplayNameSuffix();

            // 2. Aktuelle Berechtigungen auslesen und Differenzen berechnen
            var managedByMembersList = await _facadeServices.Context.GetVlResponsibleListAsync(samAccountName);
            var currentManagedByMembers = managedByMembersList.Select(account => account.SamAccountName).ToList();
            
            // 3. samAccountName-Werte aus `model.PermissionList` extrahieren
            var newManagedByMembersSamAccounts = model.DgModPermissionUsersList
                .Select(item => item.Contains("{") && item.Contains("}")
                    ? item.Split('{')[1].TrimEnd('}')
                    : item) // Fallback falls kein `samAccountName` im erwarteten Format vorhanden ist
                .ToList();

            // 4. Berechnete Unterschiede zwischen den extrahierten und den aktuellen Berechtigungen
            var managedByDiff = _facadeServices.ListComparisonService.CompareLists(newManagedByMembersSamAccounts, currentManagedByMembers);

            // 5. Erstelle den `managedByMembers`-String direkt aus den Differenzen
            string managedByMembers = string.Join("!", managedByDiff.Split('!').Select(p => p.Trim()));

            // 6. Filtern von Berechtigungen für Hinzufügen und Entfernen
            var managedByDiffToAdd = managedByDiff
                .Split('!')
                .Where(p => p.EndsWith("[ADD]"))
                .Select(p => p.Replace("[ADD]", "").Trim())
                .ToList();

            var managedByDiffToRemove = managedByDiff
                .Split('!')
                .Where(p => p.EndsWith("[DEL]"))
                .Select(p => p.Replace("[DEL]", "").Trim())
                .ToList();

            // 7. Schreiben eines Job-Files in die Queue
            var values = new List<string>
            {
                ExecutableAction.AddDistributionListResponsibles.ToString(),
                samAccountName,
                managedByMembers,
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };
            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.ModifyDistributionGroupPermissionsColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 501);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError(
                        $"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 502);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 8. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 503);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                var distribList = await _facadeServices.Context.Groups.FirstOrDefaultAsync(p => p.SamAccountName == samAccountName);

                if (distribList == null)
                {
                    _facadeServices.EventLogService.LogError(
                        $"Die Verteilerliste {model.DgModPermissionGroupName} konnte in der Datenbank nicht gefunden werden.", 504);
                    TempData["ErrorMessage"] = $"Beim modifizieren der Verteilerliste  {model.DgModPermissionGroupName}  ist ein Fehler aufgetreten.  ";
                    ModelState.AddModelError("", $"Die Verteilerliste {model.DgModPermissionGroupName} konnte in der Datenbank nicht gefunden werden.");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 9. Alle neuen Verantwortlichen für die Verteilerliste hinzufügen
                foreach (var managerName in managedByDiffToAdd)
                {
                    var managerAccount = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(p => p.SamAccountName == managerName);

                    if (managerAccount != null)
                    {
                        distribList.Manager = managerAccount.DistinguishedName;

                        var managersToGroup = new ManagersToGroup
                        {
                            PrivisioningActionType = ExecutableAction.AddDistributionListResponsibles.ToString(),
                            AccountsId = managerAccount.Id,
                            GroupsId = distribList.Id,
                            ManagerName = managerAccount.DisplayName,
                            GroupName = distribList.DisplayName,
                            ModifiedBy = $"{userInfo.CurrentUserDomainName}\\{userInfo.CurrentUserName}",
                            ModifiedOn = DateTime.Now
                        };
                        await _facadeServices.Context.ManagersToGroups.AddAsync(managersToGroup);
                    }
                }

                // 10. Alle existierenden Verantwortlichen von der Verteilerliste entfernen
                foreach (var managerName in managedByDiffToRemove)
                {
                    var managerAccount = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(p => p.SamAccountName == managerName);

                    if (managerAccount != null)
                    {
                        var managerToRemove = await _facadeServices.Context.ManagersToGroups
                            .FirstOrDefaultAsync(p => p.GroupsId == distribList.Id && p.AccountsId == managerAccount.Id);

                        if (managerToRemove != null)
                        {
                            managerToRemove.ModifiedBy = $"{userInfo.CurrentUserDomainName}\\{userInfo.CurrentUserName}";
                            managerToRemove.ModifiedOn = DateTime.Now;
                            _facadeServices.Context.ManagersToGroups.Remove(managerToRemove);
                        }
                    }
                }

                try
                {
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation(
                        $"Die Verantwortlichen auf der Verteilerliste {model.DgModPermissionGroupName} wurden erfolgreich modifiziert.", 505);
                    TempData["SuccessMessage"] = $"Die Verantwortlichen auf der Verteilerliste {model.DgModPermissionGroupName} wurden erfolgreich modifiziert.";

                    //await RazorViewDataHelper.StoreSingleSelectOptionInTempDataAsync(
                    //    TempData, _facadeServices.Context, "SelectedVlPermissionGroupName", model.DgModPermissionGroupName, StoreSelectEntityOption.Groups);

                    //await RazorViewDataHelper.StoreListSelectOptionsInTempDataAsync(
                    //    TempData, _facadeServices.Context, "SelectedVlPermissionUsersList", model.DgModPermissionUsersList, StoreSelectEntityOption.Groups);

                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Fehler beim Speichern der Änderung an {model.DgModPermissionGroupName}: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 506);
                    TempData["ErrorMessage"] = alert;
                    ModelState.AddModelError("", alert);
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else 
            {
                _facadeServices.EventLogService.LogInformation(
                    $"Die Verantwortlichen auf der Verteilerliste {model.DgModPermissionGroupName} wurden erfolgreich modifiziert.", 505);
                TempData["SuccessMessage"] = $"Die Verantwortlichen auf der Verteilerliste {model.DgModPermissionGroupName} wurden erfolgreich modifiziert.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

        }

        //[HttpPost]
        //public async Task<IActionResult> ModifyDistributionGroupResponsible(ModifyDistributionGroupResponsibleViewModel model)
        //{
        //    var combinedViewModel = new CombinedViewModel { ModifyDistributionGroupResponsible = model }.WithTabAndSection(model);

        //            if (!ModelState.IsValid)
        //            {
        //                var modelErrors = ModelState.EnumerateModelStateErrors();
        //        var fullMessage = model.FormatValidationLogMessage(ModelState);
        //        _facadeServices.EventLogService.LogWarning(fullMessage, 600);
        //                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
        //                return View(ViewPaths.Home.Landing, combinedViewModel);
        //    }

        //            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
        //            {
        //                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
        //                return View(ViewPaths.Home.Landing, combinedViewModel);
        //}

//    // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
//    var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
//    ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

//    var samAccountName = model.DgModOwnershipGroupName?.ToString().ExtractDisplayNameSuffix();
//    var managerName = model.DgModNewOwner?.ToString().ExtractDisplayNameSuffix();

//    // 2. Schreiben eines Job-Files in die Queue
//    var values = new List<string>
//    {
//        ExecutableAction.ChangeManagerDistribList.ToString(),
//        samAccountName,
//        managerName,
//        userInfo.CurrentUserName,
//        userInfo.CurrentUserDomainName,
//        userInfo.CurrentUserEMailAddress
//    };
//    string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.ChangeDistributionGroupResponsibleColumns) + "\r\n" + string.Join("|", values);
//    _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 601);

//    if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
//    {
//        string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

//        if (result != "success")
//        {
//            _facadeServices.EventLogService.LogError(
//                $"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 602);
//            TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
//            ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
//            return View(ViewPaths.Home.Landing, combinedViewModel);
//        }

//        // 3. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
//        if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
//            && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
//        {
//            try
//            {
//                await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
//            }
//            catch (Exception ex)
//            {
//                _facadeServices.EventLogService.LogError(
//                    $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 603);
//                TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
//                ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
//                return View(ViewPaths.Home.Landing, combinedViewModel);
//            }
//        }

//        var distribList = await _facadeServices.Context.Groups.FirstOrDefaultAsync(p => p.SamAccountName == samAccountName);
//        var distribListManager = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(p => p.SamAccountName == managerName);

//        if (distribList == null || distribListManager == null)
//        {
//            _facadeServices.EventLogService.LogError(
//                $"Die Verteilerliste {model.DgModOwnershipGroupName} oder der/die Verantwortliche {model.DgModNewOwner} konnte in der Datenbank nicht gefunden werden.", 604);
//            TempData["ErrorMessage"] = $"Beim modifizieren der Verteilerliste  {model.DgModOwnershipGroupName}  ist ein Fehler aufgetreten.  ";
//            ModelState.AddModelError("", $"Die Verteilerliste {model.DgModOwnershipGroupName} oder der/die Verantwortliche {model.DgModNewOwner} konnte in der Datenbank nicht gefunden werden.");
//            return View(ViewPaths.Home.Landing, combinedViewModel);
//        }

//        distribList.Manager = distribListManager.DistinguishedName;

//        try
//        {
//            await _facadeServices.Context.SaveChangesAsync();
//            _facadeServices.EventLogService.LogInformation(
//                $"Der Verantwortliche auf der Verteilerliste {model.DgModOwnershipGroupName} wurden erfolgreich modifiziert.", 605);
//            TempData["SuccessMessage"] = $"DieDer Verantwortliche auf der Verteilerliste {model.DgModOwnershipGroupName} wurden erfolgreich modifiziert.";
//            return View(ViewPaths.Home.Landing, combinedViewModel);
//        }
//        catch (Exception ex)
//        {
//            _facadeServices.EventLogService.LogError($"Allgemeiner Fehler beim Speichern: {ExceptionHelper.GetMostRelevantMessage(ex)}", 606);
//            TempData["ErrorMessage"] = $"Allgemeiner Fehler beim Speichern: {ExceptionHelper.GetMostRelevantMessage(ex)}";
//            return View(ViewPaths.Home.Landing, combinedViewModel);
//        }
//    }
//    else
//    {
//        _facadeServices.EventLogService.LogInformation(
//            $"Der Verantwortliche auf der Verteilerliste {model.DgModOwnershipGroupName} wurden erfolgreich modifiziert.", 605);
//        TempData["SuccessMessage"] = $"Der Verantwortliche auf der Verteilerliste {model.DgModOwnershipGroupName} wurden erfolgreich modifiziert.";
//        return View(ViewPaths.Home.Landing, combinedViewModel);
//    }
//}

        [HttpPost]
        public async Task<IActionResult> DeleteDistributionGroup(DeleteDistributionGroupViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { DeleteDistributionGroup = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 700);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            var samAccountName = model.DgDeleteGroupName?.ToString().ExtractDisplayNameSuffix();

            // 2. Schreiben eines Job-Files in die Queue
            var values = new List<string>
            {
                ExecutableAction.DeleteDistribList.ToString(),
                samAccountName,
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };
            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.DeleteDistributionGroupColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 701);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError(
                        $"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 702);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 3. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 703);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                var distribList = await _facadeServices.Context.Groups.FirstOrDefaultAsync(p => p.SamAccountName == samAccountName);

                if (distribList == null)
                {
                    _facadeServices.EventLogService.LogError(
                        $"Die Verteilerliste {model.DgDeleteGroupName} konnte in der Datenbank nicht gefunden werden.", 704);
                    TempData["ErrorMessage"] = $"Beim löschen der Verteilerliste {model.DgDeleteGroupName} ist ein Fehler aufgetreten.  ";
                    ModelState.AddModelError("", $"Die Verteilerliste {model.DgDeleteGroupName} konnte in der Datenbank nicht gefunden werden.");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                var membersInGroup = await _facadeServices.Context.AccountsToGroups.Where(p => p.GroupsId == distribList.Id).ToListAsync();

                if (membersInGroup.Any())
                {
                    _facadeServices.Context.AccountsToGroups.RemoveRange(membersInGroup);

                    try
                    {
                        await _facadeServices.Context.SaveChangesAsync();
                        _facadeServices.EventLogService.LogInformation(
                            $"Die Verteilerliste {model.DgDeleteGroupName} wurden erfolgreich gelöscht.", 705);
                        TempData["SuccessMessage"] = $"Die Verteilerliste {model.DgDeleteGroupName} wurden erfolgreich gelöscht.";
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError($"Allgemeiner Fehler beim Speichern: {ExceptionHelper.GetMostRelevantMessage(ex)}", 706);
                        TempData["ErrorMessage"] = $"Allgemeiner Fehler beim Speichern: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                _facadeServices.Context.Groups.Remove(distribList);

                try
                {
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation(
                        $"Die Verteilerliste {model.DgDeleteGroupName} wurde erfolgreich gelöscht.", 707);
                    TempData["SuccessMessage"] = $"Die Verteilerliste {model.DgDeleteGroupName} wurde erfolgreich gelöscht.";
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Fehler beim Speichern der Änderung an {model.DgDeleteGroupName}: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 708);
                    TempData["ErrorMessage"] = alert;
                    ModelState.AddModelError("", alert);
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else
            {
                _facadeServices.EventLogService.LogInformation(
                    $"Die Verteilerliste {model.DgDeleteGroupName} wurde erfolgreich gelöscht.", 707);
                TempData["SuccessMessage"] = $"Die Verteilerliste {model.DgDeleteGroupName} wurde erfolgreich gelöscht.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

        }

    }
}
