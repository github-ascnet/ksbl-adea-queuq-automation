﻿using Infrastructure.GUI.Web.Data;
using Infrastructure.GUI.Web.Models;
using Infrastructure.GUI.Web.Utils;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace Infrastructure.GUI.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ControllerServicesFacade _facadeServices;
        public HomeController(ControllerServicesFacade facadeServices)
        {
            _facadeServices = facadeServices;
        }

        [Route("BrowserNotSupported")]
        public IActionResult BrowserNotSupported()
        {
            return View();
        }

        public async Task<IActionResult> Landing(string tab = "groupmailbox", string section = "create")
        {
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();

            if (!userInfo.CurrentUserName.StartsWith("adm", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine($"⛔ Zugriff verweigert für Benutzer: {userInfo.CurrentUserName} → Zwangs-Login ausgelöst");
                // 🧹 Session und Auth-Daten löschen
                HttpContext.Session.Clear();
                // 🧱 Browser-Caching komplett verhindern
                Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
                Response.Headers["Pragma"] = "no-cache";
                Response.Headers["Expires"] = "0";
                // Antwort mit 401 erzwingen → Browser zeigt Loginfenster bei Windows-Auth
                Response.Headers["WWW-Authenticate"] = "Negotiate"; // oder "NTLM", je nach Konfiguration
                return Unauthorized(); // Triggert Browser-Popup für Windows Auth
            }

            ViewBag.UserEmail = 
                string.IsNullOrEmpty(userInfo.CurrentUserEMailAddress) ? _facadeServices.AppSettingsService.DefaultRecipientAddress : userInfo.CurrentUserEMailAddress;
            ViewBag.UserName = $"{userInfo.CurrentUserDomainName}\\{userInfo.CurrentUserName}";

            var viewModel = new CombinedViewModel
            {
                ActiveTab = tab,
                ActiveSection = section
            };
            
            viewModel.HospisUserAction = new HospisUserActionViewModel
            {
                CanAccessITInfrastructure = viewModel.CanAccessITInfrastructure
            };

            if (Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
            {
                // Gruppen nur bei Bedarf aus AD laden
                const string sessionKey = "AdeaUserGroups";
                List<string>? userGroups;

                if (!HttpContext.Session.TryGetValue(sessionKey, out var groupBytes))
                {
                    var username = userInfo.CurrentUserName;
                    var usernameOnly = username.Contains("\\") ? username.Split('\\')[1] : username;

                    userGroups = await _facadeServices.ActiveDirectoryService.GetUsersTokenGroupsAsync(usernameOnly);

                    var json = JsonSerializer.Serialize(userGroups);
                    HttpContext.Session.Set(sessionKey, Encoding.UTF8.GetBytes(json));
                    Console.WriteLine($"✅ Gruppen aus AD geladen und gespeichert: {string.Join(", ", userGroups)}");
                }
                else
                {
                    var json = Encoding.UTF8.GetString(groupBytes);
                    userGroups = JsonSerializer.Deserialize<List<string>>(json);
                    Console.WriteLine($"♻️ Gruppen aus Session geladen");
                }

                //viewModel.CanAccessCreateNewGroupMailbox = userGroups.Contains(_facadeServices.AppSettingsService.RoleCreateNewGroupMailbox);
                //viewModel.CanAccessModifyGroupMailboxPermissions = userGroups.Contains(_facadeServices.AppSettingsService.RoleModifyGroupMailboxPermissions);
                //viewModel.CanAccessModifyGroupMailboxResponsible = userGroups.Contains(_facadeServices.AppSettingsService.RoleModifyGroupMailboxResponsible);
                //viewModel.CanAccessCreateNewDistributionGroup = userGroups.Contains(_facadeServices.AppSettingsService.RoleCreateNewDistributionGroup);
                //viewModel.CanAccessModifyDistributionGroupPermissions = userGroups.Contains(_facadeServices.AppSettingsService.RoleCreateNewDistributionGroup);
                //viewModel.CanAccessModifyDistributionGroupResponsible = userGroups.Contains(_facadeServices.AppSettingsService.RoleCreateNewDistributionGroup);
                //viewModel.CanAccessDeleteDistributionGroup = userGroups.Contains(_facadeServices.AppSettingsService.RoleCreateNewDistributionGroup);
                //viewModel.CanAccessModifyUserNameChange = userGroups.Contains(_facadeServices.AppSettingsService.RoleModifyUserNameChange);
                //viewModel.CanAccessModifyUserAddMailNickname = userGroups.Contains(_facadeServices.AppSettingsService.RoleModifyUserAddMailNickname);
                //viewModel.CanAccessChangeMobileNumber = userGroups.Contains(_facadeServices.AppSettingsService.RoleChangeMobileNumber);
                //viewModel.CanAccessCreateHausarztUser = userGroups.Contains(_facadeServices.AppSettingsService.RoleCreateNewHausarztUser);
                //viewModel.CanAccessCreateInternalUser = userGroups.Contains(_facadeServices.AppSettingsService.RoleCreateNewInternalUser);
                //viewModel.CanAccessCreateExternalUser = userGroups.Contains(_facadeServices.AppSettingsService.RoleCreateNewExternalUser);
                //viewModel.CanAccessCreateAdminUser = userGroups.Contains(_facadeServices.AppSettingsService.RoleCreateNewAdminUser);
                //viewModel.CanAccessCreateServiceUser = userGroups.Contains(_facadeServices.AppSettingsService.RoleCreateNewServiceUser);
                //viewModel.CanAccessCreateMultiFunctionalGenericUser = userGroups.Contains(_facadeServices.AppSettingsService.RoleCreateNewMultiFunctionalGenericUser);
                //viewModel.CanAccessSubmitTransactions = userGroups.Contains(_facadeServices.AppSettingsService.RoleSubmitTransactions);
                viewModel.CanAccessITServicedesk = userGroups.Contains(_facadeServices.AppSettingsService.RoleITServicedesk);
                viewModel.CanAccessITInfrastructure = userGroups.Contains(_facadeServices.AppSettingsService.RoleITInfrastructure);

                //if (!viewModel.CanAccessITInfrastructure && !viewModel.CanAccessITServicedesk)
                //{
                //    return View("~/Views/Shared/_AccessDenied.cshtml");
                //}
            }
            else
            {
                // Für Non-Domain-Umgebung: alles erlauben (z. B. Test)
                //viewModel.CanAccessCreateNewGroupMailbox = true;
                //viewModel.CanAccessModifyGroupMailboxPermissions = true;
                //viewModel.CanAccessModifyGroupMailboxResponsible = true;
                //viewModel.CanAccessCreateNewDistributionGroup = true;
                //viewModel.CanAccessModifyDistributionGroupPermissions = true;
                //viewModel.CanAccessModifyDistributionGroupResponsible = true;
                //viewModel.CanAccessDeleteDistributionGroup = true;
                //viewModel.CanAccessModifyUserNameChange = true;
                //viewModel.CanAccessModifyUserAddMailNickname = true;
                //viewModel.CanAccessChangeMobileNumber = true;
                //viewModel.CanAccessCreateHausarztUser = true;
                //viewModel.CanAccessCreateInternalUser = true;
                //viewModel.CanAccessCreateExternalUser = true;
                //viewModel.CanAccessCreateAdminUser = true;
                //viewModel.CanAccessCreateServiceUser = true;
                //viewModel.CanAccessCreateMultiFunctionalGenericUser = true;
                //viewModel.CanAccessSubmitTransactions = true;
                viewModel.CanAccessITServicedesk = true;
                viewModel.CanAccessITInfrastructure = true;
            }

            return View(viewModel);
        }


    }


}
