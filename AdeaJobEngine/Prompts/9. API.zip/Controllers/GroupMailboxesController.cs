﻿using Infrastructure.GUI.Web.Data;
using Infrastructure.GUI.Web.Models;
using Infrastructure.GUI.Web.Utils;
using Infrastructure.GUI.Web.Views;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace Infrastructure.GUI.Web.Controllers
{
    public class GroupMailboxesController : Controller
    {
        private readonly ControllerServicesFacade _facadeServices;

        private string hospisToAdDeleteAttrValue = "Hospis2AdDeleted";

        public GroupMailboxesController(ControllerServicesFacade facadeServices)
        {
            _facadeServices = facadeServices;
        }

        [HttpPost]
        public async Task<IActionResult> CreateGroupMailbox(CreateGroupMailboxViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { CreateGroupMailbox = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 100);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            // 2. Gruppenpostfachname und SMTP-Adresse generieren
            var fullObjectName = $"GMB-{model.GmbCreateLocation}-{model.GmbCreateSearchFor}";
            var primarySmtpAddress = $"{model.GmbCreateLocation.ToLower()}.{model.GmbCreateSearchFor.ToLower()}@{_facadeServices.AppSettingsService.PrimarySmtpDomain}";

            // 3. Überprüfen, ob ein Gruppenpostfach mit diesem Namen existiert
            var existingAccount = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(g => g.DisplayName == fullObjectName);
            if (existingAccount != null)
            {
                _facadeServices.EventLogService.LogWarning(
                    $"Das Gruppenpostfach {fullObjectName} existiert bereits.", 101);
                TempData["ErrorMessage"] = $"Das Gruppenpostfach {fullObjectName} existiert bereits! Bitte wählen Sie einen anderen Namen.";
                ModelState.AddModelError("", $"Das Gruppenpostfach {fullObjectName} existiert bereits! Bitte wählen Sie einen anderen Namen.");
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 4. Überprüfen, ob ein Manager für das Gruppenpostfach ausgewählt wurde
            if (string.IsNullOrEmpty(model.GmbCreateManager))
            {
                _facadeServices.EventLogService.LogWarning(
                    $"Für das Gruppenpostfach {fullObjectName} muss mindestens ein gültiger Verantwortlicher ausgewählt werden.", 102);
                TempData["ErrorMessage"] = $"Es muss mindestens ein gültiger Verantwortlicher ausgewählt werden.";
                ModelState.AddModelError("", $"Es muss mindestens ein gültiger Verantwortlicher ausgewählt werden.");
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 5. Generierung des Manager-Strings aus `GmbCreateManager`
            var selectedItem = model.GmbCreateManager?.ToString();
            string managedBy = string.Empty;
            if (!string.IsNullOrWhiteSpace(selectedItem))
            {
                if (selectedItem.Contains("{") && selectedItem.Contains("}"))
                {
                    managedBy = selectedItem.Split('{')[1].TrimEnd('}') + "[ADD]";
                }
                else
                {
                    managedBy = selectedItem + "[ADD]";
                }
            }

            // 6. SamAccountName generieren
            string samAccountName = string.Empty;
            if (Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
            {
                samAccountName = await _facadeServices.SamAccountTracker.GetNextSamAccountNameAsync("gmb");
                _facadeServices.EventLogService.LogInformation(
                    $"Für das Gruppenpostfach {fullObjectName} wurde der SamAccountName {samAccountName} selektiert.", 103);
            }
            else
            {
                samAccountName = await _facadeServices.SamAccountTracker.GetNextSamAccountNameAsync("gmb");
                _facadeServices.EventLogService.LogInformation(
                    $"Für das Gruppenpostfach {fullObjectName} wurde der SamAccountName {samAccountName} selektiert.", 103);
            }

            // 7. SMTP-Adresse für Alias generieren, wenn vorhanden
            string newPrimaryEmailAddress = !string.IsNullOrEmpty(model.GmbCreateAlias)
                ? $"{model.GmbCreateAlias}@{_facadeServices.AppSettingsService.PrimarySmtpDomain}"
                : primarySmtpAddress;

            // 8. Berechtigungen hinzufügen (entspricht `fullAccessMembers`)
            var fullAccessMembers = string.Join("!", model.GmbCreateFullAccessPersonsList.Select(member => $"{member}[ADD]"));
            if (string.IsNullOrEmpty(fullAccessMembers))
            {
                TempData["ErrorMessage"] = "Mindestens eine Person muss als Berechtigter ausgewählt werden.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            var firstName = model.GmbCreateLocation.ToString();
            var lastName = model.GmbCreateSearchFor;
            var targetOu = _facadeServices.AppSettingsService.GroupMailboxOrgUnitName;

            // 9. Schreiben eines Job-Files in die Queue
            var values = new List<string>
            {
                ExecutableAction.CreateGroupMailbox.ToString(),
                fullObjectName,
                primarySmtpAddress,
                firstName,
                lastName,
                samAccountName,
                targetOu,
                "false",
                managedBy,
                fullAccessMembers,
                newPrimaryEmailAddress,
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };
            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.CreateGroupMailboxColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 104);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError(
                        $"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 105);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 10. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 106);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                var managedByDistinguishedName = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(g => g.SamAccountName == managedBy.Replace("[ADD]", " "));

                // 11. Neues Account-Objekt für das Gruppenpostfach erstellen
                var sharedMailbox = new Models.Account
                {
                    PrivisioningActionType = ExecutableAction.CreateGroupMailbox.ToString(),
                    DisplayName = fullObjectName,
                    SurName = lastName,
                    GivenName = firstName,
                    Name = samAccountName,
                    SamAccountName = samAccountName,
                    DistinguishedName = $"CN={fullObjectName},OU=Group Mailboxes,OU=_Groups,DC=ksbl,DC=local",
                    Manager = managedByDistinguishedName.DistinguishedName,
                    MailNickname = samAccountName,
                    Mail = primarySmtpAddress,
                    ProxyAddresses = $"smtp:{primarySmtpAddress}|SMTP:{newPrimaryEmailAddress}",
                    ExchHideFromAddressLists = false,
                    UserPrincipalName = $"{samAccountName}@{_facadeServices.AppSettingsService.UpnDomain}",
                    EmployeeType = "G",
                    ModifiedBy = userInfo.CurrentUserName,
                    ModifiedOn = DateTime.Now
                };

                // 12. Neues MailboxPermission-Objekt für das Gruppenpostfach erstellen
                var fullAccessMembersList = fullAccessMembers.Split('!')
                    .Select(item => item.Replace("[ADD]", "")) // Entferne den "[ADD]"-Text
                    .Where(trusteeName => !string.IsNullOrWhiteSpace(trusteeName)) // Ignoriere leere Einträge
                    .Select(trusteeName => new MailboxPermission
                    {
                        PrivisioningActionType = ExecutableAction.AddGroupMailboxFmaMembers.ToString(),
                        Name = samAccountName,
                        TrusteeName = trusteeName,
                        TrusteeDomain = _facadeServices.AppSettingsService.NetBiosDomain,
                        AcePermissions = "FullAccess",
                        ModifiedBy = userInfo.CurrentUserName,
                        ModifiedOn = DateTime.Now
                    }).ToList();

                // 13. Alle Account- und MailboxPermission-Objekte in die Datenbank hinzufügen
                _facadeServices.Context.Accounts.Add(sharedMailbox);
                _facadeServices.Context.MailboxPermissions.AddRange(fullAccessMembersList);

                try
                {
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation(
                        $"Das Gruppenpostfach {fullObjectName} mit der E-Mail Adresse {primarySmtpAddress} wurde erfolgreich erstellt", 107);
                    TempData["SuccessMessage"] = $"Das Gruppenpostfach {fullObjectName} mit der E-Mail Adresse {primarySmtpAddress} wurde erfolgreich erstellt.";
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Das Gruppenpostfach {fullObjectName} mit der E-Mail Adresse {primarySmtpAddress} konnte nicht der Datenbank hinzugefügt werden. {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 108);
                    TempData["ErrorMessage"] = alert;
                    ModelState.AddModelError("", alert);
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else
            {
                _facadeServices.EventLogService.LogInformation(
                    $"Das Gruppenpostfach {fullObjectName} mit der E-Mail Adresse {primarySmtpAddress} wurde erfolgreich erstellt.", 109);
                TempData["SuccessMessage"] = $"Das Gruppenpostfach {fullObjectName} mit der E-Mail Adresse {primarySmtpAddress} wurde erfolgreich erstellt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }
        }

        [HttpPost]
        public async Task<IActionResult> ModifyGroupMailboxPermissions(ModifyGroupMailboxPermissionsViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { ModifyGroupMailboxPermissions = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 200);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            var samAccountName = model.GmbModFmaMailboxName?.ToString().ExtractDisplayNameSuffix();

            // 2. Aktuelle Berechtigungen auslesen und Differenzen berechnen
            //var currentPermissions = await _facadeServices.Context.MailboxPermissions
            //    .Where(p => p.Name == model.GmbModFmaMailboxName && p.AcePermissions == "FullAccess")
            //    .Select(p => p.TrusteeName)
            //    .ToListAsync();
            var currentPermissions = await (from mp in _facadeServices.Context.MailboxPermissions
                                                join acc in _facadeServices.Context.Accounts on mp.TrusteeName equals acc.SamAccountName 
                                                where mp.Name == model.GmbModFmaMailboxName 
                                                    && mp.AcePermissions == "FullAccess" 
                                                    && acc.ExtensionAttribute11 != hospisToAdDeleteAttrValue
                                                select mp.TrusteeName
                                            ).Distinct() // optional: Duplikate vermeiden
                                             .ToListAsync();

            // 3. samAccountName-Werte aus model.GmbModFmaPersonsList extrahieren
            var newPermissionsSamAccounts = model.GmbModFmaPersonsList
                .Select(item => item.ExtractDisplayNameSuffix())
                .ToList();
            //var newPermissionsSamAccounts = model.GmbModFmaPersonsList
            //    .Select(item => item.Contains("(") && item.Contains(")")
            //        ? item.Split('(')[1].TrimEnd(')')
            //        : item) // Fallback falls kein `samAccountName` im erwarteten Format vorhanden ist
            //    .ToList();

            // 4. Berechnete Unterschiede zwischen den extrahierten und den aktuellen Berechtigungen
            var permissionsDiff = _facadeServices.ListComparisonService.CompareLists(newPermissionsSamAccounts, currentPermissions);

            // 5. Erstelle den `fullAccessMembers`-String direkt aus den Differenzen
            string fullAccessMembers = string.Join("!", permissionsDiff.Split('!').Select(p => p.Trim()));

            // 6. Filtern von Berechtigungen für Hinzufügen und Entfernen
            var permissionsToAdd = permissionsDiff
                .Split('!')
                .Where(p => p.EndsWith("[ADD]"))
                .Select(p => p.Replace("[ADD]", "").Trim())
                .ToList();

            var permissionsToRemove = permissionsDiff
                .Split('!')
                .Where(p => p.EndsWith("[DEL]"))
                .Select(p => p.Replace("[DEL]", "").Trim())
                .ToList();

            // 7. Schreiben eines Job-Files in die Queue
            var values = new List<string>
            {
                ExecutableAction.AddGroupMailboxFmaMembers.ToString(),
                samAccountName,
                fullAccessMembers,
                model.GmbModFmaSendAs.ToString(),
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };
            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.ModifyGroupMailboxPermissionsColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 201);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError(
                        $"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 202);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 8. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 203);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                // 8. Alle neuen MailboxPermission-Objekte für das Gruppenpostfach hinzufügen
                foreach (var trusteeName in permissionsToAdd)
                {
                    var mailboxPermission = new MailboxPermission
                    {
                        PrivisioningActionType = ExecutableAction.AddGroupMailboxFmaMembers.ToString(),
                        Name = samAccountName,
                        TrusteeName = trusteeName,
                        TrusteeDomain = _facadeServices.AppSettingsService.NetBiosDomain,
                        AcePermissions = "FullAccess",
                        ModifiedBy = $"{userInfo.CurrentUserDomainName}\\{userInfo.CurrentUserName}",
                        ModifiedOn = DateTime.Now
                    };
                    _facadeServices.Context.MailboxPermissions.Add(mailboxPermission);

                    //// ➕ History-Eintrag für Add im GroupMailboxesController.cs
                    //_facadeServices.Context.MailboxPermissionsHistory.Add(new MailboxPermissionsHistory
                    //{
                    //    AdReferenceObjectGuid = mailboxEntity.AdReferenceObjectGuid,
                    //    TrusteeReferenceObjectGuid = trusteeEntity.AdReferenceObjectGuid,
                    //    ObjectCategory = "Person",
                    //    AcePermissions = "FullAccess",
                    //    ModificationType = "Add",
                    //    ModifiedBy = userInfo.CurrentUserName.ToLower(),
                    //    ModifiedOn = DateTime.Now
                    //});

                }

                // 9. Alle zu löschenden MailboxPermission-Objekte für das Gruppenpostfach entfernen
                foreach (var trusteeName in permissionsToRemove)
                {
                    var mailboxPermission = await _facadeServices.Context.MailboxPermissions
                        .FirstOrDefaultAsync(p => p.Name == samAccountName && p.TrusteeName == trusteeName && p.AcePermissions.Contains("FullAccess"));

                    if (mailboxPermission != null)
                    {
                        _facadeServices.Context.MailboxPermissions.Remove(mailboxPermission);
                    }
                }

                try
                {
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation(
                        $"Die Berechtigungen auf dem Gruppenpostfach {model.GmbModFmaMailboxName} wurden erfolgreich modifiziert.", 204);
                    TempData["SuccessMessage"] = $"Die Berechtigungen auf dem Gruppenpostfach {model.GmbModFmaMailboxName} wurden erfolgreich modifiziert.";

                    //await RazorViewDataHelper.StoreSingleSelectOptionInTempDataAsync(
                    //    TempData, _facadeServices.Context, "SelectedGroupMailbox", model.GmbModFmaMailboxName, StoreSelectEntityOption.Accounts);

                    //await RazorViewDataHelper.StoreListSelectOptionsInTempDataAsync(
                    //    TempData, _facadeServices.Context, "SelectedMailboxPermissionsList", model.GmbModFmaPersonsList, StoreSelectEntityOption.Accounts);

                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Die Berechtigungen für das Gruppenpostfach {model.GmbModFmaMailboxName} konnten nicht der Datenbank hinzugefügt werden. {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 205);
                    TempData["ErrorMessage"] = alert;
                    ModelState.AddModelError("", alert);
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else 
            {
                _facadeServices.EventLogService.LogInformation(
                    $"Die Berechtigungen auf dem Gruppenpostfach  {model.GmbModFmaMailboxName}  wurden erfolgreich modifiziert.", 204);
                TempData["SuccessMessage"] = $"Die Berechtigungen auf dem Gruppenpostfach {model.GmbModFmaMailboxName} wurden erfolgreich modifiziert.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }
        }

        [HttpPost]
        public async Task<IActionResult> ModifyGroupMailboxResponsible(ModifyGroupMailboxResponsibleViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { ModifyGroupMailboxResponsible = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 300);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            var samAccountName = model.GmbModOwnershipMailboxName?.ToString().ExtractDisplayNameSuffix();
            var selectedItem = model.GmbModOwnershipPersons?.ToString();

            string managerAdObjectName = string.Empty;
            if (string.IsNullOrEmpty(selectedItem))
            {
                _facadeServices.EventLogService.LogWarning(
                    $"Kein gültiger Verantwortlicher für das Gruppenpostfach {model.GmbModOwnershipMailboxName} selektiert.", 301);
                TempData["ErrorMessage"] = "Wenn Sie die Verantwortung eines Gruppenpostfaches modifizieren wollen, dann müssen Sie schon bestimmen, wer verantwortlich sein soll!";
                ModelState.AddModelError("", "Bitte wählen Sie einen gültigen Verantwortlichen aus.");
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }
            else
            {
                managerAdObjectName = model.GmbModOwnershipPersons?.ToString().ExtractDisplayNameSuffix();
            }

            // 7. Schreiben eines Job-Files in die Queue
            var values = new List<string>
            {
                ExecutableAction.ChangeManagerGroupMailbox.ToString(),
                samAccountName,
                managerAdObjectName,
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };
            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.ChangeManagerGroupMailboxColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 302);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError(
                        $"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 303);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 8. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    } catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 304);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                // 9. Finden des zu bearbeitenden Gruppenpostfachs und des neuen Verantwortlichen
                var sharedMailbox = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(p => p.SamAccountName == samAccountName);
                var sharedMailboxManager = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(p => p.SamAccountName == managerAdObjectName);

                if (sharedMailbox == null || sharedMailboxManager == null)
                {
                    TempData["ErrorMessage"] = $"Das ausgewählte Gruppenpostfach {model.GmbModOwnershipMailboxName} oder der Verantwortliche {model.GmbModOwnershipPersons} konnte nicht gefunden werden.";
                    _facadeServices.EventLogService.LogWarning(
                        $"Das Gruppenpostfach {model.GmbModOwnershipMailboxName} oder der Verantwortliche {model.GmbModOwnershipPersons} konnte nicht gefunden werden.", 305);
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 10. Manager-Eigenschaft aktualisieren
                sharedMailbox.Manager = sharedMailboxManager.DistinguishedName;

                // 11. Manager-Eigenschaft speichern
                try
                {
                    await _facadeServices.Context.SaveChangesAsync();
                    TempData["SuccessMessage"] = $"Die Verantwortung für das Gruppenpostfach {model.GmbModOwnershipMailboxName} wurde erfolgreich aktualisiert.";
                    _facadeServices.EventLogService.LogInformation(
                        $"Die Verantwortung auf dem Gruppenpostfach {model.GmbModOwnershipMailboxName} wurden erfolgreich modifiziert.", 306);
                    TempData["SuccessMessage"] = $"Die Verantwortung auf dem Gruppenpostfach {model.GmbModOwnershipMailboxName} wurden erfolgreich modifiziert.";

                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    //return View(ViewPaths.Home.Landing, combinedViewModel);
                }
                catch (Exception ex)
                {
                    string alert = $"Fehler beim Speichern der Änderung an {model.GmbModOwnershipMailboxName}: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 307);
                    TempData["ErrorMessage"] = alert;
                    ModelState.AddModelError("", alert);
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else
            {
                _facadeServices.EventLogService.LogInformation(
                    $"Die Berechtigungen auf dem Gruppenpostfach {model.GmbModOwnershipMailboxName} wurden erfolgreich modifiziert.", 306);
                TempData["SuccessMessage"] = $"Die Berechtigungen auf dem Gruppenpostfach {model.GmbModOwnershipMailboxName} wurden erfolgreich modifiziert.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }
        }

    }
}
