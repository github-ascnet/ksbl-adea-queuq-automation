﻿using Infrastructure.GUI.Web.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System.Runtime.ConstrainedExecution;
using System;
using Infrastructure.GUI.Web.Models;
using Infrastructure.GUI.Web.Utils;
using System.Text.RegularExpressions;

namespace Infrastructure.GUI.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SearchController : ControllerBase
    {
        private readonly KSBL_IAMContext _context;
        private readonly IMemoryCache _cache;
        private readonly SamAccountTracker _samAccountTracker;

        private string hospisToAdDeleteAttrValue = "Hospis2AdDeleted";

        public SearchController(KSBL_IAMContext context, IMemoryCache cache, SamAccountTracker samAccountTracker)
        {
            _context = context;
            _cache = cache;
            _samAccountTracker = samAccountTracker;
        }

        //Durch den In-Memory Caches in ASP.NET Core kann man die Effizienz deines Datenzugriffs erheblich verbessern.
        //Bei Anfragen werden die Daten nun aus dem Cache statt aus der Datenbank geladen, was zu einer schnelleren Antwortzeit führt.
        private async Task<List<T>> GetOrSetCachedDataAsync<T>(string cacheKey, Func<Task<List<T>>> getDataFunc)
        {
            // TEMP: Cache komplett umgehen
            var fresh = await getDataFunc();
            // Optional: Cache trotzdem aktualisieren, falls du die Daten woanders brauchst
            //_cache.Set(cacheKey, fresh, new MemoryCacheEntryOptions { AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5) });
            return fresh;

            //// Überprüfe, ob die Daten im Cache vorhanden sind
            //if (!_cache.TryGetValue(cacheKey, out List<T> cachedData))
            //{
            //    // Nicht im Cache, also ein Datenbank Lookup
            //    cachedData = await getDataFunc();

            //    // Cache-Einstellungen festlegen
            //    var cacheEntryOptions = new MemoryCacheEntryOptions
            //    {
            //        AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5), // 5 Minuten im Cache halten
            //        SlidingExpiration = TimeSpan.FromMinutes(2) // Reset der Cache-Zeit bei jedem Zugriff innerhalb von 2 Minuten
            //    };

            //    // Daten im Cache speichern
            //    _cache.Set(cacheKey, cachedData, cacheEntryOptions);
            //}
            //else
            //{
            //    Console.ForegroundColor = ConsoleColor.Green;
            //    Console.WriteLine($"Data for ${cacheKey} was taken from the In-Memory cache"); 
            //}

            //return cachedData;
        }

        private async Task<string> GetNextAvailableGroupMailboxAliasAsync()
        {
            return await _samAccountTracker.GetNextSamAccountNameAsync("gmb");
        }

        private async Task<string> GetNextAvailableDistributionGroupAliasAsync()
        {
            return await _samAccountTracker.GetNextSamAccountNameAsync("vl");
        }

        private async Task<string> GetNextAvailableInternalUserIdAsync()
        {
            return await _samAccountTracker.GetNextSamAccountNameAsync("us");
        }

        private async Task<string> GetNextAvailableExternalUserIdAsync()
        {
            return await _samAccountTracker.GetNextSamAccountNameAsync("ex");
        }

        [HttpGet("checkSharedAccountForUniqueness")]
        public async Task<IActionResult> CheckSharedAccountForUniqueness(string term)
        {
            if (string.IsNullOrWhiteSpace(term))
            {
                return BadRequest("Query darf nicht leer sein.");
            }

            var match = await _context.Accounts
                .Where(p => p.EmployeeType == "G" && p.DisplayName.ToLower() == term.ToLower())
                .FirstOrDefaultAsync();

            if (match != null)
            {
                return Conflict(new { error = $"Gruppenmailbox {term} existiert bereits!", displayName = match.DisplayName, samAccountName = match.SamAccountName });
            }
            return Ok(new { exists = false });
        }

        [HttpGet("checkDistributionGroupForUniqueness")]
        public async Task<IActionResult> CheckDistributionGroupForUniqueness(string term)
        {
            if (string.IsNullOrWhiteSpace(term))
            {
                return BadRequest("Query darf nicht leer sein.");
            }

            var match = await _context.Groups
                .Where(p => p.Mail != string.Empty && p.DisplayName.ToLower() == term.ToLower())
                .FirstOrDefaultAsync();

            if (match != null)
            {
                return Conflict(new { error = $"Verteilerliste {term} existiert bereits!", displayName = match.DisplayName, samAccountName = match.SamAccountName });
            }
            return Ok(new { exists = false });
        }

        [HttpGet("getGmbAlias")]
        //public async Task<IActionResult> GetGmbAliasByLocation(string location)
        public async Task<IActionResult> GetGmbAlias()
        {
            var alias = await GetNextAvailableGroupMailboxAliasAsync();
            return Ok(new { samAccountName = alias }); 
        }

        [HttpGet("getVlAlias")]
        public async Task<IActionResult> GetVlAlias()
        {
            var alias = await GetNextAvailableDistributionGroupAliasAsync();
            return Ok(new { samAccountName = alias });
        }

        [HttpGet("getUserAlias")]
        public async Task<IActionResult> GetUserAlias(string type)
        {
            try
            {
                string alias = type switch
                {
                    "us" => await GetNextAvailableInternalUserIdAsync(),
                    "ex" => await GetNextAvailableExternalUserIdAsync(),
                    _ => throw new ArgumentException("Invalid user type")
                };

                return Ok(alias);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("The specified domain either does not exist or could not be contacted"))
                {
                    return StatusCode(503, new { error = ex.Message }); // Service unavailable
                }

                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("validateMailAliasUniqueness")]
        public async Task<IActionResult> ValidateMailAliasUniqueness([FromQuery] string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                return BadRequest(new { error = "E-Mail-Adresse darf nicht leer sein." });
            }

            string lowerEmail = email.ToLowerInvariant();

            // Füge das smtp: Präfix hinzu, wie es in ProxyAddresses gespeichert ist
            string proxyAddress = $"smtp:{lowerEmail}";

            // Suche über DataContext
            var matchingAccounts = await _context.ValidateEMailByMailAliasAsync(proxyAddress);

            if (matchingAccounts == null || matchingAccounts.Count == 0)
            {
                return Ok(new { exists = false });
            }

            var account = matchingAccounts.First();
            return Ok(new
            {
                exists = true,
                displayName = account.DisplayName,
                windowsUserId = account.SamAccountName,
                mail = account.Mail,
                mailAlias = lowerEmail
            });
        }

        [HttpGet("getActivePersonAccountsWithMailbox")]
        public async Task<IActionResult> GetActivePersonAccountsWithMailbox(string term)
        {
            if (string.IsNullOrWhiteSpace(term))
            {
                return Ok(new List<SelectListItem>());
            }

            // Überprüfe, ob die Daten im Cache vorhanden sind
            var activePersonAccountsWithMailbox = 
                await GetOrSetCachedDataAsync("ActivePersonAccountsWithMailbox", () => _context.GetAllActivePersonAccountsWithMailboxAsync());

            // Filtere die Ergebnisse basierend auf dem Suchbegriff
            var results = activePersonAccountsWithMailbox
                .Where(a => (!string.IsNullOrEmpty(a.DisplayName) && a.DisplayName.Contains(term, StringComparison.OrdinalIgnoreCase)) ||
                            //(!string.IsNullOrEmpty(a.EmployeeId) && a.EmployeeId.Contains(term, StringComparison.OrdinalIgnoreCase)) ||
                            (!string.IsNullOrEmpty(a.SamAccountName) && a.SamAccountName.Contains(term, StringComparison.OrdinalIgnoreCase)))
                .Select(a => new SelectListItem
                {
                    Value = a.SamAccountName,
                    Text = $"{a.DisplayName} ({a.SamAccountName})"
                })
                .ToList();

            return Ok(results);
        }

        [HttpGet("getAllSharedAccountsWithMailbox")]
        public async Task<IActionResult> GetAllSharedAccountsWithMailbox(string term)
        {
            if (string.IsNullOrWhiteSpace(term))
            {
                return Ok(new List<SelectListItem>());
            }

            // Überprüfe, ob die Daten im Cache vorhanden sind
            var sharedAccountsWithMailbox = 
                await GetOrSetCachedDataAsync("SharedAccountsWithMailbox", () => _context.GetAllSharedAccountsWithMailboxAsync());

            // Filtere die Ergebnisse basierend auf dem Suchbegriff
            var results = sharedAccountsWithMailbox
                .Where(a => (!string.IsNullOrEmpty(a.DisplayName) && a.DisplayName.Contains(term, StringComparison.OrdinalIgnoreCase)) ||
                            (!string.IsNullOrEmpty(a.SamAccountName) && a.SamAccountName.Contains(term, StringComparison.OrdinalIgnoreCase)))
                .Select(a => new SelectListItem
                {
                    Value = a.SamAccountName,
                    Text = $"{a.DisplayName} ({a.SamAccountName})"
                })
                .ToList();

            return Ok(results);
        }

        [HttpGet("getAllPersonAccounts")]
        public async Task<IActionResult> GetAllPersonAccounts(string term)
        {
            if (string.IsNullOrWhiteSpace(term))
            {
                return Ok(new List<SelectListItem>());
            }

            // Überprüfe, ob die Daten im Cache vorhanden sind
            var allPersonAccounts =
                await GetOrSetCachedDataAsync("AllPersonAccounts", () => _context.GetAllPersonAccountsAsync());

            // Filtere die Ergebnisse basierend auf dem Suchbegriff
            var results = allPersonAccounts
                .Where(a => (!string.IsNullOrEmpty(a.DisplayName) && a.DisplayName.Contains(term, StringComparison.OrdinalIgnoreCase)) ||
                            (!string.IsNullOrEmpty(a.SamAccountName) && a.SamAccountName.Contains(term, StringComparison.OrdinalIgnoreCase)))
                .Select(a => new SelectListItem
                {
                    Value = a.SamAccountName,
                    Text = $"{a.DisplayName} ({a.SamAccountName})"
                })
                .ToList();

            return Ok(results);
        }

        [HttpGet("getAllPersonAccountsHavingValidWindowsLogin")]
        public async Task<IActionResult> GetAllPersonAccountsHavingValidWindowsLogin(string term)
        {
            if (string.IsNullOrWhiteSpace(term))
            {
                return Ok(new List<SelectListItem>());
            }

            // Überprüfe, ob die Daten im Cache vorhanden sind
            var allPersonAccountsHavingValidWindowsLogin =
                await GetOrSetCachedDataAsync("AllPersonAccountsHavingValidWindowsLogin", () => _context.GetAllPersonAccountsHavingValidWindowsLoginAsync());

            // Filtere die Ergebnisse basierend auf dem Suchbegriff
            var results = allPersonAccountsHavingValidWindowsLogin
                .Where(a => (!string.IsNullOrEmpty(a.Vor_Nachname) && a.Vor_Nachname.Contains(term, StringComparison.OrdinalIgnoreCase)) ||
                            (!string.IsNullOrEmpty(a.WindowsLogin) && a.WindowsLogin.Contains(term, StringComparison.OrdinalIgnoreCase)))
                .Where(a => string.IsNullOrEmpty(a.WindowsLogin) || !a.WindowsLogin.StartsWith("adm", StringComparison.OrdinalIgnoreCase)) // Schließe 'adm*' WindowsLogins aus
                .Select(a => new SelectListItem
                {
                    Value = a.WindowsLogin,
                    Text = $"{a.Vor_Nachname} ({a.WindowsLogin})"
                })
                .ToList();

            return Ok(results);
        }

        [HttpGet("getAllPersonAccountsHavingValidPersId")]
        public async Task<IActionResult> GetAllPersonAccountsHavingValidPersId(string term, string clientType)
        {
            if (string.IsNullOrWhiteSpace(term))
            {
                return BadRequest("Ungültiger Mandant.");
            }

            // Überprüfe, ob die Daten im Cache vorhanden sind
            var personAccountsHavingValidPersId =
                await GetOrSetCachedDataAsync("PersonAccountsHavingValidPersId", () => _context.GetAllPersonAccountsHavingValidPersIdAsync(clientType));

            var blacklist = new[]
            {
                "/", "&", "Admin", "AEMP", "Alpha", "Augenzentrum", "Bäckerei", "Gesundheitszentrum", 
                "Hospital", "Kurier", "Besucher", "Badge", "Bestattungen",
                "Dienstfahrzeug", "Expert", "Extern", "Fremdfirmen", "Gästekarte", "Notfall",
                "Miba", "Mobimed", "Parkkarte", "Personal", "Post CH Logistik Services",
                "Hospitation Radiologie", "swiss med services basel", "Schnupper", "Transport",
                "Test", "Zutritt"
            };
            var digitRegex = new Regex(@"\d", RegexOptions.Compiled);

            var results = personAccountsHavingValidPersId
                    .Where(a => (!string.IsNullOrEmpty(a.Vor_Nachname) && a.Vor_Nachname.Contains(term, StringComparison.OrdinalIgnoreCase)) ||
                                (!string.IsNullOrEmpty(a.Personalnummer) && a.Personalnummer.Contains(term, StringComparison.OrdinalIgnoreCase)))
                    .Where(a => string.IsNullOrEmpty(a.WindowsLogin) || !a.WindowsLogin.StartsWith("adm", StringComparison.OrdinalIgnoreCase))
                    .Where(a =>
                        clientType != "M2" || // wenn nicht M2 → alles ok
                        (
                            !digitRegex.IsMatch(a.Vor_Nachname ?? "") && // keine Ziffern
                            !blacklist.Any(b => (a.Vor_Nachname ?? "").Contains(b, StringComparison.OrdinalIgnoreCase)) // keine Blacklist-Begriffe
                        )
                    )
                    .Select(a => new SelectListItem
                    {
                        //Value = a.Vor_Nachname,
                        //Text = $"{a.Vor_Nachname} ({a.Personalnummer})"
                        Value = a.Personalnummer,
                        Text = $"{a.Vor_Nachname} ({a.Personalnummer})"
                    })
                    .ToList();
            // Filtere die Ergebnisse basierend auf dem Suchbegriff
            //var results = personAccountsHavingValidPersId
            //    .Where(a => (!string.IsNullOrEmpty(a.Vor_Nachname) && a.Vor_Nachname.Contains(term, StringComparison.OrdinalIgnoreCase)) ||
            //                (!string.IsNullOrEmpty(a.Personalnummer) && a.Personalnummer.Contains(term, StringComparison.OrdinalIgnoreCase)))
            //    .Where(a => string.IsNullOrEmpty(a.WindowsLogin) || !a.WindowsLogin.StartsWith("adm", StringComparison.OrdinalIgnoreCase)) // Schließe 'adm*' WindowsLogins aus
            //    .Select(a => new SelectListItem
            //    {
            //        Value = a.Vor_Nachname,
            //        Text = $"{a.Vor_Nachname} ({a.Personalnummer})"
            //    })
            //    .ToList();

            return Ok(results);
        }

        [HttpGet("getSinglePersonByWindowsId")]
        public async Task<IActionResult> GetSinglePersonByWindowsId(string windowsId)
        {
            if (string.IsNullOrWhiteSpace(windowsId))
            {
                return BadRequest("Invalid request");
            }

            var account = await _context.GetSinglePersonByWindowsIdAsync(windowsId);

            if (account == null || !account.Any())
            {
                return NotFound("Person not found");
            }

            var result = account.Select(p => new
            {
                PersId = p.Personalnummer,
                WindowsUserId = p.WindowsLogin,
                SurName = p.Vorname,
                GivenName = p.Nachname,
                FullName = p.Vor_Nachname,
                Title = p.Tätigkeit,
                Department = p.Organisationseinheit,
                Location = p.Standort,
                WindowsAccountState = p.WindowsAccountState,
                WindowsLastLogin = p.WindowsLastLogin,
                WindowsPwdLastChanged = p.WindowsPwdLastChanged,
                WindowsAccountExpires = p.WindowsAccountExpires,
                WindowsExtAttrib11 = p.WindowsExtAttrib11,
                JoinerDate = p.Eintrittsdatum,
                LeaverDate = p.Austrittsdatum,
                Birthday = p.Geburtsdatum,
                EmployeeClientType = p.MitarbeiterTyp
            }).FirstOrDefault();

            return Ok(result);
        }

        [HttpGet("getSinglePersonByPersId")]
        public async Task<IActionResult> GetSinglePersonByPersId(string persId)
        {
            if (string.IsNullOrWhiteSpace(persId))
            {
                return BadRequest("Invalid request");
            }

            var person = await _context.GetSinglePersonByPersIdAsync(persId);

            if (person == null || !person.Any())
            {
                return NotFound("Person not found");
            }

            var result = person.Select(p => new
            {
                PersId = p.Personalnummer,
                WindowsUserId = p.WindowsLogin,
                SurName = p.Vorname,
                GivenName = p.Nachname,
                FullName = p.Vor_Nachname,
                Title = p.Tätigkeit,
                Department = p.Organisationseinheit,
                Location = p.Standort,
                WindowsAccountState = p.WindowsAccountState,
                WindowsLastLogin = p.WindowsLastLogin,
                WindowsPwdLastChanged = p.WindowsPwdLastChanged,
                WindowsAccountExpires = p.WindowsAccountExpires,
                WindowsExtAttrib11 = p.WindowsExtAttrib11,
                JoinerDate = p.Eintrittsdatum,
                LeaverDate = p.Austrittsdatum,
                Birthday = p.Geburtsdatum,
                EmployeeClientType = p.MitarbeiterTyp
            }).FirstOrDefault();

            return Ok(result);
        }

        [HttpGet("getSinglePersonHistoryByNamePersId")]
        public async Task<IActionResult> GetSinglePersonHistoryByNamePersId(string persId)
        {
            if (string.IsNullOrWhiteSpace(persId))
            {
                return BadRequest("Invalid request");
            }

            var person = await _context.GetSinglePersonHistoryByNamePersIdAsync(persId);

            if (person == null || !person.Any())
            {
                return NotFound("User not found");
            }

            var result = person.Select(p => new
            {
                Personalnummer = p.Personalnummer,
                Mitarbeiterstatus = p.Mitarbeiterstatus,
                Eintrittsdatum = p.Eintrittsdatum,
                Austrittsdatum = p.Austrittsdatum,
            }).OrderByDescending(p => p.Eintrittsdatum).ToList(); 
            
            return Ok(result);
        }

        [HttpGet("getAdUserAttributes")]
        public async Task<IActionResult> GetUserAttributes(string samAccountName)
        {
            if (string.IsNullOrWhiteSpace(samAccountName))
            {
                return BadRequest("Invalid request");
            }

            var user = await _context.GetSinglePersonAccountsWithMailboxBySamAccNameAsync(samAccountName);

            if (user == null || !user.Any())
            {
                return NotFound("User not found");
            }

            var result = user.Select(u => new
            {
                SamAccountName = u.SamAccountName,
                SurName = u.SurName,
                GivenName = u.GivenName,
                Mail = u.Mail.ToLower(),
                UserAccountControl = u.UserAccountControl,
                SmsPasscodeMobile = u.SmsPasscodeMobile,
                EmployeeType = u.EmployeeType,
                ExtensionAttribute8 = u.ExtensionAttribute8
            }).FirstOrDefault();

            return Ok(result);
        }

        [HttpGet("getMailboxPermissionList")]
        public async Task<IActionResult> GetMailboxPermissionList(string parent)
        {
            if (string.IsNullOrWhiteSpace(parent))
            {
                return BadRequest("Ungültiger Postfach Name.");
            }

            var results = await (from p in _context.MailboxPermissions
                                 join c in _context.Accounts on p.TrusteeName equals c.SamAccountName
                                 where p.Name == parent
                                    && c.ExtensionAttribute11 != hospisToAdDeleteAttrValue
                                    && p.AcePermissions.Contains("FullAccess")
                                 select new Models.Account
                                 {  
                                     DisplayName = c.DisplayName,
                                     SamAccountName = c.SamAccountName
                                 }).ToListAsync();

            return Ok(results);
        }

        [HttpGet("getDistributionGroups")]
        public async Task<IActionResult> GetDistributionGroups(string term)
        {
            if (string.IsNullOrWhiteSpace(term))
            {
                return Ok(new List<SelectListItem>());
            }

            // Überprüfe, ob die Daten im Cache vorhanden sind
            var distributionGroups =
                await GetOrSetCachedDataAsync("DistributionGroups", () => _context.GetAllDistributionGroupsAsync());

            var results = distributionGroups
                .Where(g => g.DisplayName.Contains(term, StringComparison.OrdinalIgnoreCase))
                .Select(g => new SelectListItem
                {
                    Value = g.SamAccountName,
                    Text = g.DisplayName
                })
                .ToList();

            return Ok(results);
        }

        [HttpGet("getDistributionGroupResponsibleList")]
        public async Task<IActionResult> GetDistributionGroupResponsibleList(string parent)
        {
            if (string.IsNullOrWhiteSpace(parent))
            {
                return BadRequest("Ungültiger Verteilerlisten Name.");
            }

            var results = await (from p in _context.ManagersToGroups
                                 join a in _context.Accounts on p.AccountsId equals a.Id
                                 join g in _context.Groups on p.GroupsId equals g.Id
                                 where g.SamAccountName == parent
                                       && a.ExtensionAttribute11 != hospisToAdDeleteAttrValue
                                 select new Models.Account
                                 {
                                     DisplayName = a.DisplayName,
                                     SamAccountName = a.SamAccountName
                                 }).ToListAsync(); 

            return Ok(results);
        }

        [HttpGet("getAllHospisDepartments")]
        public async Task<IActionResult> GetAllHospisDepartments(string term)
        {
            if (string.IsNullOrWhiteSpace(term))
            {
                return Ok(new List<SelectListItem>());
            }

           // Überprüfe, ob die Daten im Cache vorhanden sind
           var hospisDepartments =
               await GetOrSetCachedDataAsync("HospisDepartments", () => _context.GetAllHospisDepartmentsAsync());
            //var hospisDepartments = await _context.GetAllHospisDepartmentsAsync();
            var results = hospisDepartments
                .Where(g => g.DepartmentName.Contains(term, StringComparison.OrdinalIgnoreCase))
                .Select(g => new SelectListItem
                {
                    Value = g.DepartmentName,
                    Text = g.DepartmentName
                })
                .ToList();

            return Ok(results);
        }

        [HttpGet("getAllActiveExternalAndItPersonAccounts")]
        public async Task<IActionResult> GetAllActiveExternalAndItPersonAccounts(string term)
        {
            if (string.IsNullOrWhiteSpace(term))
            {
                return Ok(new List<SelectListItem>());
            }

            // Überprüfe, ob die Daten im Cache vorhanden sind
            var allActiveExternalAndItPersonAccounts =
                await GetOrSetCachedDataAsync("AllActiveExternalAndItPersonAccounts", () => _context.GetAllActiveExternalAndItPersonAccountsAsync());

            var results = allActiveExternalAndItPersonAccounts
                .Where(a => (!string.IsNullOrEmpty(a.DisplayName) && a.DisplayName.Contains(term, StringComparison.OrdinalIgnoreCase)) ||
                            (!string.IsNullOrEmpty(a.SamAccountName) && a.SamAccountName.Contains(term, StringComparison.OrdinalIgnoreCase)))
                .Select(a => new SelectListItem
                {
                    Value = a.SamAccountName,
                    Text = $"{a.DisplayName} ({a.SamAccountName})"
                })
                .ToList();

            return Ok(results);
        }

        [HttpGet("getExistingAdminAccount")]
        public async Task<IActionResult> GetExistingAdminAccount(string samAccountName)
        {
            if (string.IsNullOrEmpty(samAccountName))
            {
                return BadRequest("SamAccountName is required.");
            }

            var existingAdminAccount = await _context.GetExistingAdminAccountAsync(samAccountName);

            if (existingAdminAccount == null)
            {
                return NotFound("Admin account not found.");
            }

            return Ok(existingAdminAccount);
        }

        [HttpGet("checkAccountDuplicatesByClient")]
        public async Task<IActionResult> CheckAccountDuplicatesByClient([FromQuery] string identity, [FromQuery] EnterpriseClientType clientType)
        {
            if (string.IsNullOrWhiteSpace(identity))
            {
                return BadRequest(new { error = "Die Identität darf nicht leer sein." });
            }

            var accounts = _context.Accounts.AsQueryable();
            var persons = _context.Persons.AsQueryable();

            var duplicates = await DuplicateAccountHelper.FindDuplicateAccountsAsync(accounts, persons, identity, clientType);

            if (duplicates == null || duplicates.Count == 0)
            {
                return Ok(new { hasDuplicates = false });
            }

            return Ok(new
            {
                hasDuplicates = true,
                count = duplicates.Count,
                entries = duplicates
            });
        }
    }
}
