﻿using Infrastructure.GUI.Web.Data;
using Infrastructure.GUI.Web.Models;
using Infrastructure.GUI.Web.Utils;
using Infrastructure.GUI.Web.Views;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Runtime.ConstrainedExecution;

namespace Infrastructure.GUI.Web.Controllers
{
    public class HospisActionsController : Controller
    {
        private readonly ControllerServicesFacade _facadeServices;

        public HospisActionsController(ControllerServicesFacade facadeServices)
        {
            _facadeServices = facadeServices;
        }

        // Action für Hospis-Benutzeraktionen
        [HttpPost]
        public async Task<IActionResult> HospisUserAction(HospisUserActionViewModel model)
        {
            var combinedViewModel = new CombinedViewModel { HospisUserAction = model }.WithTabAndSection(model);

            if (!ModelState.IsValid)
            {
                var modelErrors = ModelState.EnumerateModelStateErrors();
                var fullMessage = model.FormatValidationLogMessage(ModelState);
                _facadeServices.EventLogService.LogWarning(fullMessage, 1700);
                TempData["ErrorMessage"] = $"Die übermittelten Daten sind ungültig: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            if (!_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                TempData["SuccessMessage"] = $"Die Ausführung wurde erfolgreich durchgeführt.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            // 1. Die Infos über den aktuellen Auftraggeber abrufen und speichern
            var userInfo = await _facadeServices.UserInfoService.GetCurrentUserInfo();
            userInfo.CurrentUserEMailAddress = userInfo.CurrentUserEMailAddress.WithFallback(_facadeServices.AppSettingsService.DefaultRecipientAddress);
            ViewBag.UserEmail = userInfo.CurrentUserEMailAddress;

            var persId = model.HospisPersId; //HospisPersonName?.ToString().ExtractDisplayNameSuffix();
            var person = await _facadeServices.Context.GetSinglePersonByPersIdAsync(persId);

            if (person == null || !person.Any())
            {
                _facadeServices.EventLogService.LogWarning($"Die Person {model.HospisPersonName} konnte nicht gefunden werden.", 1701);
                TempData["ErrorMessage"] = $"Die Person {model.HospisPersonName} konnte nicht gefunden werden.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }

            var personDetails = person.FirstOrDefault();
            string title = personDetails.Tätigkeit;
            string AdObjectName = personDetails.WindowsLogin;
            string locationName = personDetails.Standort;
            string adRefUserName = model.HospisReferencingUser?.ToString().ExtractDisplayNameSuffix();
            string adRefUserDomain = _facadeServices.AppSettingsService.LdapDomain;

            string LdapSearchPersId = string.Empty;
            string employeeClientType = string.Empty;
            if (!string.IsNullOrWhiteSpace(model.SelectedDuplicateSamAccountName) && model.SelectedDuplicateSamAccountName != "__new")
            {
                Console.WriteLine($"⚠️ Duplikat wurde manuell ausgewählt: {model.SelectedDuplicateSamAccountName}");
                var match = await _facadeServices.Context.Accounts.FirstOrDefaultAsync(a => a.SamAccountName == model.SelectedDuplicateSamAccountName);

                if (match != null)
                {
                    employeeClientType = match.EmployeeId.GetEmployeeClientType();
                    if (employeeClientType == "M2") // nur bei M2 übernehmen
                    {
                        LdapSearchPersId = match.EmployeeId;
                    }
                }
            }

            ExecutableAction hospisUseCase;
            if (employeeClientType == "M2" && !string.IsNullOrEmpty(LdapSearchPersId))
            {
                // M2 → immer ÜbertrittM1
                hospisUseCase = ExecutableAction.UebertrittM1;
            }
            else
            {
                // Normale Logik
                hospisUseCase = model.HospisAction.ToString() switch
                {
                    nameof(HospisUseCase.ERSTELLEN) => ExecutableAction.Erstellen,
                    nameof(HospisUseCase.AKTIVIEREN) => ExecutableAction.Aktivieren,
                    nameof(HospisUseCase.INAKTIVIEREN) => ExecutableAction.Inaktivieren,
                    nameof(HospisUseCase.STANDORTWECHSEL) => ExecutableAction.Standortwechsel,
                    _ => ExecutableAction.Unknown
                };
            }

            var values = new List<string>
            {
                hospisUseCase.ToString(),
                persId,
                LdapSearchPersId,
                AdObjectName,
                model.HospisFullName.ToString(),
                adRefUserName,
                adRefUserDomain,
                locationName,
                "False",
                userInfo.CurrentUserName,
                userInfo.CurrentUserDomainName,
                userInfo.CurrentUserEMailAddress
            };

            string IamQueueFileContent = string.Join("|", QueueFileColumnHeaders.HospisUserActionColumns) + "\r\n" + string.Join("|", values);
            _facadeServices.EventLogService.LogInformation($"Das Queue File sieht wie folgt aus:\n\n {IamQueueFileContent}", 1702);

            if (_facadeServices.AppSettingsService.ApplyChangesToBackgroundSystems)
            {
                string result = model.HospisUrgent == true 
                    ? await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent, true, true)
                    : await _facadeServices.IamQueueService.CreateIamQueueFileAsync(IamQueueFileContent, true, false);

                if (result != "success")
                {
                    _facadeServices.EventLogService.LogError($"Beim anlegen des Queue Files ist ein Fehler aufgetreten: {result}", 1703);
                    TempData["ErrorMessage"] = $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}";
                    ModelState.AddModelError("", $"Ein Fehler beim anlegen des Job ist aufgetreten: {result}");
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                // 2. Ausführen des Jobs über die Powershell, so dass die Mutation in AD/Exchange ausgeführt wird
                if (_facadeServices.AppSettingsService.ExecuteJobsImmediately
                    && Environment.UserDomainName == _facadeServices.AppSettingsService.NetBiosDomain)
                {
                    try
                    {
                        await _facadeServices.PowerShellRemoteExecService.RunScriptAsync("path/to/your/script.ps1");
                    }
                    catch (Exception ex)
                    {
                        _facadeServices.EventLogService.LogError(
                            $"Beim ausführen des Powershell Jobs ist ein Fehler aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}", 1704);
                        TempData["ErrorMessage"] = $"Ein Fehler beim Ausführen des Job ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                        ModelState.AddModelError("", $"Ein Fehler beim Ausführen des Jobs ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}");
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                    }
                }

                string newSamAccountName = string.Empty;
                string message = string.Empty;
                switch (model.HospisAction.ToString().Trim())
                {
                    case "ERSTELLEN":

                        newSamAccountName = (await _facadeServices.SamAccountTracker.GetNextSamAccountNameAsync("us"));
                        personDetails.WindowsLogin = newSamAccountName;
                        personDetails.WindowsAccountState = "NORMAL_ACCOUNT";
                        message = $"Der Benutzer {model.HospisPersonName} wurde erfolgreich erstellt.";
                        break;

                    case "AKTIVIEREN":
                        personDetails.WindowsAccountState = "NORMAL_ACCOUNT";
                        message = $"Der Benutzer {model.HospisPersonName} wurde erfolgreich aktiviert.";
                        break;

                    case "INAKTIVIEREN":
                        personDetails.WindowsAccountState = "ACCOUNTDISABLE NORMAL_ACCOUNT";
                        message = $"Der Benutzer {model.HospisPersonName} wurde erfolgreich inaktiviert.";
                        break;

                    default:
                        TempData["ErrorMessage"] = "Ungültige Aktion ausgewählt.";
                        return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }

                try { 
                    await _facadeServices.Context.SaveChangesAsync();
                    _facadeServices.EventLogService.LogInformation(message, 1705);
                    TempData["SuccessMessage"] = message;
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
                catch (Exception ex)
                {
                    string alert = $"Ein unbekannter Fehler ist aufgetreten: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                    _facadeServices.EventLogService.LogError(alert, 1706);
                    TempData["ErrorMessage"] = alert;
                    return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
                }
            }
            else
            {
                _facadeServices.EventLogService.LogInformation($"Der Benutzer { model.HospisPersonName} wurde erfolgreich erstellt/aktiviert/inaktiviert.", 1705);
                TempData["SuccessMessage"] = $"Der Benutzer { model.HospisPersonName} wurde erfolgreich erstellt/aktiviert/inaktiviert.";
                return RedirectToAction("Landing", "Home", new {tab = combinedViewModel.ActiveTab, section = combinedViewModel.ActiveSection });
            }
        }

        //// Action für das Verlängern eines inaktiven Benutzers
        //[HttpPost]
        //public async Task<IActionResult> ExtendInactiveUser(ExtendInactiveUserViewModel model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return View("ExtendInactiveUser", model);
        //    }

        //    // Hier die Logik für das Verlängern eines inaktiven Benutzers einfügen

        //                        return View(ViewPaths.Home.Landing, combinedViewModel);
        //}
    }
}
