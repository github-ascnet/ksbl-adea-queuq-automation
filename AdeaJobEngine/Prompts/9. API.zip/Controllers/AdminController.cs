﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Infrastructure.GUI.Web.Models;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;
using System.Reflection.PortableExecutable;

namespace Infrastructure.GUI.Web.Controllers
{
    public class AdminController : Controller
    {
        private readonly string directoryPath = @"\\sv00710\d$\iam\archive";
        private readonly IMemoryCache _memoryCache;

        public AdminController(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        [Route("Admin/ShowFileLines")]
        public async Task<IActionResult> ShowFileLines(string searchTerm = null, bool forceRefresh = false)
        {
            if (forceRefresh || !_memoryCache.TryGetValue("RecentFileLines", out List<JobArchiveViewModel> cachedLines))
            {
                Console.WriteLine($"🟢 Cache wird NEU aufgebaut (forceRefresh={forceRefresh}) um {DateTime.Now:yyyy-MM-dd HH:mm:ss}");

                var daysBack = DateTime.Now.AddMonths(-12);

                var files = await Task.Run(() => new DirectoryInfo(directoryPath)
                    .GetFiles("*_pshjob_*.csv")
                    .Where(f => f.LastWriteTime >= daysBack && !f.Name.Contains("CopyUserToUserMemberships", StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(f => f.LastWriteTime)
                    .ToList());

                //var files = await Task.Run(() => new DirectoryInfo(directoryPath)
                //    .GetFiles("*_pshjob_*.csv")
                //    .Where(f => !f.Name.Contains("CopyUserToUserMemberships", StringComparison.OrdinalIgnoreCase))
                //    .OrderByDescending(f => f.LastWriteTime)
                //    .ToList());

                Console.WriteLine($"➡️ {files.Count} Dateien gefunden, werden verarbeitet…");

                var lines = new List<JobArchiveViewModel>();

                foreach (var file in files)
                {
                    Console.WriteLine($"📄 Lese Datei: {file.Name}");

                    var fileLines = await Task.Run(() => System.IO.File.ReadAllLines(file.FullName));
                    if (fileLines.Length < 2)
                    {
                        Console.WriteLine($"⚠️ Datei {file.Name} hat weniger als 2 Zeilen → übersprungen.");
                        continue;
                    }

                    var headers = fileLines[0].Split('|');
                    var values = fileLines[1].Split('|');

                    var actionTypeIndex = Array.IndexOf(headers, "ActionType");
                    var actionType = (actionTypeIndex >= 0 && actionTypeIndex < values.Length) ? values[actionTypeIndex] : "";

                    var emailIndex = Array.IndexOf(headers, "CurrentUserEMailAddress");
                    var email = (emailIndex >= 0 && emailIndex < values.Length) ? values[emailIndex] : "";

                    var keyValuePairs = headers
                        .Select((header, index) => new { header, index })
                        .Where(h => h.header != "CurrentUserName"
                                 && h.header != "CurrentUserDomainName"
                                 && h.header != "CurrentUserEMailAddress"
                        && h.header != "ActionType")  // ActionType jetzt auch raus
                        .Select(h => $"{h.header}={(h.index < values.Length ? values[h.index] : "")}");

                    var summary = string.Join(", ", keyValuePairs);

                    lines.Add(new JobArchiveViewModel
                    {
                        CreatedDate = file.LastWriteTime,
                        ActionType = actionType,
                        CurrentUserEMailAddress = email,
                        LineSummary = summary
                    });
                }

                _memoryCache.Set("RecentFileLines", lines, TimeSpan.FromHours(1));
                _memoryCache.Set("RecentFileLinesTimestamp", DateTime.Now, TimeSpan.FromHours(1));

                Console.WriteLine($"✅ Cache erfolgreich befüllt mit {lines.Count} Zeilen um {DateTime.Now:yyyy-MM-dd HH:mm:ss}");

                cachedLines = lines;
            }
            else
            {
                Console.WriteLine($"🟡 Cache HIT → Daten aus Cache geladen (keine Neubefüllung) um {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            }

            // Timestamp in ViewBag setzen
            _memoryCache.TryGetValue("RecentFileLinesTimestamp", out DateTime lastUpdate);
            ViewBag.LastUpdate = lastUpdate;

            // Optionaler Suchfilter
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                cachedLines = cachedLines
                    .Where(l =>
                        (l.LineSummary != null && l.LineSummary.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)) ||
                        (l.ActionType != null && l.ActionType.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)) ||
                        (l.CurrentUserEMailAddress != null && l.CurrentUserEMailAddress.Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
                    )
                    .ToList();
            }

            return PartialView("_JobArchive", new JobArchiveListViewModel { Lines = cachedLines });
        }

    }
}
