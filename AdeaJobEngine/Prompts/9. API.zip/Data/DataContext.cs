﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Infrastructure.GUI.Web.Models;
using System.Configuration;
using System;
using Infrastructure.GUI.Web.Utils;
using System.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using System.Linq.Expressions;
using Microsoft.Data.SqlClient;
using NuGet.ProjectModel;

namespace Infrastructure.GUI.Web.Data
{
    public class KSBL_IAMContext : DbContext
    {
        private readonly ILoggerFactory _loggerFactory;
        public KSBL_IAMContext(DbContextOptions<KSBL_IAMContext> options, ILoggerFactory loggerFactory)
            : base(options)
        {
            _loggerFactory = loggerFactory;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseLoggerFactory(_loggerFactory).EnableSensitiveDataLogging(); 
        }

        #region DbSets
        public DbSet<Models.Account> Accounts { get; set; }

        public DbSet<ManagersToGroup> ManagersToGroups { get; set; }

        public DbSet<MailboxPermission> MailboxPermissions { get; set; }

        public DbSet<MailboxPermissionsHistory> MailboxPermissionsHistory { get; set; }

        public DbSet<StgAccount> StgAccounts { get; set; }

        public DbSet<AccountsToGroup> AccountsToGroups { get; set; }

        public DbSet<RoleTemplate> RoleTemplates { get; set; }

        public DbSet<Group> Groups { get; set; }

        public DbSet<Models.Configuration> Configurations { get; set; }

        public DbSet<AccountControlState> AccountControlStates { get; set; }

        public DbSet<MailboxFolderPermission> MailboxFolderPermissions { get; set; }

        public DbSet<Person> Persons { get; set; }

        public DbSet<EmployeeType> EmployeeTypes { get; set; }

        public DbSet<PersonsHistory> PersonsHistories { get; set; }

        public DbSet<PersonsDuplicate> PersonsDuplicates { get; set; }

        //public DbSet<VwNextAvailableGmbIdForSamAccName> VwNextAvailableGmbIdForSamAccNames { get; set; }
        //public DbSet<VwNextAvailableVlIdForSamAccName> VwNextAvailableVlIdForMailNickNames { get; set; }
        //public DbSet<VwNextAvailableInternalUserIdForSamAccName> VwNextAvailableInternalUserIdForSamAccName { get; set; }
        //public DbSet<VwNextAvailableExternalUserIdForSamAccName> VwNextAvailableExternalUserIdForSamAccName { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    // Mappen Sie die Datenbank-View auf die neue Entität
        //    modelBuilder.Entity<VwNextAvailableGmbIdForSamAccName>().ToView("vw_next_available_gmb_id_for_sam_acc_name");
        //    modelBuilder.Entity<VwNextAvailableVlIdForSamAccName>().ToView("vw_next_available_vl_id_for_mail_nick_name");
        //    modelBuilder.Entity<VwNextAvailableInternalUserIdForSamAccName>().ToView("vw_next_gap_available_us_id_for_sam_acc_name");
        //    modelBuilder.Entity<VwNextAvailableExternalUserIdForSamAccName>().ToView("vw_next_gap_available_ex_id_for_sam_acc_name");
        //}

        #endregion

        #region DbQueries

        #region Model Queries using multiple generic filters

        public async Task<List<Models.Account>> GetAccountsAsync(
            Func<IQueryable<Account>, IQueryable<Account>> additionalFilters = null,
            bool includeSurName = false,
            bool includeGivenName = false,
            bool includeMail = false,
            bool includeEmployeeId = false,
            bool includeLegacySourceDomain = false,
            bool includeSmsPasscodeMobile = false,
            bool includeUserAccountControl = false,
            bool includeEmployeeType = false,
            bool includeExtensionAttribute8 = false,
            int? take = null)
        {
            // Basisabfrage
            IQueryable<Account> query = from p in Accounts
                                        orderby p.DisplayName ascending
                                        select p;

            // Zusätzliche Filter anwenden, falls vorhanden
            if (additionalFilters != null)
            {
                query = additionalFilters(query);
            }

            // Ergebnis abfragen und in Models.Account konvertieren
            var resultQuery = query
                .Select(p => new Models.Account
                {
                    DisplayName = p.DisplayName,
                    SamAccountName = p.SamAccountName,
                    SurName = includeSurName ? p.SurName : null,
                    GivenName = includeGivenName ? p.GivenName : null,
                    Mail = includeMail ? p.Mail : null,
                    EmployeeId = includeEmployeeId ? p.EmployeeId : null,
                    LegacySourceDomain = includeLegacySourceDomain ? p.LegacySourceDomain : null,
                    SmsPasscodeMobile = includeSmsPasscodeMobile ? p.SmsPasscodeMobile : null,
                    UserAccountControl = includeUserAccountControl ? p.UserAccountControl : null,
                    EmployeeType = includeEmployeeType ? p.EmployeeType : null,
                    ExtensionAttribute8 = includeExtensionAttribute8 ? p.ExtensionAttribute8 : null,
                    Id = p.Id
                });

            // Falls take angegeben ist, die Anzahl der zurückgegebenen Ergebnisse begrenzen
            if (take.HasValue)
            {
                resultQuery = resultQuery.Take(take.Value);
            }

            return await resultQuery.Distinct().ToListAsync();
        }

        public async Task<List<Models.Group>> GetGroupsAsync(
                                        Expression<Func<Models.Group, bool>> filter = null,
                                        Expression<Func<Models.Group, Models.Group>> selector = null)
        {
            // Basisabfrage
            var query = Groups.AsQueryable();

            // Filter anwenden, falls angegeben
            if (filter != null)
            {
                query = query.Where(filter);
            }

            // Projektion anwenden, falls angegeben
            if (selector != null)
            {
                return await query.Select(selector).Distinct().ToListAsync();
            }

            // Wenn kein Selector angegeben ist, gebe alle Ergebnisse zurück
            return await query.Distinct().ToListAsync();
        }

        public async Task<List<Person>> GetPersonsAsync(
            Expression<Func<Person, bool>> filter = null,
            Expression<Func<Person, Person>> selector = null,
            Func<IQueryable<Person>, IOrderedQueryable<Person>> orderBy = null,
            bool distinct = false,
            int? take = null)
        {
            IQueryable<Person> query = Persons;  // Persons ist dein DbSet<Person>

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (orderBy != null)
            {
                query = orderBy(query);
            }

            // Wende den Selector an, falls vorhanden
            var resultQuery = (selector != null) ? query.Select(selector) : query.Select(p => new Person
            {
                Personalnummer = p.Personalnummer,
                WindowsLogin = p.WindowsLogin,
                Nachname = p.Nachname,  
                Vorname = p.Vorname,
                Vor_Nachname = p.Vor_Nachname,
                Tätigkeit = p.Tätigkeit,
                Organisationseinheit = p.Organisationseinheit,
                Standort = p.Standort,
                WindowsAccountState = p.WindowsAccountStateTranslated,
                WindowsLastLogin = p.WindowsLastLogin,
                WindowsPwdLastChanged = p.WindowsPwdLastChanged,
                WindowsAccountExpires = p.WindowsAccountExpires,
                WindowsExtAttrib11 = p.WindowsExtAttrib11,
                Eintrittsdatum = p.Eintrittsdatum,
                Austrittsdatum = p.Austrittsdatum,
                Geburtsdatum = p.Geburtsdatum,
                MitarbeiterTyp = p.MitarbeiterTyp
            });

            if (distinct)
            {
                resultQuery = resultQuery.Distinct();
            }

            if (take.HasValue)
            {
                resultQuery = resultQuery.Take(take.Value);
            }

            return await resultQuery.ToListAsync();
        }

        #endregion

        #region Queries used to fill up dropdownlists during startup in HomeController/Loading

        public async Task<List<Models.Account>> GetAllActivePersonAccountsWithMailboxAsync()
        {
            return await GetAccountsAsync(query => query
                .Where(p => (p.EmployeeType == "P" || p.EmployeeType == "E" || p.EmployeeType == "GU" || p.EmployeeType == "HNP")
                            && !p.UserAccountControl.Contains("ACCOUNTDISABLE")
                            && p.ExtensionAttribute11 != "Hospis2AdDeleted"));
        }

        public async Task<List<Models.Account>> GetAllActiveAccountsWithMailboxAsync()
        {
            return await GetAccountsAsync(query => query
                .Where(p => (p.EmployeeType == "P" || p.EmployeeType.StartsWith("G") || p.EmployeeType == "E" || p.EmployeeType == "S" || p.EmployeeType == "HNP")
                            && !p.UserAccountControl.Contains("ACCOUNTDISABLE")
                            && p.ExtensionAttribute11 != "Hospis2AdDeleted"),
                includeSurName: true, includeGivenName: true);
        }

        public async Task<List<Models.Account>> GetAllSharedAccountsWithMailboxAsync()
        {
            return await GetAccountsAsync(query => query.Where(p => p.EmployeeType.StartsWith("G")));
        }

        public async Task<List<Models.Account>> GetAllPersonAccountsAsync()
        {
            return await GetAccountsAsync(query => query.Where(p => (p.EmployeeType == "P" || p.EmployeeType == "E" || p.EmployeeType == "GU" || p.EmployeeType == "HNP")));
        }

        public async Task<List<Models.Group>> GetAllDistributionGroupsAsync()
        {
            return await GetGroupsAsync(
                filter: p => p.DisplayName.StartsWith("VL-"),
                selector: p => new Models.Group
                {
                    DisplayName = p.DisplayName,
                    SamAccountName = p.SamAccountName
                });
        }

        public async Task<List<EmployeeType>> GetAllEmployeeTypeNamesAsync()
        {
            var query = from p in EmployeeTypes
                        orderby p.SortOrderId ascending
                        select new EmployeeType
                        {
                            EmployeeTypeName = p.EmployeeTypeName,
                            SortOrderId = p.SortOrderId
                        };

            return await query.Distinct().ToListAsync();
        }

        public async Task<List<Department>> GetAllHospisDepartmentsAsync()
        {
            var result = await Accounts
                .Where(p => !string.IsNullOrEmpty(p.Department)) // Sicherstellen, dass Department korrekt ist
                .Select(p => p.Department) // Nutze direkt Department, wenn DepartmentShort nicht vorhanden ist
                .Distinct() // Eindeutige Werte
                .OrderBy(dept => dept) // Sortiere alphabetisch
                .Select(dept => new Department
                {
                    DepartmentName = dept
                })
                .ToListAsync();

            return result;
        }

        public async Task<List<Person>> GetAllPersonAccountsHavingValidPersIdAsync(string clientType)
        {
            return await GetPersonsAsync(
                filter: p => !string.IsNullOrEmpty(p.Personalnummer) && p.MitarbeiterTyp == clientType,
                selector: p => new Person
                {
                    Personalnummer = p.Personalnummer,
                    WindowsLogin = p.WindowsLogin,
                    Vor_Nachname = p.Vor_Nachname,
                    Tätigkeit = p.Tätigkeit,
                    Organisationseinheit = p.Organisationseinheit,
                    Standort = p.Standort,
                    WindowsAccountState = p.WindowsAccountStateTranslated,
                    WindowsLastLogin = p.WindowsLastLogin,
                    WindowsPwdLastChanged = p.WindowsPwdLastChanged,
                    WindowsAccountExpires = p.WindowsAccountExpires,
                    WindowsExtAttrib11 = p.WindowsExtAttrib11,
                    Eintrittsdatum = p.Eintrittsdatum,
                    Austrittsdatum = p.Austrittsdatum
                },
                orderBy: p => p.OrderBy(x => x.Vor_Nachname)
            );
        }

        #endregion


        public async Task<List<Models.Account>> GetAllActiveExternalAndItPersonAccountsAsync()
        {
            return await GetAccountsAsync(
                query => query
                    .Where(p => (p.HrmsFunctionCategory == "Informatik" || p.EmployeeType == "E")
                                && !p.UserAccountControl.Contains("ACCOUNTDISABLE")
                                && !p.DisplayName.Contains("Leistungsrevisor")
                                && !string.IsNullOrEmpty(p.EmployeeId)),
                includeEmployeeId: true);
        }

        public async Task<List<Models.Account>> GetSinglePersonAccountsByEmployeeIdAsync(string employeeId)
        {
            return await GetAccountsAsync(
                query => query.Where(p => p.EmployeeId == employeeId),
                includeSurName: true,
                includeGivenName: true,
                includeMail: true,
                includeEmployeeId: true,
                includeLegacySourceDomain: true,
                includeSmsPasscodeMobile: true,
                includeEmployeeType: true,
                includeExtensionAttribute8: true,
                take: 1);
        }

        public async Task<List<Models.Account>> GetSinglePersonAccountsBySamAccountNameAsync(string adObjectName)
        {
            return await GetAccountsAsync(
                query => query.Where(p => p.SamAccountName == adObjectName),
                includeSurName: true,
                includeGivenName: true,
                includeMail: true,
                includeEmployeeId: true,
                includeLegacySourceDomain: true,
                includeSmsPasscodeMobile: true,
                includeEmployeeType: true,
                includeExtensionAttribute8: true,
                includeUserAccountControl: true,
                take: 1);
        }

        public async Task<List<Models.Account>> ValidateEMailByMailAddressAsync(string primaryMailAddress)
        {
            return await GetAccountsAsync(query => query.Where(p => p.Mail == primaryMailAddress),
                includeMail: true);
        }

        public async Task<List<Models.Account>> ValidateEMailByMailAliasAsync(string mailAlias)
        {
            var accounts = await Accounts
                .Where(p => p.ProxyAddresses != null)
                .ToListAsync(); // Ab hier LINQ to Objects

            return accounts
                .Where(p => p.ProxyAddresses
                    .Split('|', StringSplitOptions.RemoveEmptyEntries)
                    .Any(proxy => proxy.Equals(mailAlias, StringComparison.OrdinalIgnoreCase)))
                .Select(p => new Models.Account
                {
                    DisplayName = p.DisplayName,
                    SamAccountName = p.SamAccountName,
                    Mail = p.Mail
                })
                .ToList();

            //return await GetAccountsAsync(query => query.Where(p => p.ProxyAddresses.Contains(mailAlias)),
            //    includeMail: true);
        }

        public async Task<List<Models.Account>> ValidateUserBySamAccountNameAsync(string adObjectName)
        {
            return await GetAccountsAsync(query => query.Where(p => p.SamAccountName == adObjectName),
                includeSurName: false, includeGivenName: false, includeMail: false, includeEmployeeId: false, includeLegacySourceDomain: false, includeSmsPasscodeMobile: false);
        }

        public async Task<List<Models.Account>> GetAllAccountsWithMailboxByLocationNameAsync(string locationName)
        {
            return await GetAccountsAsync(query => query
                .Where(p => p.City.Contains(locationName)
                            && (p.EmployeeType == "P" || p.EmployeeType == "E" || p.EmployeeType == "GU")
                            && !p.DistinguishedName.EndsWith("OU=Deleted,OU=_Users,DC=ksbl,DC=local")));
        }

        public async Task<List<Models.Account>> GetSinglePersonAccountsWithMailboxBySamAccNameAsync(string adObjectName)
        {
            return await GetAccountsAsync(query => query
                .Where(p => p.SamAccountName == adObjectName),
                includeSurName: true,
                includeGivenName: true,
                includeMail: true,
                includeEmployeeId: true,
                includeLegacySourceDomain: true,
                includeSmsPasscodeMobile: true,
                includeUserAccountControl: true,
                take: 1);
        }

        public async Task<List<Models.Account>> GetSinglePersonAccountsWithMailboxBySamAccNameAndDomainAsync(string adObjectName, string domainName)
        {
            return await GetAccountsAsync(query => query
                .Where(p => p.SamAccountName == adObjectName && p.LegacySourceDomain == domainName),
                includeSurName: true,
                includeGivenName: true,
                includeMail: true,
                includeEmployeeId: true,
                includeLegacySourceDomain: true,
                includeSmsPasscodeMobile: true,
                take: 1);
        }

        public async Task<List<Models.Account>> GetAllPersonAccountsNotDeletedAsync()
        {
            return await GetAccountsAsync(query => query
                .Where(p => (p.EmployeeType == "P" || p.EmployeeType == "E" || p.EmployeeType == "HNP")
                            && !p.DistinguishedName.EndsWith("OU=Deleted,OU=_Users,DC=ksbl,DC=local")),
                includeSurName: true,
                includeGivenName: true);
        }

        public async Task<List<Models.Account>> GetAllPersonAccountsWithMailboxByDomainNameAsync(string domainName)
        {
            return await GetAccountsAsync(query => query
                .Where(p => p.LegacySourceDomain == domainName));
        }

        public async Task<List<Models.Account>> GetSharedMailboxManagerBySamAccountNameAsync(string sharedObjectName)
        {
            return await GetAccountsAsync(query => query
                .Join(Accounts, p => p.Manager, a => a.DistinguishedName, (p, a) => new { p, a })
                .Where(pa => pa.p.SamAccountName == sharedObjectName)
                .Select(pa => pa.a));
        }

        public async Task<List<Person>> GetAllPersonsAsync()
        {
            return await GetPersonsAsync();
        }

        public async Task<List<Person>> GetSinglePersonByPersIdAsync(string persId)
        {
            return await GetPersonsAsync(
                filter: p => p.Personalnummer == persId,
                take: 1 // Begrenze die Ergebnisse auf das erste gefundene Element
            );
        }

        public async Task<List<Person>> GetSinglePersonByWindowsIdAsync(string windowsId)
        {
            return await GetPersonsAsync(
                filter: p => p.WindowsLogin == windowsId && p.WindowsLogin != null, // Filter sicherstellen
                take: 1 // Nur das erste Ergebnis zurückgeben
            );
        }

        public async Task<List<Person>> GetAllPersonAccountsHavingValidWindowsLoginAsync()
        {
            // Verwenden der generischen Methode mit einem spezifischen Filter
            return await GetPersonsAsync(
                filter: p => !string.IsNullOrEmpty(p.Personalnummer) && p.WindowsLogin != null,
                selector: p => new Person
                {
                    Personalnummer = p.Personalnummer,
                    WindowsLogin = p.WindowsLogin,
                    Vor_Nachname = p.Vor_Nachname,
                    Tätigkeit = p.Tätigkeit,
                    Organisationseinheit = p.Organisationseinheit,
                    Standort = p.Standort,
                    WindowsAccountState = p.WindowsAccountStateTranslated,
                    WindowsLastLogin = p.WindowsLastLogin,
                    WindowsPwdLastChanged = p.WindowsPwdLastChanged,
                    WindowsAccountExpires = p.WindowsAccountExpires,
                    WindowsExtAttrib11 = p.WindowsExtAttrib11,
                    Eintrittsdatum = p.Eintrittsdatum,
                    Austrittsdatum = p.Austrittsdatum
                },
                orderBy: p => p.OrderBy(x => x.Vor_Nachname), // Sortierung nach dem Vor- und Nachnamen
                distinct: true // Optional: Eindeutige Ergebnisse
            );
        }

        public async Task<List<PersonsHistory>> GetSinglePersonHistoryByNamePersIdAsync(string persId)
        {
            var query = from p in PersonsHistories
                        where p.Personalnummer == persId
                        select new PersonsHistory
                        {
                            Personalnummer = p.Personalnummer,
                            Mitarbeiterstatus = p.Mitarbeiterstatus,
                            Eintrittsdatum = p.Eintrittsdatum,
                            Austrittsdatum = p.Austrittsdatum,
                        };

            return await query.ToListAsync();;
        }

        public async Task<List<Models.Group>> GetAllGroupsAsync()
        {
            return await GetGroupsAsync(
                filter: p => !p.Name.Contains("TPL-") && p.GroupTypeTranslated != "Domain_Local_Security_Group",
                selector: p => new Models.Group
                {
                    Name = p.Name
                });
        }

        public async Task<List<Models.Group>> GetDomainByGroupNameAsync(string groupName)
        {
            return await GetGroupsAsync(
                filter: p => p.Name == groupName,
                selector: p => new Models.Group
                {
                    LegacySourceDomain = p.LegacySourceDomain
                });
        }

        public async Task<List<Models.Group>> GetDistributionGroupSamAccountNameByDisplayNameAsync(string groupName)
        {
            return await GetGroupsAsync(
                filter: p => p.DisplayName == groupName,
                selector: p => new Models.Group
                {
                    SamAccountName = p.SamAccountName,
                    LegacySourceDomain = p.LegacySourceDomain,
                    Id = p.Id
                });
        }

        public async Task<List<Models.Group>> GetSecurityGroupSamAccountNameByCanonicalNameAsync(string groupName)
        {
            return await GetGroupsAsync(
                filter: p => p.Cn == groupName,
                selector: p => new Models.Group
                {
                    SamAccountName = p.SamAccountName,
                    LegacySourceDomain = p.LegacySourceDomain,
                    Id = p.Id
                });
        }

        public async Task<List<Models.Group>> GetMembersByGroupNameAsync(string groupName)
        {
            var query = from p in AccountsToGroups
                        join c in Accounts on p.AccountsId equals c.Id
                        where p.GroupName == groupName
                        select new Models.Group
                        {
                            Member = p.MemberName,
                            SamAccountName = c.SamAccountName
                        };

            return await query.Distinct().ToListAsync();
        }

        public async Task<List<Models.Group>> GetGroupMembersListDifferencesByUsersAsync(int? sourceUserId, int? targetUserId)
        {
            var query = from p in AccountsToGroups
                        join a in Accounts on p.AccountsId equals a.Id
                        join g in Groups on p.GroupsId equals g.Id
                        where p.AccountsId == sourceUserId
                           && p.MemberCategory == "user"
                           && !AccountsToGroups.Any(t => t.GroupsId == p.GroupsId && t.AccountsId == targetUserId)
                        select new Models.Group
                        {
                            DisplayName = p.GroupName,
                            SamAccountName = g.SamAccountName,
                            Name = g.Name,
                            ExtensionAttribute3 = g.ExtensionAttribute3,
                            Id = g.Id
                        };

            return await query.Distinct().ToListAsync();
        }

        public async Task<List<Models.Account>> GetGroupMembersListDifferencesByGroupsAsync(int? sourceGroupId, int? targetGroupId)
        {
            var query = from s in AccountsToGroups
                        join a in Accounts on s.AccountsId equals a.Id
                        where s.GroupsId == sourceGroupId
                           && !AccountsToGroups.Any(t => s.GroupsId == t.GroupsId && t.GroupsId == targetGroupId)
                        select new Models.Account
                        {
                            DisplayName = a.DisplayName,
                            SamAccountName = a.SamAccountName,
                            MemberCategory = s.MemberCategory,
                            Id = a.Id
                        };

            return await query.Distinct().ToListAsync();
        }

        public async Task<List<Models.Account>> GetGroupMembersListAsync(string groupSamAccountName)
        {
            var query = from p in AccountsToGroups
                        join a in Accounts on p.AccountsId equals a.Id
                        join g in Groups on p.GroupsId equals g.Id
                        where g.SamAccountName == groupSamAccountName
                        select new Models.Account
                        {
                            DisplayName = a.DisplayName,
                            SamAccountName = a.SamAccountName
                        };

            return await query.Distinct().ToListAsync();
        }

        public async Task<List<Models.Account>> GetVlResponsibleListAsync(string vlManagerAdObjectName)
        {
            var query = from p in ManagersToGroups
                        join a in Accounts on p.AccountsId equals a.Id
                        join g in Groups on p.GroupsId equals g.Id
                        where g.SamAccountName == vlManagerAdObjectName
                           && a.ExtensionAttribute11 != "Hospis2AdDeleted"
                        select new Models.Account
                        {
                            DisplayName = a.DisplayName,
                            SamAccountName = a.SamAccountName
                        };

            return await query.Distinct().ToListAsync();
        }

        public async Task<List<RoleTemplate>> GetAllRoleGroupsByLocationAsync(string location)
        {
            var query = from p in RoleTemplates
                        where p.Standort.Contains(location) && p.Template != "N/A"
                        orderby p.Template ascending
                        select new RoleTemplate
                        {
                            Template = p.Template,
                        };

            return await query.Distinct().ToListAsync();
        }

        public async Task<List<MailboxFolderPermission>> GetAllMailboxFolderAceTypesAsync()
        {
            var query = from p in MailboxFolderPermissions
                        orderby p.FolderAce ascending
                        select new MailboxFolderPermission
                        {
                            FolderAce = p.FolderAce
                        };

            return await query.Distinct().ToListAsync();
        }

        public async Task<List<Models.Account>> GetSharedMailboxFMAListAsync(string sharedObjectName)
        {
            var query = from p in MailboxPermissions
                        join c in Accounts on p.TrusteeName equals c.SamAccountName
                        where p.Name == sharedObjectName
                           && c.ExtensionAttribute11 != "Hospis2AdDeleted"
                           && p.AcePermissions.Contains("FullAccess")
                        select new Models.Account
                        {
                            DisplayName = c.DisplayName,
                            SamAccountName = c.SamAccountName
                        };

            return await query.Distinct().ToListAsync();
        }


        public async Task<List<string>> GetNextAvailableSamNameAsync(string prefix)
        {
            // Asynchrone Ausführung der Abfrage und Rückgabe als Liste
            return await this.Set<string>()
                .FromSqlInterpolated($"EXEC usp_next_available_sam_name {prefix}")
                .ToListAsync();
        }

        public async Task<Models.Account> GetExistingAdminAccountAsync(string samAccountName)
        {
            return await Accounts
                .Where(p => p.EmployeeType == "A" && p.ExtensionAttribute8 == samAccountName)
                .FirstOrDefaultAsync();
        }

        #endregion
    }
}
