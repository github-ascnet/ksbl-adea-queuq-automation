﻿namespace Infrastructure.GUI.Web.Utils
{
    public class AppSettingsService
    {
        public string Version { get; set; }
        public string OutputShareName { get; set; }
        public string PrimarySmtpDomain { get; set; }
        public string DistListOrgUnitName { get; set; }
        public string LdapServer { get; set; }
        public string DefaultRecipientAddress { get; set; }
        public string LdapDomain { get; set; }
        public string UpnDomain { get; set; }
        public string NetBiosDomain { get; set; }
        public string UserEnabledGracePeriod { get; set; }
        public string HospisAdUseCases { get; set; }
        public string HospisLocations { get; set; }
        public string RoleITServicedesk { get; set; }
        public string RoleITInfrastructure { get; set; }
        //public string RoleModifyRoleMemberships { get; set; }
        //public string RoleCopyUserToUser { get; set; }
        //public string RoleModifyGroupMemberships { get; set; }
        //public string RoleCreateNewGroupMailbox { get; set; }
        //public string RoleModifyGroupMailboxPermissions { get; set; }
        //public string RoleModifyGroupMailboxResponsible { get; set; }
        //public string RoleModifyDistributionGroupPermissions { get; set; }
        //public string RoleModifyDistributionGroupResponsible { get; set; }
        //public string RoleDeleteDistributionGroup { get; set; }
        //public string RoleCreateNewDistributionGroup { get; set; }
        //public string RoleModifyUserNameChange { get; set; }
        //public string RoleModifyUserAddMailNickname { get; set; }
        //public string RoleChangeMobileNumber { get; set; }
        //public string RoleCreateNewHausarztUser { get; set; }
        //public string RoleCreateNewAdminUser { get; set; }
        //public string RoleCreateNewInternalUser { get; set; }
        //public string RoleCreateNewExternalUser { get; set; }
        //public string RoleCreateNewServiceUser { get; set; }
        //public string RoleCreateNewMultiFunctionalGenericUser { get; set; }
        //public string RoleSubmitTransactions { get; set; }
        public string M2IntOrgUnitName { get; set; }
        public string M2ExtOrgUnitName { get; set; }
        public string GroupMailboxOrgUnitName { get; set; }
        public string MultiFuncGenericOrgUnitName { get; set; }
        public string HnpDefaultDepartment { get; set; }
        public string IamServer { get; set; }
        public string ServiceAccountOrgUnitName { get; set; }
        public string AdminAccountOrgUnitName { get; set; }
        public string ServiceAccountTypes { get; set; }
        public string ManagedServiceAccountOrgUnitName { get; set; }
        public bool ApplyChangesToBackgroundSystems { get; set; }
        public bool ExecuteJobsImmediately { get; set; }
    }
}
