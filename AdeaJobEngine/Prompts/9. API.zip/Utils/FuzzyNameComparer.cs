﻿using System;
using System.Globalization;
using System.Linq;
using System.Text;
using FuzzySharp;

namespace Infrastructure.GUI.Web.Analysis
{
    public static class FuzzyNameComparer
    {
        /// <summary>
        /// Führt einen gewichteten Fuzzy-Vergleich zweier Namen durch und liefert den Ähnlichkeits-Score zurück (0–100).
        /// Optional: Debugausgabe mit Kennzeichnung.
        /// </summary>
        public static int GetFullNameSimilarityScore(
            string fullNameA, string fullNameB, bool useBirthdayBoost = false, string birthdateA = null, string birthdateB = null, bool withDebug = false)
        {
            if (string.IsNullOrWhiteSpace(fullNameA) || string.IsNullOrWhiteSpace(fullNameB))
                return 0;

            string normA = NormalizeFullName(fullNameA);
            string normB = NormalizeFullName(fullNameB);

            int ratio = Fuzz.Ratio(normA, normB);
            int tokenSortRatio = Fuzz.TokenSortRatio(normA, normB);
            int tokenSetRatio = Fuzz.TokenSetRatio(normA, normB);
            int partialRatio = Fuzz.PartialRatio(normA, normB);

            // Basis-Gewichtung
            double baseScore = ratio * 0.25 + tokenSortRatio * 0.25 + tokenSetRatio * 0.4 + partialRatio * 0.1;

            // Bonus bei exakt gleichem Geburtsdatum
            bool birthdateMatch = !string.IsNullOrWhiteSpace(birthdateA) &&
                                  !string.IsNullOrWhiteSpace(birthdateB) &&
                                  NormalizeDate(birthdateA) == NormalizeDate(birthdateB);

            if (useBirthdayBoost && birthdateMatch)
            {
                baseScore = Math.Min(100, baseScore + 10); // Boost durch identisches Geburtsdatum
            }

            int score = (int)Math.Round(baseScore);

            if (withDebug)
            {
                string rating = score == 100 ? "  Sicheres Duplikat"
                              : score >= 95 ? "  Wahrscheinliches Duplikat"
                              : score >= 85 ? "  Mögliches Duplikat"
                              : "  Kein Duplikat";

                Console.WriteLine($"  '{fullNameA}' vs. '{fullNameB}'");
                Console.WriteLine($"     Ratio: {ratio}, TokenSort: {tokenSortRatio}, TokenSet: {tokenSetRatio}, Partial: {partialRatio}");

                // 🎨 Farbe setzen basierend auf Score
                if (score == 100)
                    Console.ForegroundColor = ConsoleColor.Green;
                else if (score >= 95)
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                else if (score >= 85)
                    Console.ForegroundColor = ConsoleColor.Yellow; // Orange-ähnlich
                else
                    Console.ForegroundColor = ConsoleColor.Red;

                Console.WriteLine($"     Score: {score} → {rating}");
                Console.ResetColor();

                Console.WriteLine(new string('-', 60));
            }

            return score;
        }

        private static string NormalizeDate(string date)
        {
            // Erwartet Formate wie: 1984-03-12 oder 12.03.1984
            if (DateTime.TryParse(date, out DateTime dt))
                return dt.ToString("yyyyMMdd"); // Normalisiertes Format

            return date.Trim(); // Falls Parsen nicht möglich
        }

        /// <summary>
        /// Normalisiert einen Namen für Fuzzy-Vergleiche (entfernt Umlaute, Bindestriche, Sonderzeichen, Akzente etc.).
        /// </summary>
        private static string NormalizeFullName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return string.Empty;

            name = name.ToLowerInvariant()
                       .Replace("ä", "ae").Replace("ö", "oe").Replace("ü", "ue")
                       .Replace("ß", "ss")
                       .Replace("-", " ").Replace(".", "").Replace(",", "");

            // Entferne diakritische Zeichen (z. B. è → e)
            string normalized = name.Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder();
            foreach (var c in normalized)
            {
                var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);
                if (unicodeCategory != UnicodeCategory.NonSpacingMark)
                    sb.Append(c);
            }

            return sb.ToString().Normalize(NormalizationForm.FormC).Trim();
        }
    }
}
