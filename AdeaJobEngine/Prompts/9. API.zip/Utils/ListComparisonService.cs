﻿namespace Infrastructure.GUI.Web.Utils
{
    public interface IListComparisonService
    {
        string CompareLists(List<string> newList, List<string> currentList);
    }

    public class ListComparisonService : IListComparisonService
    {
        public string CompareLists(List<string> newList, List<string> currentList)
        {
            return ListComparer.CompareLists(newList, currentList);
        }
    }

    public static class ListComparer
    {
        /// <summary>
        /// Vergleicht zwei Listen und gibt die Unterschiede als "[ADD]!" oder "[DEL]!" zurück.
        /// </summary>
        /// <param name="newList">Die neue Liste, die mit der alten Liste verglichen wird.</param>
        /// <param name="currentList">Die bestehende Liste.</param>
        /// <returns>Eine Zeichenfolge mit den Unterschieden im Format "[ADD]!" oder "[DEL]!"</returns>
        public static string CompareLists(List<string> newList, List<string> currentList)
        {
            // Unterschiede zwischen den neuen und aktuellen Listen berechnen
            IEnumerable<string> addedMembers = newList.Except(currentList);
            IEnumerable<string> removedMembers = currentList.Except(newList);

            string membersToReturn = string.Empty;

            // Hinzugefügte Mitglieder
            foreach (string member in addedMembers)
            {
                membersToReturn += member + "[ADD]!";
            }

            // Entfernte Mitglieder
            foreach (string member in removedMembers)
            {
                membersToReturn += member + "[DEL]!";
            }

            // Rückgabe des Ergebnisses, wenn es Änderungen gibt
            return membersToReturn.Length > 0 ? membersToReturn.TrimEnd('!') : string.Empty;
        }
    }

}
