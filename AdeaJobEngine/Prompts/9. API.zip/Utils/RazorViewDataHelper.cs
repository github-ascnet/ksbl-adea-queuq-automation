﻿using Infrastructure.GUI.Web.Models;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace Infrastructure.GUI.Web.Utils
{
    public enum StoreSelectEntityOption
    {
        Accounts,
        Groups
    }

    public static class RazorViewDataHelper
    {
        public static async Task StoreListSelectOptionsInTempDataAsync(
                ITempDataDictionary tempData,
                DbContext context,
                string tempDataKey,
                IEnumerable<string> samAccountNames,
                StoreSelectEntityOption entityOption)
        {
            List<dynamic> entityItems;

            switch (entityOption)
            {
                case StoreSelectEntityOption.Accounts:
                    entityItems = await context.Set<Account>()
                        .Where(a => samAccountNames.Contains(a.SamAccountName))
                        .Select(a => new { a.DisplayName, a.SamAccountName })
                        .ToListAsync<dynamic>();
                    break;

                case StoreSelectEntityOption.Groups:
                    entityItems = await context.Set<Group>()
                        .Where(g => samAccountNames.Contains(g.SamAccountName))
                        .Select(g => new { g.DisplayName, g.SamAccountName })
                        .ToListAsync<dynamic>();
                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(entityOption), $"Unsupported EntityOption: {entityOption}");
            }

            var options = entityItems.Select(e => new
            {
                Text = $"{(string.IsNullOrEmpty(e.DisplayName) ? e.SamAccountName : e.DisplayName)} ({e.SamAccountName})",
                Value = e.SamAccountName
            }).ToList();

            tempData[tempDataKey] = JsonConvert.SerializeObject(options);
        }

        public static async Task StoreSingleSelectOptionInTempDataAsync(
            ITempDataDictionary tempData,
            DbContext context,
            string tempDataKey,
            string samAccountName,
            StoreSelectEntityOption entityOption)
        {
            string displayName;

            switch (entityOption)
            {
                case StoreSelectEntityOption.Accounts:
                    displayName = await context.Set<Account>()
                        .Where(a => a.SamAccountName == samAccountName)
                        .Select(a => a.DisplayName)
                        .FirstOrDefaultAsync();
                    break;

                case StoreSelectEntityOption.Groups:
                    displayName = await context.Set<Group>()
                        .Where(g => g.SamAccountName == samAccountName)
                        .Select(g => g.DisplayName)
                        .FirstOrDefaultAsync();
                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(entityOption), $"Unsupported EntityOption: {entityOption}");
            }

            displayName ??= samAccountName;
            var option = new[] { new { Text = $"{displayName} ({samAccountName})", Value = samAccountName } };
            tempData[tempDataKey] = JsonConvert.SerializeObject(option);
        }
    }

}
