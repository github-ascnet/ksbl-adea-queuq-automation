﻿using System;
using System.DirectoryServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Infrastructure.GUI.Web.Utils
{
    //public class SamAccountNameBackgroundLoader : IHostedService
    //{
    //    public Task StartAsync(CancellationToken cancellationToken)
    //    {
    //        return SamAccountNameCache.Instance.PreloadAll();
    //    }

    //    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;
    //}

    //public class SamAccountNameCache
    //{
    //    private readonly Dictionary<string, string> _nextAccounts = new();
    //    private readonly SamAccountTracker _tracker = new();
    //    private readonly string[] _prefixes = { "us", "ex", "gmb", "vl" };

    //    private static readonly Lazy<SamAccountNameCache> _instance =
    //        new(() => new SamAccountNameCache());

    //    public static SamAccountNameCache Instance => _instance.Value;

    //    private SamAccountNameCache()
    //    {
    //        Task.Run(() => PreloadAll()).Wait(); // Optional: synchron blockierend beim Startup
    //    }

    //    public string GetNextAccountName(string prefix)
    //    {
    //        if (_nextAccounts.TryGetValue(prefix.ToLower(), out var name))
    //        {
    //            return name;
    //        }

    //        return null; // oder Fallback
    //    }

    //    public async Task RefreshAsync(string prefix)
    //    {
    //        var next = await _tracker.GetNextSamAccountNameAsync(prefix);
    //        _nextAccounts[prefix.ToLower()] = next;
    //    }

    //    public async Task PreloadAll()
    //    {
    //        foreach (var prefix in _prefixes)
    //        {
    //            try
    //            {
    //                var next = await _tracker.GetNextSamAccountNameAsync(prefix);
    //                _nextAccounts[prefix] = next;
    //                Console.WriteLine($"✅ {prefix}: {next}");
    //            }
    //            catch (Exception ex)
    //            {
    //                Console.WriteLine($"❌ Fehler beim Laden von {prefix}: {ex.Message}");
    //            }
    //        }
    //    }
    //}

    public class LDAPConfig
    {
        public string Prefix { get; set; }
        public string LdapFilter { get; set; }

        public LDAPConfig(string prefix)
        {
            Prefix = prefix;

            // ZuluTime auf 12 Monate zurück setzen
            string zuluTime = DateTime.UtcNow.AddMonths(-12).ToString("yyyyMMddHHmmss.0Z");
            LdapFilter = GetLdapFilter(prefix, zuluTime);
        }

        private string GetLdapFilter(string prefix, string zuluTime)
        {
            switch (prefix.ToLower())
            {
                case "us":
                    return $"(&(sAMAccountType=805306368)(sAMAccountName=us*)(!(sAMAccountName=us????))(whenCreated>={zuluTime}))";
                case "ex":
                    return $"(&(sAMAccountType=805306368)(sAMAccountName=ex*)(!(sAMAccountName=ex????))(whenCreated>={zuluTime}))";
                case "gmb":
                    return $"(&(sAMAccountType=805306368)(sAMAccountName=gmb*)(!(sAMAccountName=gmb???))(whenCreated>={zuluTime}))";
                case "vl":
                    return $"(&(grouptype:1.2.840.113556.1.4.803:=-2147483640)(mail=*)(sAMAccountName=vl*)(!(sAMAccountName=vl???))(whenCreated>={zuluTime}))";
                default:
                    throw new ArgumentException("Unbekannter Prefix: " + prefix);
            }
        }
    }

    public class SamAccountTracker : IDisposable
    {
        private bool disposed = false;

        public SamAccountTracker()
        {
        }

        public async Task<string> GetNextSamAccountNameAsync(string prefix)
        {
            var _ldapConfig = new LDAPConfig(prefix);

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            string currentUser = string.Empty;
            try
            {
                currentUser = await GetUserWithHighestSamAccountNameAsync(_ldapConfig.LdapFilter);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return ex.Message;
            }

            string nextUser = string.Empty;
            if (!string.IsNullOrEmpty(currentUser))
            {
                nextUser = GenerateNextUser(currentUser);
            }
            else
            {
                nextUser = GenerateFallbackUser(_ldapConfig.Prefix); // Eindeutigen Fallback-Wert generieren
            }
            stopwatch.Stop();
            return nextUser;
        }

        private async Task<string> GetUserWithHighestSamAccountNameAsync(string ldapFilter)
        {
            return await Task.Run(() =>
            {
                try
                {
                    using (var entry = new DirectoryEntry())
                    {
                        using (var searcher = new DirectorySearcher(entry))
                        {
                            searcher.Filter = ldapFilter;
                            searcher.PropertiesToLoad.Add("sAMAccountName");
                            searcher.PropertiesToLoad.Add("whenCreated");
                            searcher.Sort.PropertyName = "sAMAccountName";
                            searcher.Sort.Direction = System.DirectoryServices.SortDirection.Descending;

                            var result = searcher.FindOne();

                            if (result != null)
                            {
                                return result.Properties["sAMAccountName"][0].ToString();
                            }
                        }
                    }

                }
                catch (DirectoryServicesCOMException ex)
                {
                    throw new Exception("Fehler beim Zugriff auf Active Directory.", ex);
                }
                return null; // Kein Benutzer gefunden
            });
        }

        private string GenerateNextUser(string currentUser)
        {
            string prefix = currentUser.StartsWith("gmb", StringComparison.OrdinalIgnoreCase) ? "gmb" : currentUser.Substring(0, 2); // Hole den Prefix
            Match match = Regex.Match(currentUser, @"^([a-z]{2,3})(\d+)$", RegexOptions.IgnoreCase);

            if (match.Success)
            {
                string numPart = match.Groups[2].Value;

                switch (prefix.ToLower())
                {
                    case "us":
                    case "ex":
                        if (numPart.Length == 5)
                        {
                            int userNumber = int.Parse(numPart);
                            return prefix + (userNumber + 1).ToString("D5"); // Nächste Zahl in 5 Stellen
                        }
                        break;

                    case "vl":
                    case "gmb":
                        if (numPart.Length == 4)
                        {
                            int userNumber = int.Parse(numPart);
                            return prefix + (userNumber + 1).ToString("D4"); // Nächste Zahl in 4 Stellen
                        }
                        break;
                }
            }

            // Falls kein passendes Muster gefunden wurde, generiere einen Fallback-Wert
            return GenerateFallbackUser(prefix); // Fallback-Wert
        }

        private string GenerateFallbackUser(string prefix)
        {
            // Generiere eine alphanumerische Kombination, die nicht länger als 15 Zeichen ist
            string uniquePart = DateTime.Now.ToString("yyyyMMddHHmmss"); // Zeitstempel als eindeutigen Teil
            string fallbackUser = prefix + uniquePart;

            // Kürze den Fallback-Wert auf maximal 15 Zeichen (prefix + eindeutigen Teil)
            return fallbackUser.Length > 15 ? fallbackUser.Substring(0, 15) : fallbackUser;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // Freigeben von verwalteten Ressourcen
                }
                disposed = true;
            }
        }
    }
}
