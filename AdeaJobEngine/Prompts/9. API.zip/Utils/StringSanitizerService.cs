﻿using System.Text;

namespace Infrastructure.GUI.Web.Utils
{
    public interface IStringSanitizerService
    {
        string ReplaceIllegalChars(string input);
    }

    /*
        Dictionary<char, string>: 
        Ein Wörterbuch wird verwendet, um die Ersetzungen für alle relevanten Zeichen zu speichern. 
        StringBuilder: 
        Ein StringBuilder wird verwendet, um die Zeichen zu verarbeiten und zu ersetzen. 
        Wenn das Zeichen gefunden wird, wird es durch das entsprechende Ersatzzeichen ersetzt. 
        Andernfalls wird es unverändert in den StringBuilder geschrieben.    
     */

    public class StringSanitizerService : IStringSanitizerService
    {
        private readonly Dictionary<char, string> _replacementMap = new()
        {
            {' ', "-"}, {'\'', ""}, {'_', "-"}, {'/', "-"}, {'\\', "-"},
            {'ä', "ae"}, {'Ä', "Ae"}, {'ö', "oe"}, {'Ö', "Oe"}, {'ü', "ue"}, {'Ü', "Ue"},
            {'À', "A"}, {'Á', "A"}, {'Â', "A"}, {'Ã', "A"}, {'Å', "A"}, {'Ç', "C"},
            {'È', "E"}, {'É', "E"}, {'Ê', "E"}, {'Ë', "E"}, {'Ì', "I"}, {'Í', "I"}, {'Î', "I"}, {'Ï', "I"},
            {'Ñ', "N"}, {'Ò', "O"}, {'Ó', "O"}, {'Ô', "O"}, {'Õ', "O"}, {'Ù', "U"}, {'Ú', "U"}, {'Û', "U"}, {'Ý', "Y"},
            {'ß', "ss"}, {'à', "a"}, {'á', "a"}, {'â', "a"}, {'ã', "a"}, {'å', "a"}, {'æ', "ae"},
            {'ç', "c"}, {'è', "e"}, {'é', "e"}, {'ê', "e"}, {'ë', "e"}, {'ì', "i"}, {'í', "i"}, {'î', "i"}, {'ï', "i"},
            {'ð', "d"}, {'ñ', "n"}, {'ò', "o"}, {'ó', "o"}, {'ô', "o"}, {'õ', "o"}, 
            {'ù', "u"}, {'ú', "u"}, {'û', "u"}, {'ý', "y"}, {'ÿ', "y"}
        };

        public string ReplaceIllegalChars(string input)
        {
            if (string.IsNullOrEmpty(input))
                return input;

            var output = new StringBuilder(input.Length);

            foreach (var ch in input)
            {
                if (_replacementMap.ContainsKey(ch))
                {
                    output.Append(_replacementMap[ch]);
                }
                else
                {
                    output.Append(ch);
                }
            }
            return output.ToString();
        }
    }

}
