﻿namespace Infrastructure.GUI.Web.Utils
{
    public static class TabIndexService
    {
        private static int _currentTabIndex = 1;

        public static int Next()
        {
            return _currentTabIndex++;
        }

        public static void Reset()
        {
            _currentTabIndex = 1;
        }
    }
}
