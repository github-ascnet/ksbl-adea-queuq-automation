﻿namespace Infrastructure.GUI.Web.Utils
{
    public static class TabNavigationService
    {
        public class TabSectionDefinition
        {
            public string TabKey { get; set; } = string.Empty;
            public string Emoji { get; set; } = string.Empty;
            public string TabTitle { get; set; } = string.Empty;
            public Dictionary<string, string> Sections { get; set; } = new();

            public string GetSectionTitle(string sectionKey)
            {
                return Sections.TryGetValue(sectionKey, out var title) ? title : string.Empty;
            }
        }

        private static readonly Dictionary<string, TabSectionDefinition> _tabDefinitions = new()
        {
            ["groupmailbox"] = new TabSectionDefinition
            {
                TabKey = "groupmailbox",
                Emoji = "👥",
                TabTitle = "Gruppenpostfächer",
                Sections = new Dictionary<string, string>
                {
                    ["create"] = "➕ Neu Anlegen",
                    ["permissions"] = "🔐 Berechtigungen setzen",
                    ["ownership"] = "📥 Verantwortlicher ändern"
                }
            },
            ["distribution"] = new TabSectionDefinition
            {
                TabKey = "distribution",
                Emoji = "📤",
                TabTitle = "Verteilerlisten",
                Sections = new Dictionary<string, string>
                {
                    ["create"] = "➕ Neu Anlegen",
                    //["permissions"] = "👤 Verantwortlicher ändern",
                    ["ownerships"] = "👤 Verantwortliche ändern",
                    ["delete"] = "🗑️ Löschen"
                }
            },
            ["useraccounts"] = new TabSectionDefinition
            {
                TabKey = "useraccounts",
                Emoji = "👤",
                TabTitle = "Benutzerkonten",
                Sections = new Dictionary<string, string>
                {
                    ["modifyname"] = "📝 Benutzername ändern",
                    ["modifyad"] = "‍🖧 Active-Directory Benutzer ändern",
                    ["hausarzt"] = "🏥 Hausarzt Benutzer erstellen",
                    ["admin"] = "🛡️ Admin Benutzer erstellen",
                    ["external"] = "🌐 Externer Benutzer erstellen",
                    ["internal"] = "🏢 Mandant 2 Benutzer erstellen",
                    ["service"] = "🔧 Service Benutzer erstellen",
                    ["generic"] = "👥 Gemeinschafts Benutzer erstellen",
                    ["mobile"] = "📱 Mobile Nummer anpassen"
                }
            },
            ["hospis"] = new TabSectionDefinition
            {
                TabKey = "hospis",
                Emoji = "🏢",
                TabTitle = "Hospis Aktionen",
                Sections = new Dictionary<string, string>
                {
                    ["manual"] = "➕✍️ Manuelle Auslösung"
                }
            },
            ["admin"] = new TabSectionDefinition
            {
                TabKey = "admin",
                Emoji = "🛠️",
                TabTitle = "Admin",
                Sections = new Dictionary<string, string>
                {
                    ["jobarchive"] = "🗄️ Job Archiv"
                }
            }
        };

        public static TabSectionDefinition GetTabDefinition(string tabKey)
        {
            return _tabDefinitions.TryGetValue(tabKey, out var def) ? def : new TabSectionDefinition();
        }

        public static IReadOnlyDictionary<string, TabSectionDefinition> All => _tabDefinitions;
    }
}
