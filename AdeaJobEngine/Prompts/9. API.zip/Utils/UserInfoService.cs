﻿using Microsoft.Extensions.Options;
using System.Text.Json;

namespace Infrastructure.GUI.Web.Utils
{
    public interface IUserInfoService
    {
        Task<UserInfo> GetCurrentUserInfo();
    }

    public class UserInfoService : IUserInfoService
    {
        private readonly IActiveDirectoryService _adService;
        private readonly AppSettingsService _appSettingsService;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public UserInfoService(IActiveDirectoryService adService, IOptions<AppSettingsService> appSettingsService, IHttpContextAccessor httpContextAccessor)
        {
            _adService = adService;
            _appSettingsService = appSettingsService.Value;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<UserInfo> GetCurrentUserInfo()
        {
            var session = _httpContextAccessor.HttpContext.Session;

            // Prüfe, ob Benutzerinformationen in der Session gespeichert sind
            var userInfoJson = session.GetString("UserInfo");
            if (!string.IsNullOrEmpty(userInfoJson))
            {
                return JsonSerializer.Deserialize<UserInfo>(userInfoJson);
            }

            // Wenn nicht vorhanden, Benutzerinformationen vom Netzwerk abrufen
            var userInfo = new UserInfo
            {
                CurrentUserName = string.Empty,
                CurrentUserDomainName = string.Empty,
                CurrentUserEMailAddress = _appSettingsService.DefaultRecipientAddress
            };

            var userIdentity = _httpContextAccessor.HttpContext?.User?.Identity;
            if (userIdentity != null && userIdentity.IsAuthenticated)
            {                
                var splitName = userIdentity.Name.Split('\\');
                userInfo.CurrentUserDomainName = splitName[0];
                userInfo.CurrentUserName = splitName[1];
                userInfo.CurrentUserEMailAddress = await _adService.EnumerateAdminUserEmail(userInfo.CurrentUserName);

                // Durchlaufe die Claims und extrahiere die Gruppenmitgliedschaften
                var claimsPrincipal = _httpContextAccessor.HttpContext.User;
                var groupSidClaims = claimsPrincipal.Claims.Where(claim => claim.Type == "http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid");
            }

            // Speichere die Benutzerinformationen in der Session
            session.SetString("UserInfo", JsonSerializer.Serialize(userInfo));
            return userInfo;
        }
    }

    public class UserInfo
    {
        public string CurrentUserName { get; set; }
        public string CurrentUserEMailAddress { get; set; }
        public string CurrentUserDomainName { get; set; }
    }
}
