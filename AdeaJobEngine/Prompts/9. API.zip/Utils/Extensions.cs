﻿using Infrastructure.GUI.Web.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace Infrastructure.GUI.Web.Utils
{
    public enum PropValidation
    {
        Valid,
        Invalid,
        Unknown
    }

    public static class Extensions
    {
        public static PropValidation IsValidEmailAddress(this string emailAddress)
        {
            if (string.IsNullOrEmpty(emailAddress))
            {
                return PropValidation.Unknown;
            }
            else
            {
                try
                {
                    System.Net.Mail.MailAddress m = new System.Net.Mail.MailAddress(emailAddress);
                    return PropValidation.Valid;
                }
                catch (FormatException)
                {
                    return PropValidation.Invalid;
                }
            }
        }

        public static string ExtractDisplayNameSuffix(this string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return "N/A";
            }

            // Prüfe auf `()` und extrahiere den Inhalt
            if (input.Contains("(") && input.Contains(")"))
            {
                int startIndex = input.IndexOf("(") + 1;
                int endIndex = input.IndexOf(")");
                return input.Substring(startIndex, endIndex - startIndex).Trim();
            }

            // Prüfe auf `{}` und extrahiere den Inhalt
            if (input.Contains("{") && input.Contains("}"))
            {
                int startIndex = input.IndexOf("{") + 1;
                int endIndex = input.IndexOf("}");
                return input.Substring(startIndex, endIndex - startIndex).Trim();
            }
            return input.Trim();
        }

        public static string EnumerateModelStateErrors(this ModelStateDictionary modelState)
        {
            if (modelState == null || !modelState.Any())
                return string.Empty;

            var sb = new StringBuilder();

            foreach (var entry in modelState)
            {
                var key = entry.Key;
                foreach (var error in entry.Value.Errors)
                {
                    var errorMessage = string.IsNullOrWhiteSpace(error.ErrorMessage) ? "Unbekannter Fehler" : error.ErrorMessage;
                    sb.AppendLine($"{key}: {errorMessage}");
                }
            }
            return sb.ToString().Trim();
        }

        public static string FormatValidationLogMessage<T>(this T model, ModelStateDictionary modelState, string prefix = "❌ Die übermittelten Formulardaten sind ungültig:")
        {
            var modelErrors = modelState.EnumerateModelStateErrors();
            var modelValues = JsonSerializer.Serialize(model, new JsonSerializerOptions { WriteIndented = true });

            return $"{prefix}\n" +
                   $"→ Fehler: {(string.IsNullOrWhiteSpace(modelErrors) ? "Unknown" : modelErrors)}\n" +
                   $"→ Modelinhalt:\n{modelValues}";
        }

        public static CombinedViewModel WithTabAndSection(this CombinedViewModel viewModel, object activeModel)
        {
            switch (activeModel)
            {
                // === Gruppenpostfächer ===
                case CreateGroupMailboxViewModel:
                    viewModel.ActiveTab = "groupmailbox";
                    viewModel.ActiveSection = "create";
                    break;

                case ModifyGroupMailboxPermissionsViewModel:
                    viewModel.ActiveTab = "groupmailbox";
                    viewModel.ActiveSection = "permissions";
                    break;

                case ModifyGroupMailboxResponsibleViewModel:
                    viewModel.ActiveTab = "groupmailbox";
                    viewModel.ActiveSection = "ownership";
                    break;

                // === Verteilerlisten ===
                case CreateDistributionGroupViewModel:
                    viewModel.ActiveTab = "distribution";
                    viewModel.ActiveSection = "create";
                    break;

                //case ModifyDistributionGroupResponsibleViewModel:
                //    viewModel.ActiveTab = "distribution";
                //    viewModel.ActiveSection = "permissions";
                //    break;

                case ModifyDistributionGroupPermissionsViewModel:
                    viewModel.ActiveTab = "distribution";
                    viewModel.ActiveSection = "ownerships";
                    break;

                case DeleteDistributionGroupViewModel:
                    viewModel.ActiveTab = "distribution";
                    viewModel.ActiveSection = "delete";
                    break;

                // === Benutzerkonten ===
                case UpdateUserNameChangeViewModel:
                    viewModel.ActiveTab = "useraccounts";
                    viewModel.ActiveSection = "modifyname";
                    break;

                case UpdateAdAndExchangeViewModel:
                    viewModel.ActiveTab = "useraccounts";
                    viewModel.ActiveSection = "modifyad";
                    break;

                case CreateNewHausarztUserViewModel:
                    viewModel.ActiveTab = "useraccounts";
                    viewModel.ActiveSection = "hausarzt";
                    break;

                case CreateNewAdminUserViewModel:
                    viewModel.ActiveTab = "useraccounts";
                    viewModel.ActiveSection = "admin";
                    break;

                case CreateNewExternalUserViewModel:
                    viewModel.ActiveTab = "useraccounts";
                    viewModel.ActiveSection = "external";
                    break;

                case CreateNewInternalUserViewModel:
                    viewModel.ActiveTab = "useraccounts";
                    viewModel.ActiveSection = "internal";
                    break;

                case CreateNewServiceUserViewModel:
                    viewModel.ActiveTab = "useraccounts";
                    viewModel.ActiveSection = "service";
                    break;

                case CreateMultifunctionUserViewModel:
                    viewModel.ActiveTab = "useraccounts";
                    viewModel.ActiveSection = "generic";
                    break;

                case AssignMobileNumberViewModel:
                    viewModel.ActiveTab = "useraccounts";
                    viewModel.ActiveSection = "mobile";
                    break;

                // === Hospis ===
                case HospisUserActionViewModel:
                    viewModel.ActiveTab = "hospis";
                    viewModel.ActiveSection = "manual";
                    break;

                default:
                    viewModel.ActiveTab = "groupmailbox";
                    viewModel.ActiveSection = "create";
                    break;
            }

            return viewModel;
        }

        public static string TruncateName(this string expression)
        {
            if (string.IsNullOrWhiteSpace(expression))
            {
                throw new ArgumentException("Der Name darf nicht null oder leer sein.", nameof(expression));
            }

            expression = expression.Trim();
            int length = expression.Length;

            if (length <= 4)
            {
                return expression;
            }

            string nameWithoutSpaces = expression.Replace(" ", "");
            int lengthWithoutSpaces = nameWithoutSpaces.Length;

            int newLengthWithoutSpaces = (int)Math.Round(lengthWithoutSpaces * 0.6);

            newLengthWithoutSpaces = Math.Max(newLengthWithoutSpaces, 4);

            int lengthToTake = Math.Min(length, newLengthWithoutSpaces + (expression.Length - lengthWithoutSpaces));

            return expression.Substring(0, lengthToTake);
        }

        public static string TruncateChars(this string expression)
        {
            if (expression.Contains(" "))
            {
                expression = expression.Substring(0, expression.IndexOf(" "));
            }

            if (expression.Contains("-"))
            {
                expression = expression.Substring(0, expression.IndexOf("-"));
            }

            if (expression.Length <= 4) { return expression.Substring(0, expression.Length); }
            else if (expression.Length <= 5) { return expression.Substring(0, 4); }
            else if (expression.Length <= 7) { return expression.Substring(0, 5); }
            else if (expression.Length <= 9) { return expression.Substring(0, 6); }
            else if (expression.Length <= 11) { return expression.Substring(0, 7); }
            else if (expression.Length <= 13) { return expression.Substring(0, 8); }
            else if (expression.Length <= 15) { return expression.Substring(0, 9); }
            else if (expression.Length <= 17) { return expression.Substring(0, 10); }
            else { return expression.Substring(0, 11); }
        }

        public static bool HasNameMatchByPrefixSuffix(this Tuple<string, string> person1, Tuple<string, string> person2, int prefixLength, int suffixLength)
        {
            return person1.Item1.Substring(0, prefixLength) == person2.Item1.Substring(0, prefixLength)
                && person1.Item1.Substring(person1.Item1.Length - suffixLength) == person2.Item1.Substring(person2.Item1.Length - suffixLength)
                && person1.Item2.Substring(0, prefixLength) == person2.Item2.Substring(0, prefixLength)
                && person1.Item2.Substring(person1.Item2.Length - suffixLength) == person2.Item2.Substring(person2.Item2.Length - suffixLength);
        }

        public static string WithFallback(this string? value, string fallback) => string.IsNullOrWhiteSpace(value) ? fallback : value;

        /// <summary>
        /// Bestimmt den Mandantentyp ("M1" / "M2") anhand der EmployeeId.
        /// - Nur numerische IDs werden berücksichtigt
        /// - Wenn > 900000 → M2
        /// - Wenn ≤ 900000 → M1
        /// - Wenn nicht numerisch → null
        /// </summary>
        public static string? GetEmployeeClientType(this string? employeeId)
        {
            // Null oder leer → kein Mandant
            if (string.IsNullOrWhiteSpace(employeeId))
                return null;

            // Prüfen, ob nur Ziffern enthalten sind
            if (!System.Text.RegularExpressions.Regex.IsMatch(employeeId, @"^\d+$"))
                return null; // enthält Buchstaben oder Sonderzeichen

            // Versuchen, in int zu konvertieren
            if (!int.TryParse(employeeId, out var numericId))
                return null; // ungültige Zahl (z. B. zu groß für int)

            // M1/M2 bestimmen
            if (numericId > 900000)
                return "M2";

            return "M1";
        }

        public static string ReplaceIllegalChars(this string input)
        {
            if (string.IsNullOrEmpty(input))
                return input;

            input = input.Replace(" ", "-")
                        .Replace("'", "")
                        .Replace("_", "-")
                        .Replace("//", "-")
                        .Replace("\\", "-")
                        .Replace("ä", "ae")
                        .Replace("Ä", "Ae")
                        .Replace("ö", "oe")
                        .Replace("Ö", "Oe")
                        .Replace("ü", "ue")
                        .Replace("Ü", "Ue")
                        .Replace("À", "A")
                        .Replace("Á", "A")
                        .Replace("Â", "A")
                        .Replace("Ã", "A")
                        .Replace("Å", "A")
                        .Replace("Ç", "C")
                        .Replace("È", "E")
                        .Replace("É", "E")
                        .Replace("Ê", "E")
                        .Replace("Ë", "E")
                        .Replace("Ì", "I")
                        .Replace("Í", "I")
                        .Replace("Î", "I")
                        .Replace("Ï", "I")
                        .Replace("Ñ", "N")
                        .Replace("Ò", "O")
                        .Replace("Ó", "O")
                        .Replace("Ô", "O")
                        .Replace("Õ", "O")
                        .Replace("Ö", "O")
                        .Replace("Ù", "U")
                        .Replace("Ú", "U")
                        .Replace("Û", "U")
                        .Replace("Ü", "U")
                        .Replace("Ý", "Y")
                        .Replace("à", "a")
                        .Replace("á", "a")
                        .Replace("â", "a")
                        .Replace("ã", "a")
                        .Replace("ä", "a")
                        .Replace("å", "a")
                        .Replace("æ", "ae")
                        .Replace("ç", "c")
                        .Replace("è", "e")
                        .Replace("é", "e")
                        .Replace("ê", "e")
                        .Replace("ë", "e")
                        .Replace("ì", "i")
                        .Replace("í", "i")
                        .Replace("î", "i")
                        .Replace("ï", "i")
                        .Replace("Ð", "D")
                        .Replace("ß", "ss")
                        .Replace("ñ", "n")
                        .Replace("ò", "o")
                        .Replace("ó", "o")
                        .Replace("ô", "o")
                        .Replace("õ", "o")
                        .Replace("ö", "o")
                        .Replace("ù", "u")
                        .Replace("ú", "u")
                        .Replace("û", "u")
                        .Replace("ü", "u")
                        .Replace("ý", "y")
                        .Replace("ÿ", "y");

            return input;
        }
    }
}
