﻿namespace Infrastructure.GUI.Web.Utils
{
    public static class QueueFileColumnHeaders
    {
        public static readonly List<string> CreateDistributionGroupColumns = new List<string>
        {
            "ActionType",
            "DisplayName",
            "PrimarySmtpAddress",
            "AdObjectName",
            "OrgUnit",
            "HideInAb",
            "Manager",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        public static readonly List<string> CreateGroupMailboxColumns = new List<string>
        {
            "ActionType",
            "DisplayName",
            "PrimarySmtpAddress",
            "FirstName",
            "LastName",
            "AdObjectName",
            "OrgUnit",
            "HideInAb",
            "Manager",
            "FullAccessMembers",
            "NewPrimaryEMailAddress",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|AdObjectName|FullAccessMembers|EnableSendAs|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> ModifyGroupMailboxPermissionsColumns = new List<string>
        {
            "ActionType",
            "AdObjectName",
            "FullAccessMembers",
            "EnableSendAs",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|AdObjectName|ManagerAdObjectName|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> ChangeManagerGroupMailboxColumns = new List<string>
        {
            "ActionType",
            "AdObjectName",
            "ManagerAdObjectName",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|AdObjectName|ManagedByMembers|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> ModifyDistributionGroupPermissionsColumns = new List<string>
        {
            "ActionType",
            "AdObjectName",
            "ManagedByMembers",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|AdObjectName|ManagerAdObjectName|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> ChangeDistributionGroupResponsibleColumns = new List<string>
        {
            "ActionType",
            "AdObjectName",
            "ManagerAdObjectName",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|AdObjectName|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> DeleteDistributionGroupColumns = new List<string>
        {
            "ActionType",
            "AdObjectName",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|AdObjectName|GivenName|SurName|NewPrimaryEMailAddress|NewUserId|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> UpdateUserNameChangeColumns = new List<string>
        {
            "ActionType",
            "AdObjectName",
            "GivenName",
            "SurName",
            "NewPrimaryEMailAddress",
            "NewUserId",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|AdObjectName|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> UpdateAdAndExchangeUserUpdateAccountColumns = new List<string>
        {
            "ActionType",
            "AdObjectName",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|AdObjectName|DomainName|NewPrimaryEMailAddress|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> UpdateAdAndExchangeUserChangeMailAliasColumns = new List<string>
        {
            "ActionType",
            "AdObjectName",
            "DomainName",
            "NewPrimaryEMailAddress",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|TargetAdObjectName|LdapSearchUserId|MailboxEnable|TargetDomain|TargetLocation|TargetUserAdSurname|TargetUserAdGivenname|TargetUserAdDisplayname|TargetUserAdEmployeeId|TargetUserAdEmployeeType|TargetUserDomainOU|TargetUserAdDepartment|TargetUserBirtdayDate|TargetExternalCompany|TargetAppDescription|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> CreateNewHausarztUserColumns = new List<string>
        {
            "ActionType",
            "TargetAdObjectName",
            "LdapSearchUserId",
            "MailboxEnable",
            "TargetDomain",
            "TargetLocation",
            "TargetUserAdSurname",
            "TargetUserAdGivenname",
            "TargetUserAdDisplayname",
            "TargetUserAdEmployeeId",
            "TargetUserAdEmployeeType",
            "TargetUserDomainOU",
            "TargetUserAdDepartment",
            "TargetUserBirtdayDate",
            "TargetExternalCompany",
            "TargetAppDescription",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|TargetAdObjectName|LdapSearchUserId|MailboxEnable|TargetDomain|TargetLocation|TargetUserAdSurname|TargetUserAdGivenname|TargetUserAdDisplayname|TargetUserAdEmployeeId|TargetUserAdEmployeeType|TargetUserDomainOU|TargetUserAdDepartment|TargetUserBirtdayDate|TargetExternalCompany|TargetAppDescription|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> CreateNewAdminUserColumns = new List<string>
        {
            "ActionType",
            "TargetAdObjectName",
            "LdapSearchUserId",
            "MailboxEnable",
            "TargetDomain",
            "TargetLocation",
            "TargetUserAdSurname",
            "TargetUserAdGivenname",
            "TargetUserAdDisplayname",
            "TargetUserAdEmployeeId",
            "TargetUserAdEmployeeType",
            "TargetUserDomainOU",
            "TargetUserAdDepartment",
            "TargetUserBirtdayDate",
            "TargetExternalCompany",
            "TargetAppDescription",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|TargetAdObjectName|LdapSearchUserId|MailboxEnable|TargetDomain|TargetLocation|TargetUserAdSurname|TargetUserAdGivenname|TargetUserAdDisplayname|TargetUserAdEmployeeId|TargetUserAdEmployeeType|TargetUserDomainOU|TargetUserAdDepartment|TargetUserBirtdayDate|TargetExternalCompany|TargetAppDescription|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> CreateNewExternalUserColumns = new List<string>
        {
            "ActionType",
            "TargetAdObjectName",
            "LdapSearchUserId",
            "MailboxEnable",
            "TargetDomain",
            "TargetLocation",
            "TargetUserAdSurname",
            "TargetUserAdGivenname",
            "TargetUserAdDisplayname",
            "TargetUserAdEmployeeId",
            "TargetUserAdEmployeeType",
            "TargetUserDomainOU",
            "TargetUserAdDepartment",
            "TargetUserBirtdayDate",
            "TargetExternalCompany",
            "TargetAppDescription",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|TargetAdObjectName|LdapSearchUserId|MailboxEnable|TargetDomain|TargetLocation|TargetUserAdSurname|TargetUserAdGivenname|TargetUserAdDisplayname|TargetUserAdEmployeeId|TargetUserAdEmployeeType|TargetUserDomainOU|TargetUserAdDepartment|TargetUserBirtdayDate|TargetExternalCompany|TargetAppDescription|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> CreateNewInternalUserColumns = new List<string>
        {
            "ActionType",
            "TargetAdObjectName",
            "LdapSearchUserId",
            "MailboxEnable",
            "TargetDomain",
            "TargetLocation",
            "TargetUserAdSurname",
            "TargetUserAdGivenname",
            "TargetUserAdDisplayname",
            "TargetUserAdEmployeeId",
            "TargetUserAdEmployeeType",
            "TargetUserDomainOU",
            "TargetUserAdDepartment",
            "TargetUserBirtdayDate",
            "TargetExternalCompany",
            "TargetAppDescription",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|TargetAdObjectName|LdapSearchUserId|MailboxEnable|TargetDomain|TargetLocation|TargetUserAdSurname|TargetUserAdGivenname|TargetUserAdDisplayname|TargetUserAdEmployeeId|TargetUserAdEmployeeType|TargetUserDomainOU|TargetUserAdDepartment|TargetUserBirtdayDate|TargetExternalCompany|TargetAppDescription|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> CreateNewServiceUserColumns = new List<string>
        {
            "ActionType",
            "TargetAdObjectName",
            "LdapSearchUserId",
            "MailboxEnable",
            "TargetDomain",
            "TargetLocation",
            "TargetUserAdSurname",
            "TargetUserAdGivenname",
            "TargetUserAdDisplayname",
            "TargetUserAdEmployeeId",
            "TargetUserAdEmployeeType",
            "TargetUserDomainOU",
            "TargetUserAdDepartment",
            "TargetUserBirtdayDate",
            "TargetExternalCompany",
            "TargetAppDescription",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|TargetAdObjectName|TargetDomain|TargetUserAdDisplayname|TargetUserAdEmployeeType|targetUserDomainOU|Manager|Description|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> CreateMultifunctionUserColumns = new List<string>
        {
            "ActionType",
            "TargetAdObjectName",
            "TargetDomain",
            "TargetUserAdDisplayname",
            "TargetUserAdEmployeeType",
            "TargetUserDomainOU",
            "Manager",
            "Description",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|AdObjectName|MobileNumber|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> AssignMobileNumberColumns = new List<string>
        {
            "ActionType",
            "AdObjectName",
            "MobileNumber",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

        // ActionType|PersId|LdapSearchPersId|AdObjectName|DisplayName|RefUserId|RefUserDomain|LocationName|MigrateUser|CurrentUserName|CurrentUserDomainName|CurrentUserEMailAddress
        public static readonly List<string> HospisUserActionColumns = new List<string>
        {
            "ActionType",
            "PersId",
            "LdapSearchPersId",
            "AdObjectName",
            "DisplayName",
            "RefUserId",
            "RefUserDomain",
            "LocationName",
            "MigrateUser",
            "CurrentUserName",
            "CurrentUserDomainName",
            "CurrentUserEMailAddress"
        };

    }
}
