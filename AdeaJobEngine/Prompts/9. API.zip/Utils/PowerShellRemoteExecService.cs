﻿using System.Diagnostics;

namespace Infrastructure.GUI.Web.Utils
{
    public interface IPowerShellRemoteExecService
    {
        Task RunScriptAsync(string scriptPath);
    }

    public class PowerShellRemoteExecService : IPowerShellRemoteExecService
    {
        public async Task RunScriptAsync(string scriptPath)
        {
            var startInfo = new ProcessStartInfo
            {
                FileName = "powershell.exe",  // Pfad zur PowerShell-Exe
                Arguments = $"-File \"{scriptPath}\"",  // Übergibt das Skript als Argument
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true  // Startet ohne neues Fenster                
            };

            using (var process = new Process { StartInfo = startInfo })
            {
                process.Start();                  
                var output = await process.StandardOutput.ReadToEndAsync();
                var error = await process.StandardError.ReadToEndAsync();
                await process.WaitForExitAsync();  

                // Prüfe, ob Fehler aufgetreten sind
                if (!string.IsNullOrEmpty(error))
                {
                    throw new Exception($"Fehler beim Ausführen des Skripts {scriptPath}: {error}");
                }
            }
        }
    }

}
