﻿namespace Infrastructure.GUI.Web.Utils
{
    public static class ConnectionStringParser
    {
        public static string ExtractServerName(string connectionString)
        {
            var parts = connectionString.Split(';', StringSplitOptions.RemoveEmptyEntries);

            foreach (var part in parts)
            {
                if (part.TrimStart().StartsWith("Server=", StringComparison.OrdinalIgnoreCase) ||
                    part.TrimStart().StartsWith("Data Source=", StringComparison.OrdinalIgnoreCase))
                {
                    var value = part.Split('=')[1].Trim();

                    // Entferne Port falls vorhanden (z. B. ,64039)
                    var withoutPort = value.Split(',')[0];

                    // Entferne Domain falls vorhanden (z. B. ms.uhbs.ch)
                    var shortName = withoutPort.Split('.')[0];

                    return shortName.ToUpper();
                }
            }
            return "Unbekannter Server";
        }
    }

}
