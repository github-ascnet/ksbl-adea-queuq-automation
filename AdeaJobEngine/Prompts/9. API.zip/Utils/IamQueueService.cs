﻿using Microsoft.Extensions.Options;
using System.Security.Cryptography.X509Certificates;

namespace Infrastructure.GUI.Web.Utils
{
    public enum ExecutableAction
    {
        CreateGroupMailbox,
        CreatePersonMailbox,
        CreateNonStdPersonMailbox,
        CreateMultiFunctionGenericUser,
        CreateServiceAccount,
        CreateManagedServiceAccount,
        CreateWpaServiceAccount,
        CreateHospisPersonMailbox,
        CreateDistributionList,
        AddGroupMailboxFmaMembers,
        RemoveGroupMailboxFmaMembers,
        AddDistributionListResponsibles,
        RemoveDistributionListResponsibles,
        RenameUserAccount,
        AddEMailNickName,
        EnableNonStdPersonMailbox,
        DisableNonStdPersonMailbox,
        ModifyGroupMemberships,
        ModifyRoleMemberships,
        CopyUserToUserMemberships,
        ChangeManagerGroupMailbox,
        ChangeManagerDistribList,
        DeleteDistribList,
        UserLocationChange,
        Aktivieren,
        Inaktivieren,
        Erstellen,
        DringendInaktivieren,
        Standortwechsel,
        UebertrittM2,
        UebertrittM1,
        EnableAdAccountWithGracePeriod,
        ModifyMobilePhoneNumber,
        ModifyMailboxFolderAce,
        Unknown
    }

    enum HospisUseCase
    {
        ERSTELLEN,
        INAKTIVIEREN,
        AKTIVIEREN,
        STANDORTWECHSEL,
        UEBERTRITTM2,
        Unknown
    }

    public interface IIamQueueService
    {
        Task<string> CreateIamQueueFileAsync(string iamQueueFileContent, bool isHospisPersonUseCase = false, bool urgent = false);
    }

    public class IamQueueService : IIamQueueService
    {
        private readonly AppSettingsService _appSettingsService;

        public IamQueueService(IOptions<AppSettingsService> appSettingsService)
        {
            _appSettingsService = appSettingsService.Value;
        }

        public async Task<string> CreateIamQueueFileAsync(string iamQueueFileContent, bool isHospisPersonUseCase = false, bool urgent = false)
        {
            // Überprüfe, ob der Inhalt gültig ist
            if (string.IsNullOrEmpty(iamQueueFileContent))
            {
                return "IamQueueFileContent is null or empty.";
            }

            // Splitte den Inhalt in Zeilen (falls es mehrere Zeilen gibt)
            string[] lines = iamQueueFileContent.Split(new[] { "\r\n" }, StringSplitOptions.None);

            // Überprüfe, ob wir genügend Zeilen haben
            if (lines.Length < 2)
            {
                return "Invalid IamQueueFileContent format.";
            }

            // Die erste Zeile enthält die Spaltennamen
            string[] columns = lines[0].Split('|');
            string[] values = lines[1].Split('|');

            // Überprüfe, ob die Zeilen ausreichend Werte haben
            if (columns.Length == 0 || values.Length < columns.Length)
            {
                return "Invalid IamQueueFileContent format: insufficient values.";
            }

            // 1. Hole den Index für "ActionType" und "CurrentUserName"
            int actionIndex = Array.IndexOf(columns, "ActionType");
            int currentUserIndex = Array.IndexOf(columns, "CurrentUserName");

            if (actionIndex == -1 || currentUserIndex == -1)
            {
                return "IamQueueFileContent is missing required fields: ActionType or CurrentUserName.";
            }

            string iamQueueFilePath = string.Empty;
            // 2. Nutze die Indizes, um die entsprechenden Werte aus dem `values` Array zu lesen
            string executableAction = values[actionIndex];
            string currentUserName = values[currentUserIndex];

            if (executableAction.StartsWith("Create", StringComparison.OrdinalIgnoreCase) && executableAction.EndsWith("ServiceAccount", StringComparison.OrdinalIgnoreCase))
            {
                executableAction = "CreateNonStdPersonMailbox";
            }

            if (isHospisPersonUseCase)
            {
                if (urgent)
                {
                    executableAction += "_HospisPersonUrgentUseCase";
                }
                else
                {
                    executableAction += "_HospisPersonUseCase";
                }
            }

            //if (Environment.MachineName.ToLower() == "sv00565")
            //{
            //    iamQueueFilePath = Path.Combine(@$"c:\temp\queue\{Guid.NewGuid()}_{executableAction}_{currentUserName}_pshjob_.csv");
            //}
            //else
            {
                // Hole den IAM-Server und das Share-Name aus den Konfigurationen
                string iamServer = _appSettingsService.IamServer;
                string shareName = _appSettingsService.OutputShareName;

                // Netzwerkzugang prüfen
                string netMessage = await CheckRemoteServerNetworkAccessAsync(iamServer, 445);
                if (netMessage != "success")
                {
                    return netMessage;
                }

                // Pfad zur IAM Queue-Datei erstellen
                iamQueueFilePath = Path.Combine(@"\\", iamServer, shareName, $"{Guid.NewGuid()}_{executableAction}_{currentUserName}_pshjob_.csv");
            }

            try
            {
                // Datei schreiben
                await File.WriteAllTextAsync(iamQueueFilePath, iamQueueFileContent);
                return "success";
            }
            catch (UnauthorizedAccessException ex)
            {
                return $"Unauthorized access error: {ExceptionHelper.GetMostRelevantMessage(ex)}";
            }
            catch (IOException ex)
            {
                return $"IO error: {ExceptionHelper.GetMostRelevantMessage(ex)}";
            }
        }

        private async Task<string> CheckRemoteServerNetworkAccessAsync(string targetServer, int tcpPort)
        {
            using (var client = new System.Net.Sockets.TcpClient())
            {
                try
                {
                    await client.ConnectAsync(targetServer, tcpPort);
                    return "success"; 
                }
                catch (System.Net.Sockets.SocketException ex)
                {
                    return $"Fehler beim Netzwerk-Zugriff auf {targetServer}:{tcpPort}: {ExceptionHelper.GetMostRelevantMessage(ex)}";
                }
            }
        }

    }
}
