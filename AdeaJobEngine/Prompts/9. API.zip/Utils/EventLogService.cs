﻿using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Infrastructure.GUI.Web.Utils
{
    public interface IEventLogService
    {
        void LogInformation(string message, int eventId, [CallerMemberName] string memberName = "", [CallerLineNumber] int lineNumber = 0);
        void LogWarning(string message, int eventId, [CallerMemberName] string memberName = "", [CallerLineNumber] int lineNumber = 0);
        void LogError(string message, int eventId, [CallerMemberName] string memberName = "", [CallerLineNumber] int lineNumber = 0);
    }
    public class EventLogService : IEventLogService
    {
        private readonly string _source;
        private readonly string _logName;

        public EventLogService(string logSource, string logName)
        {
            _source = logSource;
            _logName = logName;

            try
            {
                // Prüft, ob die EventLog-Quelle existiert, und erstellt sie falls nicht
                if (!EventLog.SourceExists(_source))
                {
                    EventLog.CreateEventSource(_source, _logName);
                }
            }
            catch (System.Security.SecurityException ex)
            {
                Console.WriteLine($"SecurityException: Keine Berechtigung zur Erstellung der EventLog-Quelle '{_source}' im Log '{_logName}'. {ExceptionHelper.GetMostRelevantMessage(ex)}");
                // Fallback-Mechanismus oder alternativer Logweg kann hier eingebaut werden
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Fehler beim Erstellen der EventLog-Quelle: {ExceptionHelper.GetMostRelevantMessage(ex)}");
            }
        }

        public void LogInformation(string message, int eventId, [CallerMemberName] string memberName = "", [CallerLineNumber] int lineNumber = 0)
        {
            var detailedMessage = $"{message} (Funktion: {memberName}, Zeile: {lineNumber})";
            WriteLog(detailedMessage, eventId, EventLogEntryType.Information);
        }

        public void LogWarning(string message, int eventId, [CallerMemberName] string memberName = "", [CallerLineNumber] int lineNumber = 0)
        {
            var detailedMessage = $"{message} (Funktion: {memberName}, Zeile: {lineNumber})";
            WriteLog(detailedMessage, eventId, EventLogEntryType.Warning);
        }

        public void LogError(string message, int eventId, [CallerMemberName] string memberName = "", [CallerLineNumber] int lineNumber = 0)
        {
            var detailedMessage = $"{message} (Funktion: {memberName}, Zeile: {lineNumber})";
            WriteLog(detailedMessage, eventId, EventLogEntryType.Error);
        }

        private void WriteLog(string message, int eventId, EventLogEntryType type)
        {
            using (EventLog eventLog = new EventLog { Source = _source, Log = _logName })
            {
                eventLog.WriteEntry(message, type, eventId);
            }
        }
    }
}
