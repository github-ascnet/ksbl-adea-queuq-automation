﻿using Microsoft.EntityFrameworkCore;
using Infrastructure.GUI.Web.Models;
using Infrastructure.GUI.Web.Analysis;

namespace Infrastructure.GUI.Web.Utils
{
    public enum EnterpriseClientType
    {
        Hausarzt,
        Mandant1,
        Mandant2
    }

    public static class DuplicateAccountHelper
    {
        public static async Task<List<Person>> FindDuplicateAccountsAsync(
                                    IQueryable<Models.Account> accounts,
                                    IQueryable<Models.Person> persons,
                                    string identity,
                                    EnterpriseClientType clientType)
        {
            // 🧠 1. Personenstammdaten holen inklusive Geburtsdatum
            var person = await persons
                .Where(p => p.Personalnummer == identity)
                .Select(p => new { p.Nachname, p.Vorname, p.Geburtsdatum })
                .FirstOrDefaultAsync();

            if (person == null)
            {
                Console.WriteLine($"❌ Keine Person gefunden für Identity: {identity}");
                return new List<Person>();
            }

            // 🧠 2. Accounts abrufen
            var allAccounts = await accounts.Where(p => p.EmployeeType == "P" || p.EmployeeType == "E").ToListAsync();
            if (!allAccounts.Any())
            {
                Console.WriteLine($"❌ Keine Accounts in der Datenbank gefunden.");
                return new List<Person>();
            }

            // 🧠 3. Eigenes Geburtsdatum bestimmen (Person bevorzugt)
            string ownBirthday = NormalizeDate(person.Geburtsdatum);

            if (string.IsNullOrWhiteSpace(ownBirthday))
            {
                var ownAccount = allAccounts.FirstOrDefault(a => a.EmployeeId == identity);
                ownBirthday = NormalizeDate(ownAccount?.HrmsBirthdate) ?? NormalizeDate(ownAccount?.ExtensionAttribute14);
            }

            if (string.IsNullOrWhiteSpace(ownBirthday))
            {
                Console.WriteLine($"⚠️ Kein Geburtsdatum für die Identität {identity} gefunden.");
                return new List<Person>();
            }

            // 🧠 4. Vollständiger Name für Fuzzy-Vergleich
            var ownFullName = $"{person.Nachname} {person.Vorname}".Trim();

            // 🧠 5. Kandidaten vorbereiten
            string normalizedPersonBirthday = NormalizeDate(person.Geburtsdatum);

            return allAccounts
                .Where(p => !string.IsNullOrWhiteSpace(p.SurName) && !string.IsNullOrWhiteSpace(p.GivenName))
                .Select(p => new
                {
                    Account = p,
                    Score = FuzzyNameComparer.GetFullNameSimilarityScore(
                        fullNameA: ownFullName,
                        fullNameB: $"{p.SurName} {p.GivenName}".Trim(),
                        useBirthdayBoost: true,
                        birthdateA: ownBirthday,
                        birthdateB: NormalizeDate(p.HrmsBirthdate) ?? NormalizeDate(p.ExtensionAttribute14)
                    )
                })
                .Where(x => x.Score >= 85) // ⚡️ Schwelle für potenzielle Duplikate
                .Select(x => new Person
                {
                    Personalnummer = x.Account.EmployeeId,
                    WindowsLogin = x.Account.SamAccountName,
                    Nachname = x.Account.SurName,
                    Vorname = x.Account.GivenName,
                    Organisationseinheit = x.Account.Department,
                    WindowsAccountState = x.Account.UserAccountControl.Contains("ACCOUNTDISABLE") ? "Inaktiv" : "Aktiv",
                    WindowsLastLogin = x.Account.LastLogonTimestamp,
                    WindowsPwdLastChanged = x.Account.PwdLastSet,
                    WindowsAccountExpires = x.Account.AccountExpires,
                    WindowsExtAttrib11 = x.Account.ExtensionAttribute11,
                    WindowsEmployeeType = x.Account.EmployeeType,
                    Geburtsdatum = !string.IsNullOrWhiteSpace(person.Geburtsdatum)
                                   ? person.Geburtsdatum
                                   : (x.Account.HrmsBirthdate ?? x.Account.ExtensionAttribute14 ?? ""),
                    FuzzyMatchScore = x.Score
                })
                .ToList();
        }

        /// <summary>
        /// Normiert ein Datum ins Format yyyyMMdd oder gibt null zurück.
        /// </summary>
        private static string NormalizeDate(string rawDate)
        {
            if (DateTime.TryParse(rawDate, out DateTime parsed))
                return parsed.ToString("yyyyMMdd");

            return null;
        }
    }
}
