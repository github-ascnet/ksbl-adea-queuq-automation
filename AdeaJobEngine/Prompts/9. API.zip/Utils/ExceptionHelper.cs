﻿namespace Infrastructure.GUI.Web.Utils
{
    public static class ExceptionHelper
    {
        public static string GetMostRelevantMessage(Exception ex)
        {
            if (ex == null)
                return "Unbekannter Fehler";

            // Ebene 1: ex.InnerException.InnerException.Message
            if (ex.InnerException?.InnerException != null &&
                !string.IsNullOrWhiteSpace(ex.InnerException.InnerException.Message))
            {
                return ex.InnerException.InnerException.Message;
            }

            // Ebene 2: ex.InnerException.Message
            if (ex.InnerException != null &&
                !string.IsNullOrWhiteSpace(ex.InnerException.Message))
            {
                return ex.InnerException.Message;
            }

            // Ebene 3: ex.GetBaseException().Message
            var baseMessage = ex.GetBaseException()?.Message;
            if (!string.IsNullOrWhiteSpace(baseMessage))
            {
                return baseMessage;
            }

            // Ebene 4: ex.Message
            if (!string.IsNullOrWhiteSpace(ex.Message))
            {
                return ex.Message;
            }

            // Fallback
            return ex.ToString();
        }
    }
}
