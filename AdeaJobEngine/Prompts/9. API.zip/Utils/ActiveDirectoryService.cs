﻿using System.DirectoryServices;

namespace Infrastructure.GUI.Web.Utils
{
    enum AdAccountControlState
    {
        Enabled,
        Disabled
    }

    public interface IActiveDirectoryService
    {
        Task<string> EnumerateAdminUserEmail(string samAccountName);
        Task<List<string>> GetUsersTokenGroupsAsync(string environmentUserName);
        Task<string> ValidateMailAddressAsync(string proposedMailAddress);
    }

    public class ActiveDirectoryService : IActiveDirectoryService
    {
        public async Task<string> EnumerateAdminUserEmail(string samAccountName)
        {
            return await Task.Run(() =>
            {
                try
                {
                    using (DirectoryEntry entry = new DirectoryEntry())
                    {
                        using (DirectorySearcher adSearcher = new DirectorySearcher(entry))
                        {
                            adSearcher.Filter = "(&(sAMAccountType=805306368)(sAMAccountName=" + samAccountName + ")(extensionAttribute6=*))";
                            adSearcher.PropertiesToLoad.Add("extensionAttribute6");
                            SearchResult sr = adSearcher.FindOne();

                            if (sr != null)
                            {
                                string mailAddress = sr.Properties["extensionAttribute6"][0].ToString();
                                return mailAddress;
                            }
                            else
                            {
                                return string.Empty;
                            }
                        }
                    }
                }
                catch (System.Runtime.InteropServices.COMException)
                {
                    System.Runtime.InteropServices.COMException ex = new System.Runtime.InteropServices.COMException();
                    return string.Empty;
                }
                catch (InvalidOperationException)
                {
                    InvalidOperationException ex = new InvalidOperationException();
                    return string.Empty;
                }
                catch (NotSupportedException)
                {
                    NotSupportedException ex = new NotSupportedException();
                    return string.Empty;
                }
            });
        }

        public async Task<List<string>> GetUsersTokenGroupsAsync(string environmentUserName)
        {
            var userNestedMembership = new List<string>();

            try
            {
                using (var domainConnection = new DirectoryEntry())
                {
                    using (var samSearcher = new DirectorySearcher(domainConnection))
                    {
                        samSearcher.Filter = $"(samAccountName={environmentUserName})";
                        samSearcher.PropertiesToLoad.Add("samaccountname");

                        SearchResult samResult = await Task.Run(() => samSearcher.FindOne());

                        if (samResult != null)
                        {
                            using (var theUser = samResult.GetDirectoryEntry())
                            {
                                theUser.RefreshCache(new[] { "tokenGroups" });

                                foreach (byte[] resultBytes in theUser.Properties["tokenGroups"])
                                {
                                    var mySID = new System.Security.Principal.SecurityIdentifier(resultBytes, 0);

                                    using (var sidSearcher = new DirectorySearcher(domainConnection))
                                    {
                                        sidSearcher.Filter = $"(objectSid={mySID.Value})";
                                        sidSearcher.PropertiesToLoad.Add("name");

                                        SearchResult sidResult = await Task.Run(() => sidSearcher.FindOne());

                                        if (sidResult != null && sidResult.Properties["name"].Count > 0)
                                        {
                                            string groupName = sidResult.Properties["name"][0].ToString();
                                            if (groupName.StartsWith("LG-IAM"))
                                            {
                                                userNestedMembership.Add(groupName);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the exception (optional)
                Console.WriteLine($"Error occurred while fetching token groups for user {environmentUserName}: {ExceptionHelper.GetMostRelevantMessage(ex)}");
            }

            return userNestedMembership;
        }

        public async Task<string> ValidateMailAddressAsync(string proposedMailAddress)
        {
            return await Task.Run(() =>
            {
                SearchResult result = null;

                using (DirectoryEntry entry = new DirectoryEntry())
                {
                    using (DirectorySearcher adSearcher = new DirectorySearcher(entry))
                    {
                        adSearcher.Filter = "(|(proxyAddresses=smtp:" + proposedMailAddress + ")(mail=" + proposedMailAddress + "))";
                        adSearcher.PropertiesToLoad.Add("mail");

                        result = adSearcher.FindOne();

                        if (result == null)
                        {
                            return proposedMailAddress;
                        }
                        else
                        {
                            for (int i = 1; i < 99; i++)
                            {
                                proposedMailAddress = proposedMailAddress.Replace("@", "." + i + "@");
                                adSearcher.Filter = "(|(proxyAddresses=smtp:" + proposedMailAddress + ")(mail=" + proposedMailAddress + "))";
                                adSearcher.PropertiesToLoad.Add("mail");

                                result = adSearcher.FindOne();

                                if (result == null)
                                {
                                    return proposedMailAddress;
                                }
                            }

                            return string.Empty;
                        }
                    }
                }
            });
        }

    }
}


