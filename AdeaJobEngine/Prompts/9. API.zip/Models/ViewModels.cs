﻿using Infrastructure.GUI.Web.Validators;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace Infrastructure.GUI.Web.Models
{
    public class CreateGroupMailboxViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string GmbCreateLocation { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        [RegularExpression(@"^[a-zA-Z0-9-]{3,40}$", ErrorMessage = "Das Feld muss zwischen 3 und 40 Zeichen lang sein und darf nur Buchstaben (ohne Umlaute), Zahlen und Bindestriche enthalten.")]
        public string GmbCreateSearchFor { get; set; }

        public string GmbCreateDisplayName { get; set; }

        public string GmbCreateAlias { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        [EmailAddress(ErrorMessage = "Bitte eine gültige E-Mail-Adresse eingeben.")]
        [RegularExpression(@"^[^@\s]+@ksbl\.ch$", ErrorMessage = "Die E-Mail-Adresse muss mit @ksbl.ch enden.")]
        public string GmbCreateEmailAddress { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string GmbCreateManager { get; set; }

        public string GmbCreateFullAccessPersons { get; set; }
        
        public List<string> GmbCreateFullAccessPersonsList { get; set; } = new List<string>();

    }

    public class ModifyGroupMailboxPermissionsViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string GmbModFmaMailboxName { get; set; }

        public bool GmbModFmaSendAs { get; set; }

        public string GmbModFmaPersons { get; set; }
        
        public List<string> GmbModFmaPersonsList { get; set; }
    }

    public class ModifyGroupMailboxResponsibleViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string GmbModOwnershipMailboxName { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string GmbModOwnershipPersons { get; set; }

        //public List<string> GmbModOwnershipPersonsList { get; set; }
    }

    public class CreateDistributionGroupViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string DgCreateLocation { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        [RegularExpression(@"^[a-zA-Z0-9-]{3,40}$", ErrorMessage = "Das Feld muss zwischen 3 und 40 Zeichen lang sein und darf nur Buchstaben (ohne Umlaute), Zahlen und Bindestriche enthalten.")]
        public string DgCreateSearchFor { get; set; }

        public string DgCreateDisplayName { get; set; }

        public string DgCreateAlias { get; set; }

        //[Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        //[EmailAddress(ErrorMessage = "Bitte geben Sie eine gültige E-Mail Adresse ein.")]
        public string DgCreateEmailAddress { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string DgCreateManager { get; set; }

        public bool DgCreateHideFromAddressLists { get; set; }
    }

    public class ModifyDistributionGroupPermissionsViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string DgModPermissionGroupName { get; set; }

        //[Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string DgModPermissionUser { get; set; }

        [MinLength(1, ErrorMessage = "Es muss mindestens ein Benutzer ausgewählt werden.")]
        public List<string> DgModPermissionUsersList { get; set; }
    }

    //public class ModifyDistributionGroupResponsibleViewModel
    //{
    //    public string DgModOwnershipGroupName { get; set; }
    //    public string DgModNewOwner { get; set; }
    //    //public List<SelectListItem> DgSelectGroup { get; set; } = new List<SelectListItem>();
    //    //public List<SelectListItem> DgNewResponsible { get; set; } = new List<SelectListItem>();
    //}

    public class DeleteDistributionGroupViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string DgDeleteGroupName { get; set; }
    }

    public class UpdateUserNameChangeViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]

        public string UserNameChangeUserSelect { get; set; }

        public string HiddenSamAccountName { get; set; }

        public bool UserNameChangeNewUserId { get; set; }

        public string UserNameChangeUserId { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string UserNameChangeLastName { get; set; }

        public string UserNameChangeEmail { get; set; }
    }

    public class UpdateAdAndExchangeViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string AdAndExchangeUserSelect { get; set; }
        public string AdAndExchangeAlias { get; set; }
        public string AdAndExchangeAccountStatus { get; set; }
    }

    public class CreateNewHausarztUserViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewHausarztLocation { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewHausarztFirstName { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewHausarztLastName { get; set; }

        public string NewHausarztUserId { get; set; }

        public string ExistingHausarztUserId { get; set; }
    }

    public class CreateNewAdminUserViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewAdminPersId { get; set; }

        public string NewAdminFirstName { get; set; }

        public string NewAdminLastName { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public bool NewAdminCreateAccount { get; set; }

        public string NewAdminUserId { get; set; }
    }

    public class CreateNewExternalUserViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewExternalUserType { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewExternalFirstName { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewExternalLastName { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewExternalLocation { get; set; }

        public string NewExternalUserId { get; set; }

        public bool NewExternalEnableMailbox { get; set; }

        [Required(ErrorMessage = $"Das Geburtsdatum ist erforderlich.")]
        [MinimumAge(15)]
        public DateTime? NewExternalBirthdate { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewExternalCompany { get; set; }
    }

    public class CreateNewInternalUserViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewInternalPersId { get; set; }
        public string NewInternalFirstName { get; set; }
        public string NewInternalLastName { get; set; }
        public string NewInternalUserId { get; set; }
        public DateTime? NewInternalBirthdate { get; set; }
        public string NewInternalDepartment { get; set; }
        public string SelectedDuplicateSamAccountName { get; set; }

    }

    public class CreateNewServiceUserViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewServiceAccountType { get; set; }

        public string NewServiceFirstName { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewServiceLastName { get; set; }

        public bool NewServiceEnableMailbox { get; set; }

        public string NewServiceUserId { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string NewServiceAppDescription { get; set; }
    }

    public class CreateMultifunctionUserViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string MultifunctionLocation { get; set; }

        public List<SelectListItem> AvailableLocations { get; set; } = new()
        {
            new SelectListItem { Text = "Liestal", Value = "LI" },
            new SelectListItem { Text = "Bruderholz", Value = "BH" },
            new SelectListItem { Text = "Laufen", Value = "LA" }
        };

        //[ValidateMultifunctionName(ErrorMessage = "Der Multifunktionsname muss mindestens 6 Zeichen lang sein und mit dem Standort beginnen.")]
        public string MultifunctionName { get; set; }

        public string MultifunctionUserId { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string MultifunctionDescription { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string MultifunctionResponsible { get; set; }
    }

    public class AssignMobileNumberViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string MobileNumberUserSelect { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string MobileNumber { get; set; }
    }

    public class HospisUserActionViewModel
    {
        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string HospisPersonName { get; set; }

        [Required(ErrorMessage = "Dieses Feld ist erforderlich.")]
        public string HospisAction { get; set; }

        public bool CanAccessITInfrastructure { get; set; }
        public bool HospisUrgent { get; set; }
        public string HospisPersId { get; set; }
        public string hiddenWindowsUserId { get; set; }
        public string HospisLocation { get; set; }
        public string HospisReferencingUser { get; set; }
        [ValidateNever]
        public string HospisFullName { get; set; }
        [ValidateNever]
        [BindNever]
        public string HospisRole { get; set; }
        [ValidateNever]
        [BindNever]
        public string HospisOrg { get; set; }
        [ValidateNever]
        [BindNever]
        public string HospisStatus { get; set; }
        [ValidateNever]
        [BindNever]
        public DateTime? HospisBirthdate { get; set; }
        [ValidateNever]
        [BindNever]
        public string HospisWindowsLastLogin { get; set; }
        [ValidateNever]
        [BindNever]
        public DateTime? HospisDateExpiry { get; set; }
        public string SelectedDuplicateSamAccountName { get; set; } 
    }

    public class ExtendInactiveUserViewModel
    {
        public string InactiveUser { get; set; }
        public DateTime? ValidUntil { get; set; }
    }

    public class JobArchiveViewModel
    {
        public DateTime CreatedDate { get; set; }
        public string ActionType { get; set; }
        public string CurrentUserEMailAddress { get; set; }
        public string LineSummary { get; set; }
    }

    public class JobArchiveListViewModel
    {
        public List<JobArchiveViewModel> Lines { get; set; }
    }

}
