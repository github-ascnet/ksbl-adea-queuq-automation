﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Infrastructure.GUI.Web.Models
{
    public class Account
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(50)]
        public string PrivisioningActionType { get; set; }
        [MaxLength(100)]
        public string Name { get; set; }
        [MaxLength(100)]
        public string Cn { get; set; }
        [MaxLength(100)]
        public string SamAccountName { get; set; }
        [MaxLength(100)]
        public string Title { get; set; }
        [MaxLength(50)]
        public string SurName { get; set; }
        [MaxLength(50)]
        public string GivenName { get; set; }
        [MaxLength(125)]
        public string UserPrincipalName { get; set; }
        [MaxLength(100)]
        public string DisplayName { get; set; }
        [NotMapped]
        public string LegacySourceDomain { get; set; }
        [MaxLength(256)]
        public string Manager { get; set; }
        [NotMapped]
        public string ManagerShortName { get; set; }
        [MaxLength(25)]
        public string EmployeeId { get; set; }
        [MaxLength(10)]
        public string EmployeeType { get; set; }
        [MaxLength(100)]
        public string SmsPasscodeMobile { get; set; }
        [MaxLength(100)]
        public string Department { get; set; }
        [NotMapped]
        public string DepartmentShort { get; set; }
        [MaxLength(100)]
        public string Division { get; set; }
        [MaxLength(100)]
        public string Company { get; set; }
        public string Description { get; set; }
        [MaxLength(100)]
        public string StreetAddress { get; set; }
        [MaxLength(10)]
        public string PostalCode { get; set; }
        [MaxLength(10)]
        public string CountryState { get; set; }
        [MaxLength(50)]
        public string City { get; set; }
        [MaxLength(50)]
        public string Country { get; set; }
        [MaxLength(50)]
        public string HomePage { get; set; }
        [MaxLength(50)]
        public string TelephoneNumber { get; set; }
        [MaxLength(50)]
        public string FacsimileTelephoneNumber { get; set; }
        [MaxLength(50)]
        public string MobilephoneNumber { get; set; }
        [MaxLength(512)]
        public string UserAccountControl { get; set; }
        public DateTime? PwdLastSet { get; set; }
        public DateTime? LastLogonTimestamp { get; set; }
        public DateTime? AccountExpires { get; set; }
        [MaxLength(100)]
        public string MailNickname { get; set; }
        [MaxLength(100)]
        public string TargetAddress { get; set; }
        [MaxLength(100)]
        public string ExchMailboxGuid { get; set; }
        [MaxLength(100)]
        public string ExchRecipientTypeDetails { get; set; }
        [MaxLength(100)]
        public string ExchRecipientDisplayType { get; set; }
        public string LegacyExchangeDN { get; set; }
        public bool ExchHideFromAddressLists { get; set; }
        [MaxLength(100)]
        public string Mail { get; set; }
        [NotMapped]
        public string MailName { get; set; }
        [NotMapped]
        public string MailDomainName { get; set; }
        public string ProxyAddresses { get; set; }
        [MaxLength(512)]
        public string AltRecipient { get; set; }
        [MaxLength(256)]
        public string DistinguishedName { get; set; }
        [MaxLength(256)]
        public string AdReferenceObjectGuid { get; set; }
        public string ExtensionAttribute1 { get; set; }
        public string ExtensionAttribute2 { get; set; }
        public string ExtensionAttribute3 { get; set; }
        public string ExtensionAttribute4 { get; set; }
        public string ExtensionAttribute5 { get; set; }
        public string ExtensionAttribute6 { get; set; }
        public string ExtensionAttribute7 { get; set; }
        public string ExtensionAttribute8 { get; set; }
        public string ExtensionAttribute9 { get; set; }
        public string ExtensionAttribute10 { get; set; }
        public string ExtensionAttribute11 { get; set; }
        public string ExtensionAttribute12 { get; set; }
        public string ExtensionAttribute13 { get; set; }
        public string ExtensionAttribute14 { get; set; }
        public string ExtensionAttribute15 { get; set; }
        public DateTime? WhenCreated { get; set; }
        public DateTime? WhenChanged { get; set; }
        [MaxLength(50)]
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        [MaxLength(255)]
        public string HrmsBadgeFirstName { get; set; }
        [MaxLength(255)]
        public string HrmsBadgeLastName { get; set; }
        [MaxLength(255)]
        public string HrmsBirthdate { get; set; }
        [MaxLength(255)]
        public string HrmsCostCenter { get; set; }
        [MaxLength(255)]
        public string HrmsFunction { get; set; }
        [MaxLength(255)]
        public string HrmsFunctionCategory { get; set; }
        [MaxLength(255)]
        public string HrmsGender { get; set; }
        [MaxLength(255)]
        public string HrmsJoinerDate { get; set; }
        [MaxLength(255)]
        public string HrmsLeaverDate { get; set; }
        [MaxLength(255)]
        public string HrmsMgmtLevelNumber { get; set; }
        [MaxLength(255)]
        public string HrmsMgmtLevelNumberAdditive { get; set; }
        [MaxLength(255)]
        public string HrmsOrgId { get; set; }
        [MaxLength(255)]
        public string HrmsPhoneLocation { get; set; }
        [MaxLength(255)]
        public string HrmsSKATDescription { get; set; }
        [MaxLength(255)]
        public string HrmsSKATNumber { get; set; }
        [NotMapped]
        public string PrimaryEMailAddress { get; set; }
        [NotMapped]
        public string MemberCategory { get; set; }
    }

    public class AccountsToGroup
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(50)]
        public string PrivisioningActionType { get; set; }
        public int? AccountsId { get; set; }
        public int? GroupsId { get; set; }
        [MaxLength(100)]
        public string MemberName { get; set; }
        [MaxLength(100)]
        public string MemberCategory { get; set; }
        [MaxLength(100)]
        public string GroupName { get; set; }
        [MaxLength(50)]
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }

    public class MailboxPermission
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(50)]
        public string PrivisioningActionType { get; set; }
        [MaxLength(100)]
        public string Name { get; set; }
        [MaxLength(100)]
        public string TrusteeName { get; set; }
        [MaxLength(50)]
        public string TrusteeDomain { get; set; }
        public string AcePermissions { get; set; }
        [MaxLength(256)]
        public string DistinguishedName { get; set; }
        public bool? ExchHideFromAddressLists { get; set; }
        [MaxLength(256)]
        public string AdReferenceObjectGuid { get; set; }
        [MaxLength(128)]
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        [NotMapped]
        public string PermissionType { get; set; }
        [NotMapped]
        public string AssignedTo { get; set; }
        [NotMapped]
        public DateTime? GrantedOn { get; set; }
        [NotMapped]
        public string GrantedBy { get; set; }
        [NotMapped]
        public DateTime? RevokedOn { get; set; }
        [NotMapped]
        public string RevokedBy { get; set; }
    }

    [Table("hist_MailboxPermissions")]
    public class MailboxPermissionsHistory
    {
        public int Id { get; set; }
        public int AccountsId { get; set; }
        public int TrusteeId { get; set; }
        public string? AdReferenceObjectGuid { get; set; }
        public string? TrusteeReferenceObjectGuid { get; set; }
        public string? ObjectCategory { get; set; }
        public string? AcePermissions { get; set; }
        public string? ModificationType { get; set; }
        public string? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }

    public class ManagersToGroup
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(50)]
        public string PrivisioningActionType { get; set; }
        public int? AccountsId { get; set; }
        public int? GroupsId { get; set; }
        [MaxLength(100)]
        public string ManagerName { get; set; }
        [MaxLength(100)]
        public string GroupName { get; set; }
        [MaxLength(50)]
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        // Navigation Property to the Account Model Class
        [ForeignKey("AccountsId")]
        public Account Account { get; set; }
    }

    public class StgAccount
    {
        [Key]
        public int Id { get; set; }
        [Required, MaxLength(100)]
        public string Name { get; set; }
        [Required, MaxLength(100)]
        public string Cn { get; set; }
        [Required, MaxLength(100)]
        public string SamAccountName { get; set; }
        [MaxLength(50)]
        public string Title { get; set; }
        [MaxLength(50)]
        public string SurName { get; set; }
        [MaxLength(50)]
        public string GivenName { get; set; }
        [MaxLength(125)]
        public string UserPrincipalName { get; set; }
        [MaxLength(100)]
        public string DisplayName { get; set; }
        [MaxLength(256)]
        public string Manager { get; set; }
        [NotMapped]
        public string ManagerShortName { get; set; }
        [MaxLength(25)]
        public string EmployeeId { get; set; }
        [MaxLength(10)]
        public string EmployeeType { get; set; }
        [MaxLength(100)]
        public string SmsPasscodeMobile { get; set; }
        [MaxLength(100)]
        public string Department { get; set; }
        [MaxLength(100)]
        public string Division { get; set; }
        [MaxLength(100)]
        public string Company { get; set; }
        public string Description { get; set; }
        [MaxLength(100)]
        public string StreetAddress { get; set; }
        [MaxLength(10)]
        public string PostalCode { get; set; }
        [MaxLength(10)]
        public string CountryState { get; set; }
        [MaxLength(50)]
        public string City { get; set; }
        [MaxLength(50)]
        public string Country { get; set; }
        [MaxLength(50)]
        public string HomePage { get; set; }
        [MaxLength(50)]
        public string TelephoneNumber { get; set; }
        [MaxLength(50)]
        public string FacsimileTelephoneNumber { get; set; }
        [MaxLength(50)]
        public string MobilephoneNumber { get; set; }
        [Required, MaxLength(512)]
        public string UserAccountControl { get; set; }
        public DateTime PwdLastSet { get; set; }
        public DateTime LastLogonTimestamp { get; set; }
        public DateTime AccountExpires { get; set; }
        [MaxLength(100)]
        public string MailNickname { get; set; }
        [MaxLength(100)]
        public string TargetAddress { get; set; }
        [MaxLength(100)]
        public string ExchMailboxGuid { get; set; }
        [MaxLength(100)]
        public string ExchRecipientTypeDetails { get; set; }
        [MaxLength(100)]
        public string ExchRecipientDisplayType { get; set; }
        public string LegacyExchangeDN { get; set; }
        public bool? ExchHideFromAddressLists { get; set; }
        [MaxLength(100)]
        public string Mail { get; set; }
        [NotMapped]
        public string MailName { get; set; }
        [NotMapped]
        public string MailDomainName { get; set; }
        public string ProxyAddresses { get; set; }
        [MaxLength(512)]
        public string AltRecipient { get; set; }
        [Required, MaxLength(256)]
        public string DistinguishedName { get; set; }
        [Required, MaxLength(256)]
        public string AdReferenceObjectGuid { get; set; }
        public string ExtensionAttribute1 { get; set; }
        public string ExtensionAttribute2 { get; set; }
        public string ExtensionAttribute3 { get; set; }
        public string ExtensionAttribute4 { get; set; }
        public string ExtensionAttribute5 { get; set; }
        public string ExtensionAttribute6 { get; set; }
        public string ExtensionAttribute7 { get; set; }
        public string ExtensionAttribute8 { get; set; }
        public string ExtensionAttribute9 { get; set; }
        public string ExtensionAttribute10 { get; set; }
        public string ExtensionAttribute11 { get; set; }
        public string ExtensionAttribute12 { get; set; }
        public string ExtensionAttribute13 { get; set; }
        public string ExtensionAttribute14 { get; set; }
        public string ExtensionAttribute15 { get; set; }
        public DateTime WhenCreated { get; set; }
        public DateTime WhenChanged { get; set; }
        public DateTime StagingInserted { get; set; }
        [MaxLength(255)]
        public string HrmsBadgeFirstName { get; set; }
        [MaxLength(255)]
        public string HrmsBadgeLastName { get; set; }
        [MaxLength(255)]
        public string HrmsBirthdate { get; set; }
        [MaxLength(255)]
        public string HrmsCostCenter { get; set; }
        [MaxLength(255)]
        public string HrmsFunction { get; set; }
        [MaxLength(255)]
        public string HrmsFunctionCategory { get; set; }
        [MaxLength(255)]
        public string HrmsGender { get; set; }
        [MaxLength(255)]
        public string HrmsJoinerDate { get; set; }
        [MaxLength(255)]
        public string HrmsLeaverDate { get; set; }
        [MaxLength(255)]
        public string HrmsMgmtLevelNumber { get; set; }
        [MaxLength(255)]
        public string HrmsMgmtLevelNumberAdditive { get; set; }
        [MaxLength(255)]
        public string HrmsOrgId { get; set; }
        [MaxLength(255)]
        public string HrmsPhoneLocation { get; set; }
        [MaxLength(255)]
        public string HrmsSKATDescription { get; set; }
        [MaxLength(255)]
        public string HrmsSKATNumber { get; set; }
        [NotMapped]
        public string AccountName { get; set; }
        [NotMapped]
        public string AccountType { get; set; }
        [NotMapped]
        public DateTime? CreatedOn { get; set; }
        [NotMapped]
        public string CreatedBy { get; set; }
        [NotMapped]
        public DateTime? ModifiedOn { get; set; }
        [NotMapped]
        public string ModifiedBy { get; set; }
        [NotMapped]
        public bool IsActive { get; set; }
    }

    public class RoleTemplate
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(255)]
        public string Standort { get; set; }
        [MaxLength(255)]
        public string Abteilung { get; set; }
        [MaxLength(255)]
        public string Funktion { get; set; }
        [MaxLength(255)]
        public string Template { get; set; }
    }

    public class Group
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(50)]
        public string PrivisioningActionType { get; set; }
        [MaxLength(100)]
        public string Name { get; set; }
        [MaxLength(100)]
        public string Cn { get; set; }
        [MaxLength(100)]
        public string SamAccountName { get; set; }
        [MaxLength(100)]
        public string DisplayName { get; set; }
        [MaxLength(100)]
        public string LegacySourceDomain { get; set; }
        [MaxLength(256)]
        public string Manager { get; set; }
        [NotMapped]
        public string ManagerShortName { get; set; }
        [MaxLength(1024)]
        public string GroupType { get; set; }
        [NotMapped]
        public string GroupTypeTranslated { get; set; }
        public string Info { get; set; }
        [MaxLength(100)]
        public string MailNickname { get; set; }
        [MaxLength(100)]
        public string TargetAddress { get; set; }
        [MaxLength(256)]
        public string LegacyExchangeDN { get; set; }
        public bool? ExchHideFromAddressLists { get; set; }
        [MaxLength(100)]
        public string Mail { get; set; }
        [NotMapped]
        public string MailName { get; set; }
        [NotMapped]
        public string MailDomainName { get; set; }
        public string ProxyAddresses { get; set; }
        public string AuthOrig { get; set; }
        public string UnauthOrig { get; set; }
        public string MemSubmitPerms { get; set; }
        public string MemRejectPerms { get; set; }
        [MaxLength(256)]
        public string DistinguishedName { get; set; }
        [MaxLength(256)]
        public string AdReferenceObjectGuid { get; set; }
        public string ExtensionAttribute1 { get; set; }
        public string ExtensionAttribute2 { get; set; }
        public string ExtensionAttribute3 { get; set; }
        public string ExtensionAttribute4 { get; set; }
        public string ExtensionAttribute5 { get; set; }
        public string ExtensionAttribute6 { get; set; }
        public string ExtensionAttribute7 { get; set; }
        public string ExtensionAttribute8 { get; set; }
        public string ExtensionAttribute9 { get; set; }
        public string ExtensionAttribute10 { get; set; }
        public string ExtensionAttribute11 { get; set; }
        public string ExtensionAttribute12 { get; set; }
        public string ExtensionAttribute13 { get; set; }
        public string ExtensionAttribute14 { get; set; }
        public string ExtensionAttribute15 { get; set; }
        public DateTime? WhenCreated { get; set; }
        public DateTime? WhenChanged { get; set; }
        [MaxLength(50)]
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        [NotMapped]
        public string Member { get; set; }
    }

    public class Configuration
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(50)]
        public string InternalUserId { get; set; }
        [NotMapped]
        public string NextInternalUserId { get; set; }
        [MaxLength(50)]
        public string ExternalUserId { get; set; }
        [NotMapped]
        public string NextExternalUserId { get; set; }
        [MaxLength(50)]
        public string DistributionId { get; set; }
        [MaxLength(10)]
        public string NextDistributionId { get; set; }
        [MaxLength(50)]
        public string GroupMailboxId { get; set; }
        [MaxLength(10)]
        public string NextGroupMailboxId { get; set; }
        [NotMapped]
        public string Key { get; set; }
        [NotMapped]
        public string Value { get; set; }
        [NotMapped]
        public DateTime? CreatedOn { get; set; }
        [NotMapped]
        public string CreatedBy { get; set; }
        [NotMapped]
        public DateTime? ModifiedOn { get; set; }
        [NotMapped]
        public string ModifiedBy { get; set; }
    }

    public class AccountControlState
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(50)]
        public string ProvisioningActionType { get; set; }
        [Required]
        public int AccountsId { get; set; }
        [MaxLength(100)]
        public string SamAccountName { get; set; }
        [MaxLength(100)]
        public string AccountState { get; set; }
        public DateTime? EnabledUntil { get; set; }
        public bool? IgnoreEnabledUntil { get; set; }
        [MaxLength(50)]
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public DateTime? CompletedOn { get; set; }
    }

    public class MailboxFolderPermission
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(50)]
        public string FolderAce { get; set; }
        [NotMapped]
        public string FolderName { get; set; }
        [NotMapped]
        public string PermissionLevel { get; set; }
        [NotMapped]
        public string AssignedTo { get; set; }
        [NotMapped]
        public DateTime? GrantedOn { get; set; }
        [NotMapped]
        public string GrantedBy { get; set; }
        [NotMapped]
        public DateTime? RevokedOn { get; set; }
        [NotMapped]
        public string RevokedBy { get; set; }
    }

    public class Person
    {
        [Key]
        public int Id { get; set; }
        public string Personalnummer { get; set; }
        public string Vorname { get; set; }
        public string Nachname { get; set; }
        [Column("Vor/Nachname")]
        public string Vor_Nachname { get; set; } 
        public string Tätigkeit { get; set; }
        public string Organisationseinheit { get; set; }
        public string Standort { get; set; }
        public string WindowsLogin { get; set; }
        public string WindowsAccountState { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public string WindowsAccountStateTranslated { get; set; }
        public DateTime? WindowsLastLogin { get; set; }
        public DateTime? WindowsPwdLastChanged { get; set; }
        public DateTime? WindowsAccountExpires { get; set; }
        public string WindowsExtAttrib11 { get; set; }
        public string WindowsEmployeeType { get; set; }
        public DateTime? Eintrittsdatum { get; set; }
        public DateTime? Austrittsdatum { get; set; }
        public string Geburtsdatum { get; set; }
        public string MitarbeiterTyp { get; set; }
        [NotMapped]
        public int FuzzyMatchScore { get; set; }
    }

    public class EmployeeType
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(50)]
        public string EmployeeTypeName { get; set; }
        public int? SortOrderId { get; set; }
    }

    [Table("PersonsHistory")]
    public class PersonsHistory
    {
        [Key]
        public int Id { get; set; }
        public DateTime? ImportDate { get; set; }
        [MaxLength(50)]
        public string Personalnummer { get; set; }
        [MaxLength(9)]
        public string Mitarbeiterstatus { get; set; }
        [MaxLength(1001)]
        public string Ganzer_Name { get; set; }
        public DateTime? Eintrittsdatum { get; set; }
        public DateTime? Austrittsdatum { get; set; }
    }

    public class PersonsDuplicate
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(50)]
        public string Personalnummer { get; set; }
        [MaxLength(50)]
        public string Personalnummer_M2 { get; set; }
        public string AdBenutzer { get; set; }
        public string AdBenutzer_M2 { get; set; }
        [MaxLength(8)]
        public string Benutzer_Status { get; set; }
        [MaxLength(8)]
        public string Benutzer_Status_M2 { get; set; }
        [MaxLength(513)]
        public string Ganzer_Name { get; set; }
        [MaxLength(513)]
        public string Ganzer_Name_M2 { get; set; }
        [MaxLength(50)]
        public string Geburtsdatum { get; set; }
        [MaxLength(50)]
        public string Geburtsdatum_M2 { get; set; }
        [MaxLength(500)]
        public string Organisationseinheit { get; set; }
        [MaxLength(500)]
        public string Organisationseinheit_M2 { get; set; }
        public DateTime? Eintrittsdatum { get; set; }
        public DateTime? Eintrittsdatum_M2 { get; set; }
        public DateTime? Austrittsdatum { get; set; }
        public DateTime? Austrittsdatum_M2 { get; set; }

        //[NotMapped]
        //public int OriginalPersonId { get; set; }
        //[NotMapped]
        //public int DuplicatePersonId { get; set; }
        //[NotMapped]
        //public DateTime? CreatedOn { get; set; }
        //[NotMapped]
        //public string CreatedBy { get; set; }
        //[NotMapped]
        //public DateTime? ResolvedOn { get; set; }
        //[NotMapped]
        //public string ResolvedBy { get; set; }
    }

    public class Department
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(255)]
        public string Abteilung { get; set; }
        public string Gruppen { get; set; }
        [NotMapped]
        public string DepartmentName { get; set; }
    }

    //public class VwNextAvailableGmbIdForSamAccName
    //{
    //    public int Id { get; set; }
    //    public string SamAccountName { get; set; }
    //    public string NewSamAccountName { get; set; }
    //}
    //public class VwNextAvailableVlIdForSamAccName
    //{
    //    public int Id { get; set; }
    //    public string MailNickname { get; set; }
    //    public string NewMailNickname { get; set; }
    //}

    //public class VwNextAvailableInternalUserIdForSamAccName
    //{
    //    public int Id { get; set; }
    //    public string NextSamAccountName { get; set; }
    //}

    //public class VwNextAvailableExternalUserIdForSamAccName
    //{
    //    public int Id { get; set; }
    //    public string NextSamAccountName { get; set; }
    //}


}

