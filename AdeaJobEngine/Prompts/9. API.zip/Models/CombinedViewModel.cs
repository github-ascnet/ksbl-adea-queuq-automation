﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace Infrastructure.GUI.Web.Models
{
    public class CombinedViewModel
    {
        public string ActiveSection { get; set; }
        public string ActiveTab { get; set; }
        public string ActiveAccordion { get; set; }
        public bool CanAccessITInfrastructure { get; set; }
        public bool CanAccessITServicedesk { get; set; }


        //public bool CanAccessCreateNewGroupMailbox { get; set; }
        //public bool CanAccessModifyGroupMailboxPermissions { get; set; }
        //public bool CanAccessModifyGroupMailboxResponsible { get; set; }
        //public bool CanAccessCreateNewDistributionGroup { get; set; }
        //public bool CanAccessModifyDistributionGroupPermissions { get; set; }
        //public bool CanAccessModifyDistributionGroupResponsible { get; set; }
        //public bool CanAccessDeleteDistributionGroup { get; set; }
        //public bool CanAccessModifyUserNameChange { get; set; }
        //public bool CanAccessModifyUserAddMailNickname { get; set; }
        //public bool CanAccessChangeMobileNumber { get; set; }
        //public bool CanAccessCreateHausarztUser { get; set; }
        //public bool CanAccessCreateInternalUser { get; set; }
        //public bool CanAccessCreateExternalUser { get; set; }
        //public bool CanAccessCreateAdminUser { get; set; }
        //public bool CanAccessCreateServiceUser { get; set; }
        //public bool CanAccessCreateMultiFunctionalGenericUser { get; set; }
        //public bool CanAccessSubmitTransactions { get; set; }
        //public bool CanAccessModifyRoleMemberships { get; set; }
        //public bool CanAccessCopyUserToUser { get; set; }
        //public bool CanAccessModifyGroupMemberships { get; set; }

        public CreateGroupMailboxViewModel CreateGroupMailbox { get; set; }
        public ModifyGroupMailboxPermissionsViewModel ModifyGroupMailboxPermissions { get; set; }
        public ModifyGroupMailboxResponsibleViewModel ModifyGroupMailboxResponsible { get; set; }
        public CreateDistributionGroupViewModel CreateDistributionGroup { get; set; }
        public ModifyDistributionGroupPermissionsViewModel ModifyDistributionGroupPermissions { get; set; }
        //public ModifyDistributionGroupResponsibleViewModel ModifyDistributionGroupResponsible { get; set; }
        public DeleteDistributionGroupViewModel DeleteDistributionGroup { get; set; }
        public UpdateUserNameChangeViewModel UpdateUserNameChange { get; set; }
        public UpdateAdAndExchangeViewModel UpdateAdAndExchange { get; set; }
        public CreateNewHausarztUserViewModel CreateNewHausarztUser { get; set; }
        public CreateNewAdminUserViewModel CreateNewAdminUser { get; set; }
        public CreateNewExternalUserViewModel CreateNewExternalUser { get; set; }
        public CreateNewInternalUserViewModel CreateNewInternalUser { get; set; }
        public CreateNewServiceUserViewModel CreateNewServiceUser { get; set; }
        public CreateMultifunctionUserViewModel CreateMultifunctionUser { get; set; }
        public AssignMobileNumberViewModel AssignMobileNumber { get; set; }
        public HospisUserActionViewModel HospisUserAction { get; set; }
        public ExtendInactiveUserViewModel ExtendInactiveUser { get; set; }
        public JobArchiveViewModel JobArchive { get; set; }
    }
}
